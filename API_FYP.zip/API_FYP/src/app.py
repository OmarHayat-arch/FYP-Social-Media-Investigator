from flask import Flask, request, jsonify
from flask_pymongo import PyMongo, ObjectId
from flask_cors import CORS
from pandas import pandas
from pymongo import MongoClient

app = Flask(__name__)
# app.config['MONGO_URI']='mongodb://omar1234:omar1234@cluster0-shard-00-00.ddf2s.mongodb.net:27017,cluster0-shard-00-01.ddf2s.mongodb.net:27017,cluster0-shard-00-02.ddf2s.mongodb.net:27017/SocialMedia?ssl=true&replicaSet=atlas-g1k44j-shard-0&authSource=admin&retryWrites=true&w=majority'
# mongo=PyMongo(app)
CORS(app)
#db =mongo.db.users


client = MongoClient("mongodb://omar1234:omar1234@cluster0-shard-00-00.ddf2s.mongodb.net:27017,cluster0-shard-00-01.ddf2s.mongodb.net:27017,cluster0-shard-00-02.ddf2s.mongodb.net:27017/SocialMedia?ssl=true&replicaSet=atlas-g1k44j-shard-0&authSource=admin&retryWrites=true&w=majority")
db = client.get_database('SocialMedia')
records = db.Test


@app.route('/', methods=['GET'])
def index():
    return '<h1> WELCOME TO FLASK API </h1>'


@app.route('/users', methods=['GET'])
def create_user():
    id = records.insert({'content': [{"tweet": "Lets go Pakistan", "likes": 5}, {
                        "tweet": "Pakistan Zindabad", "likes": 5}], "Trend": "#Pakistan"})
    return jsonify({'id': str(ObjectId(id)), 'msg': "User added successfully"})


@app.route('/trends', methods=['GET'])
def get_trends():
    trends = []
    for tren in records.find():
        trends.append({
            '_id': str(ObjectId(tren['_id'])),
            'content': tren['content'],
            'Trend': tren['Trend']
        })


@app.route('/trends/<id>', methods=['GET'])
def get_trend(id):
    trend = records.find_one({'_id':ObjectId(id)})
    return jsonify({
        '_id': str(ObjectId(trend['_id'])),
        'content': trend['content'],
        'Trend': trend['Trend']
    })   
@app.route('/trends/CivilWar', methods=['GET'])
def get_trendCivilWar():
    trend = records.find_one({'_id':ObjectId('617aa63aa2071ec120abdfd0')})
    return jsonify({
        '_id': str(ObjectId(trend['_id'])),
        'content': trend['content'],
        'Trend': trend['Trend']
    })   
@app.route('/trends/StopBalochGenocide', methods=['GET'])
def get_trendStopBalochGenocide():
    trend = records.find_one({'_id':ObjectId('61c3678bd4b2d3de32ad8a63')})
    return jsonify({
        '_id': str(ObjectId(trend['_id'])),
        'content': trend['content'],
        'Trend': trend['Trend']
    }) 
@app.route('/trends/SanctionPakistan', methods=['GET'])
def get_trendSanctionPakistan():
    trend = records.find_one({'_id':ObjectId('61c39927e345142a93816962')})
    return jsonify({
        '_id': str(ObjectId(trend['_id'])),
        'content': trend['content'],
        'Trend': trend['Trend']
    })    
if __name__ == '__main__':
    app.run(debug=True)
