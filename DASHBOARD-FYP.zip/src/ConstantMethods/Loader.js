import React,{ useState } from "react";



function TextField(props){

//const [Getitem,SetItem]= useState(null);



    return(

      <div class="row-form">
      <div class="col-12">
        <div>
       
          <img
            style={{ width: "100px", height: "100px" }}
            src="/Loader.gif"
          />
        </div>
      </div>
    </div>
    )


}

export default TextField

//onChange={(date) => props.changeDate(date) || setStartDate(date) ||  setMonthDate(date) || setYearDate(date)}   ||SetItem(event.target.value.toUpperCase())