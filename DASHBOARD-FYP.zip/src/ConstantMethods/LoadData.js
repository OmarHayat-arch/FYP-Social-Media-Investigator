
async function loadData(GetReportURL, inputparam) {

    // Use the Fetch Api to pull the data https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
  
    const headers = new Headers();
    let param = GetReportURL + inputparam;
    const dataRequest = new Request(param, {
      headers: headers,
    });
  
    const response = await fetch(dataRequest);
  
    const data = await response.json();
  
    return data;
  }
  export default loadData;