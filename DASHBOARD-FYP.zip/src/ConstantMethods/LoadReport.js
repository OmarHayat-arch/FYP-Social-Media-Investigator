
async function loadReport(LoadReportURL) {
    // load report definition from the file
    const reportResponse = await fetch(LoadReportURL);
    const report = await reportResponse.json();
    return report;
  }
  export default loadReport;