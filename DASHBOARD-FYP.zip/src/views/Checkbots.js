import React,{useState,useEffect} from 'react'
import { DataGrid } from '@mui/x-data-grid';
import './dynamicrow.css';
import {
    CBadge,
    CButton,
    CButtonGroup,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CProgress,
    CRow,
    CCreateElement,
    CWidgetIcon,
    CCallout,
    CSidebarNavDivider,
    CSidebarNavDropdown,
    CSidebarNavItem,
    CSidebarNavTitle,
} from '@coreui/react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import CIcon from '@coreui/icons-react'
import '@progress/kendo-theme-default/dist/all.css';
import { Grid, GridColumn } from '@progress/kendo-react-grid';

import products from './products.json';
import axios from 'axios';
//import Loader from "./loader/loader";

const initialDataState = {
  skip: 0,
  take: 10
};

const CheckBots = () =>{
    const[records,setRecords]=useState([]);
    //const[loading,setLoading]=useState(false);
    const[searching,setSearching]=useState(true);
    const[search,setSearch]=useState("");

    const columns = [
      {
        field: 'Tweet',
        headerName: 'Tweet',
        width: 400,
        editable: true,
      },
      {
        field: 'User Name',
        headerName: 'User Name',
        width: 150,
        editable: true,
      },
      {
        field: 'Account Status',
        headerName: 'Account Status',
        width: 150,
        editable: true,
      },
      {
        field: 'Sentiment',
        headerName: 'Sentiment',
        width: 150,
        editable: true,
      },
      {
        field: 'Location',
        headerName: 'Location',
        width: 150,
        editable: true,
      },
    ];




function Loader()
{
    return <h1> Loading ...</h1>
}
function Filter()
{
    if(search.includes("#")){
      alert("ERROR")
      return false;
    }
  return true
}
function Loadtrend(){
    if (Filter()==true){
    setSearching(false);
    axios.get('http://localhost:5000/bots?myparam='+search)
    .then(res =>{setRecords(res.data)
    setSearching(true);
    console.log("Response =",res)
    }
    );
  }
    //alert(search);
}
    return (
        <>
      <div style={{ width: '50%' }}>
        <TextField
        label="Search Trend"
        color="secondary"
        focused
        inputProps={{ maxLength: 50 }}
        onChange={(e)=>setSearch(e.target.value)}
        fullWidth
      />
      </div>
        
        <br/>
        <Button variant="contained" color="secondary" onClick={Loadtrend}>
        Search
      </Button>
      <br/>
      <br/>
        
      {searching ? (     <div style={{ height: 500, width: '100%' }}>
      <DataGrid 
           sx={{
            boxShadow: 2,
            border: 2,
            borderColor: 'secondary.light',
            '& .MuiDataGrid-cell:hover': {
              color: 'secondary.main',
            },
          }}
      getRowId={(row) => row.ID}
        rows={records}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        checkboxSelection
        disableSelectionOnClick
      />
    </div> )
        :(<Loader/>)
    }
        </>
        )
}

export default CheckBots;