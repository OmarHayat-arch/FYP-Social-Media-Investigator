import React,{useState,useEffect} from 'react'
import { DataGrid } from '@mui/x-data-grid';
import './dynamicrow.css';
import {
    CBadge,
    CButton,
    CButtonGroup,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CProgress,
    CRow,
    CCreateElement,
    CWidgetIcon,
    CCallout,
    CSidebarNavDivider,
    CSidebarNavDropdown,
    CSidebarNavItem,
    CSidebarNavTitle,
} from '@coreui/react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import CIcon from '@coreui/icons-react'
import '@progress/kendo-theme-default/dist/all.css';
import { Grid, GridColumn } from '@progress/kendo-react-grid';

import products from './products.json';
import axios from 'axios';
//import Loader from "./loader/loader";
import { red } from '@mui/material/colors';

const color = red[500];
const initialDataState = {
  skip: 0,
  take: 10
};

const Countertrend = () =>{
    const[records,setRecords]=useState([]);
    //const[loading,setLoading]=useState(false);
    const[searching,setSearching]=useState(true);
    const[search,setSearch]=useState("");

    const columns = [
      {
        field: 'Tweet',
        headerName: 'Tweet',
        width: 400,
        editable: true,
      },
    ];




function Loader()
{
    return <h1> Generating Text ...</h1>
}
function Filter()
{
    if(search.includes("#")){
      alert("ERROR")
      return false;
    }
  return true
}
function Loadtrend(){
    if (Filter()==true){
    setSearching(false);
    axios.get('http://localhost:5000/countertrend?myparam='+search)
    .then(res =>{setRecords(res.data)
    setSearching(true);
    console.log("Response =",res)
    }
    );
  }
    //alert(search);
}
    return (
        <>
      <div style={{ width: '50%' }}>
        <TextField
        label="Search Trend"
        color="secondary"
        focused
        inputProps={{ maxLength: 50 }}
        onChange={(e)=>setSearch(e.target.value)}
        fullWidth
      />
      </div>
        
        <br/>
        <Button variant="contained" color="secondary" onClick={Loadtrend}>
        Counter Trend
      </Button>
      <br/>
      <br/>
        
      {searching ? (     <div style={{ height: 500, width: '100%' }}>
      <DataGrid 

      getRowId={(row) => row.ID}
        rows={records}
        columns={columns}
        pageSize={3}
        rowsPerPageOptions={[3]}
        checkboxSelection
        disableSelectionOnClick
      />
    </div> )
        :(<Loader/>)
    }
        </>
        )
}

export default Countertrend;