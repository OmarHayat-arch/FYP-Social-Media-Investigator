
import React, { useState, useEffect, useMemo } from 'react';
import Header from '../datatable/Header';
import {
    CTabPane,
    CNavLink,
    CTabs,
    CNav,
    CNavItem,
    CTabContent
} from '@coreui/react'

import PayerListDatatable from '../datatable/PayerListDatatable';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';

import Claim_a from "src/assets/resource/Claim_a.png"
import Claim from "src/assets/resource/Claim.png"
import ClaimDisable from "src/assets/resource/ClaimDisable.png"

import ClaimStatus_a from "src/assets/resource/ClaimStatus_a.png"
import ClaimStatus_c from "src/assets/resource/ClaimStatus_c.png"
import ClaimStatus_d from "src/assets/resource/ClaimStatus_d.png"

import ERAGrid_c from "src/assets/resource/ERAGrid_c.png"
import ERAGrid_e from "src/assets/resource/ERAGrid_e.png"
import ERAGrid_f from "src/assets/resource/ERAGrid_f.png"

import Eligibility_a from "src/assets/resource/Eligibility_a.png"
import Eligibility from "src/assets/resource/Eligibility.png"
import EligibilityDisable from "src/assets/resource/EligibilityDisable.png"

import UserProfile from 'src/containers/UserProfile';
import progressbar from '../progressbar/progressbar';


const PayerList = () => {


    const [data, setData] = useState();
    const [isLoading, setisLoading] = useState(false);
    const [totalItems, setTotalItems] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");
    const [sorting, setSorting] = useState({ field: "", order: "" });
    const [paginationStatus, setPaginationStatus] = useState();
    const [count, setCount] = useState(0);

    

    const [name, setName] = useState();
    const [id, setId] = useState();
    const [filter, setFilter] = useState();
    let where_condition = "";


    const headers = [
        { name: "Payer Name", field: "payername", sortable: false },
        { name: "Payer ID", field: "payerid", sortable: true },
        { name: "Claims", field: "claim", sortable: true },
        { name: "Claim Status", field: "claimstatus", sortable: false },
        { name: "ERA", field: "era", sortable: false },
        { name: "Eligibility", field: "eligibility", sortable: false },
        { name: "Claims", field: "claim1", sortable: true },
        { name: "Claim Status", field: "claimstatus1", sortable: false },
        { name: "ERA", field: "era1", sortable: false },
        { name: "Eligibility", field: "eligibility1", sortable: false }
    ];

    useEffect(() => {


        async function LoadData() {

            if (UserProfile.getStart() === null && UserProfile.getEnd() === null) {

                UserProfile.setStart(0)
                UserProfile.setEnd(100)

            }
            else {



            }

            if (UserProfile.getPayerListTab() === null) {
                UserProfile.setPayerListTab(1)
            }

            TabData(UserProfile.getPayerListTab())

        }

        LoadData();
    }, [])


    async function TabData(tab) {

        if (tab == 1) {
            UserProfile.setPayerListTab(1)
            setisLoading(false);
            where_condition = "WHERE CATEGORY='MEDICAL'";


        }

        else if (tab == 2) {
            UserProfile.setPayerListTab(2)
            setisLoading(false);
            where_condition = "WHERE CATEGORY='WC'";
        }
        else if (tab == 3) {
            UserProfile.setPayerListTab(3)
            setisLoading(false);
            where_condition = "WHERE CATEGORY ='DENTAL'";
        }


        UserProfile.setPayerName(name);
        UserProfile.setPayerId(id);
        UserProfile.setPayerFilter(filter);

        const url = config.url.API_URL;
        const GetReportURL = url + "/ediportal/api/v1/RequestHandler";
       
        const obj = {
            tag_name: 'PayerList_request',
            parameters: `${UserProfile.getPayerListTab() == 1 ? "MEDICAL" : UserProfile.getPayerListTab() == 2 ? "WC" : UserProfile.getPayerListTab() == 3 ? "DENTAL" : "undefined"}@splitter@${name == "" ? "undefined" : name}@splitter@${id == "" ? "undefined" : id}@splitter@${filter == "" ? "undefined" : filter}@splitter@${UserProfile.getStart()}@splitter@${UserProfile.getEnd()}@splitter@LiveDB`
        }
    
       
       

        const param = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(obj)
        }



        try {

            setName("");
            setId("");
            setFilter("");

            let result = await API_Fetcher(GetReportURL, param);



            UserProfile.setTotal(result.data[0].data.Total)

            setData(result.data[1].data);
            setisLoading(true);
        } catch (error) {

        }

    }



    const handlePagination = useMemo(() => {

        if (UserProfile.getPayerListType() == "P") {
            if (Number(UserProfile.getStart()) == 0) {

            }
            else {


                UserProfile.setStart(Number(UserProfile.getStart()) < 100 ? Number(0) : Number(UserProfile.getStart()) - 100);

                UserProfile.setEnd(Number(UserProfile.getEnd()));
            }

        }
        else if (UserProfile.getPayerListType() == "N") {
            if (Number(UserProfile.getEnd()) >= Number(UserProfile.getTotal())) {

            }
            else {
                UserProfile.setStart(Number(UserProfile.getStart()) + 100);
                UserProfile.setEnd(Number(UserProfile.getEnd()));
            }
        }
        else if (UserProfile.getPayerListType() == "F") {
            UserProfile.setStart(0)
            UserProfile.setEnd(100)
        }
        else if (UserProfile.getPayerListType() == "L") {
            UserProfile.setStart(UserProfile.getTotal() - 100)
            UserProfile.setEnd(UserProfile.getTotal())
        }

        TabData(UserProfile.getPayerListTab());
        return "";
    }, [count])



    return (
        <>


            <CTabs>
                <CNav >
                    <CNavItem>
                        <CNavLink className={UserProfile.getPayerListTab() == 1 ? "custom_tab" : ""} onClick={() => UserProfile.setStart(0) || UserProfile.setEnd(100) || UserProfile.setPayerListType("R") || TabData(1)}>
                            Professional Payer List
                        </CNavLink>

                    </CNavItem>
                    <CNavItem >
                        <CNavLink className={UserProfile.getPayerListTab() == 2 ? "custom_tab" : ""} onClick={() => UserProfile.setStart(0) || UserProfile.setEnd(100) || UserProfile.setPayerListType("R") || TabData(2)}>
                            Worker Comp and No-Fault Payers List
                        </CNavLink>
                    </CNavItem>
                    <CNavItem>
                        <CNavLink className={UserProfile.getPayerListTab() == 3 ? "custom_tab" : ""} onClick={() => UserProfile.setStart(0) || UserProfile.setEnd(100) || UserProfile.setPayerListType("R") || TabData(3)}>
                            Dental Payer List
                        </CNavLink>
                    </CNavItem>
                </CNav>
                <CTabContent>
                    <CTabPane>
                        {isLoading ? <PayerListDatatable PaginationChange={(status) => setCount(status)} SearchByName={(name) => { setName(name) }} SearchById={(id) => { setId(id) }} SearchByFilter={(filter) => { setFilter(filter) }}  result={data} headers={headers} /> : progressbar(2)}
                    </CTabPane>
                    <CTabPane>
                        {isLoading ? <PayerListDatatable PaginationChange={(status) => setCount(status)} SearchByName={(name) => { setName(name) }} SearchById={(id) => { setId(id) }} SearchByFilter={(filter) => { setFilter(filter) }} result={data} headers={headers} /> : progressbar(2)}
                    </CTabPane>
                    <CTabPane>
                        {isLoading ? <PayerListDatatable PaginationChange={(status) => setCount(status)} SearchByName={(name) => { setName(name) }} SearchById={(id) => { setId(id) }} SearchByFilter={(filter) => { setFilter(filter) }} result={data} headers={headers} /> : progressbar(2)}
                    </CTabPane>

                </CTabContent>
            </CTabs>



        </>
    )
}


export default PayerList;