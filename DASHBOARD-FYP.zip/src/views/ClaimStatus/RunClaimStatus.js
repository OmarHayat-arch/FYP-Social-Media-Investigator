import React, { useState } from 'react';
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CSwitch
} from '@coreui/react'
import moment from 'moment';

const RunClaimStatus = () => {

    const [Payer, setPayer] = useState();
    const [PayerId, setPayerId] = useState();
    const [ClaimChargeAmount, setClaimChargeAmount] = useState();
    const [InsuredId, setInsuredId] = useState();
    const [InsuredFirstName, setInsuredFirstName] = useState();
    const [InsuredLastName, setInsuredLastName] = useState();
    const [InsuredDOB, setInsuredDOB] = useState();
    const [InsuredSex, setInsuredSex] = useState();
    const [DOS, setDOS] = useState(new Date);
    const [ProviderNPI, setProviderNPI] = useState();
    const [ProviderFirstName, setProviderFirstName] = useState();
    const [ProviderLastName, setProviderLastName] = useState();


    return (
        <>
            <CRow >
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardBody>
                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <label className="custom_label mandatory" htmlFor="date-input" >Payer</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CSelect onChange={(e) => setPayer(e.target.value)} custom name="select" id="common">
                                                <option value="">- SELECT -</option>
                                                <option value="PAYER REJECTED">PAYER REJECTED</option>
                                                <option value="PRACTICEEHR REJECTED">PRACTICEEHR REJECTED</option>
                                            </CSelect>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label mandatory" htmlFor="date-input">Payer ID</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setPayerId(e.target.value)} type="text" placeholder="Payer ID" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label mandatory" htmlFor="date-input">Claim Charge Amount</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setClaimChargeAmount(e.target.value)} type="text" placeholder="Claim Charge Amount" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                            </CRow>


                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Insured ID</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setInsuredId(e.target.value)} type="text" placeholder="Insured ID" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label mandatory" htmlFor="date-input">Insured First Name</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setInsuredFirstName(e.target.value)} type="text" placeholder="Insured First Name" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label mandatory" htmlFor="date-input">Insured Last Name</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setInsuredLastName(e.target.value)} type="text" placeholder="Insured Last Name" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                            </CRow>


                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Insured DOB</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()} value={InsuredDOB == undefined ? "" : moment(InsuredDOB).format('YYYY-MM-DD')} onChange={(e) => setInsuredDOB(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="Insured DOB" />
                                            <div class="divider"></div>
                                            {InsuredDOB == undefined ? "" : <button onClick={() => { setInsuredDOB(undefined) }} className="custom_clear">X</button>}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Insured Sex</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CFormGroup variant="checkbox" className="customCheckbox">
                                                <CInputRadio onClick={()=> setInsuredSex("Male")} checked={InsuredSex == "Male"} className="form-check-input" id="radio1" name="radios" value="Male" />
                                                <CLabel variant="checkbox" htmlFor="radio1">Male</CLabel>
                                            </CFormGroup>
                                            <CFormGroup variant="checkbox" className="customCheckbox">
                                                <CInputRadio onClick={()=> setInsuredSex("Female")} checked={InsuredSex == "Female"} className="form-check-input" id="radio2" name="radios" value="Female" />
                                                <CLabel variant="checkbox" htmlFor="radio2">Female</CLabel>
                                            </CFormGroup>
                                            {/* <CInput onChange={(e) => setInsuredLastName(e.target.value)} type="text" placeholder="Insured First Name" /> */}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label mandatory" htmlFor="date-input">DOS</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CInput onKeyDown={(e) => e.preventDefault()} value={DOS == undefined ? "" : moment(DOS).format('YYYY-MM-DD')} onChange={(e) => setDOS(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="DOS" />
                                            <div class="divider"></div>
                                            {DOS == undefined ? "" : <button onClick={() => { setDOS(undefined) }} className="custom_clear">X</button>}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                            </CRow>


                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label mandatory" htmlFor="date-input">Provider NPI</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setProviderNPI(e.target.value)} type="text" placeholder="Provider NPI" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Provider First Name</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setProviderFirstName(e.target.value)} type="text" placeholder="Provider First Name" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label mandatory" htmlFor="date-input">Provider Last Name</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setProviderLastName(e.target.value)} type="text" placeholder="Provider Last Name" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                            </CRow>

                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">

                                        </CCol>
                                        <CCol xs="12" md="9" className="form">

                                        </CCol>


                                    </CFormGroup>
                                </CCol>


                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">

                                        </CCol>
                                        <CCol xs="12" md="9" className="form">

                                        </CCol>


                                    </CFormGroup>
                                </CCol>




                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">

                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CButton type="submit" color="primary" className="custom_button col-md-12">Submit</CButton>

                                        </CCol>


                                    </CFormGroup>
                                </CCol>

                            </CRow>
                            <CRow>


                            </CRow>
                            <CRow>
                            </CRow>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    )
}

export default RunClaimStatus;