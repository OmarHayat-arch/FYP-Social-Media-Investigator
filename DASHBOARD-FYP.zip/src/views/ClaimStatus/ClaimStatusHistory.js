import React, { useState } from 'react';
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CSwitch
} from '@coreui/react'
import moment from 'moment';
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';
import API_Fetcher from 'src/containers/API_Fetcher';
import { config } from 'src/containers/API_Call_Constant';
import progressbar from '../progressbar/progressbar';
import UserProfile from 'src/containers/UserProfile';
import ClaimStatusHistoryDatatable from '../datatable/ClaimStatusHistoryDatatable';


const customized_col_names = ["First Name", "Last Name", "Provider Claim #", "Payer", "Rendering Provider", "DOS", "Status Code", "Description", "Status Date", "",];
const customized_col_index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
const cells = ["ProviderNum"]

const ClaimStatusHistory = () => {

    const [ClaimDateFrom, setClaimDateFrom] = useState();
    const [ClaimDateTo, setClaimDateTo] = useState();
    const [ProviderClaimNum, setProviderClaimNum] = useState();
    const [PatientLastName, setPatientLastName] = useState();
    const [PatientFirstName, setPatientFirstName] = useState();
    const [Status, setStatus] = useState("ALL");
    const [DOSFrom, setDOSFrom] = useState();
    const [DOSTo, setDOSTo] = useState();
    const [open, setOpen] = useState(false);
    const [isLoading,setLoading] = useState(false);
    const [data, setData] = useState();
   

const handleClose = () => {
    setOpen(false);
  };
  const handleToggle = () => {
    setOpen(!open);
  };

  const useStyles = makeStyles((theme) => ({
    backdrop: {
      zIndex: theme.zIndex.drawer + 1,
      color: '#fff',
    },
  }));

  const classes = useStyles();

async function HandleSearch(){
    handleToggle();
const url = config.url.API_URL;
const GetReportURL = url +"/ediportal/api/v1/RequestHandler";

const obj = {
  tag_name: 'ClaimStatusHistory_request',
  parameters: `${UserProfile.getSeqnum()}@splitter@${ClaimDateFrom}@splitter@${ClaimDateTo}@splitter@${ProviderClaimNum}@splitter@${PatientLastName}@splitter@${PatientFirstName}@splitter@${Status}@splitter@${DOSFrom}@splitter@${DOSTo}@splitter@LiveDB`
}

const param = {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(obj)
}

try {
let { status, data } = await API_Fetcher(GetReportURL, param)


setData(data[0]);
setLoading(true);
setOpen(false);

} catch (error) {
}

}

    



    return (
        <>


            <CRow id="ClaimStatusHistoryFilter">
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardBody>
                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <label className="custom_label" htmlFor="date-input" >Claim Status Date From</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CInput onKeyDown={(e) => e.preventDefault()} value={ClaimDateFrom == undefined ? "" : moment(ClaimDateFrom).format('YYYY-MM-DD')} onChange={(e) => setClaimDateFrom(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="Claim Status Date From" />
                                            <div class="divider"></div>
                                            {ClaimDateFrom == undefined ? "" : <button onClick={() => { setClaimDateFrom(undefined) }} className="custom_clear">X</button>}
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Claim Status Date To</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CInput onKeyDown={(e) => e.preventDefault()} value={ClaimDateTo == undefined ? "" : moment(ClaimDateTo).format('YYYY-MM-DD')} onChange={(e) => setClaimDateTo(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="Claim Status Date To" />
                                            <div class="divider"></div>
                                            {ClaimDateTo == undefined ? "" : <button onClick={() => { setClaimDateTo(undefined) }} className="custom_clear">X</button>}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Provider Claim #</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setProviderClaimNum(e.target.value)} type="text" placeholder="Provider Claim Number" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                            </CRow>


                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Patient last Name</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setPatientLastName(e.target.value)} type="text" placeholder="Patient Last Name" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Patient First Name</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setPatientFirstName(e.target.value)} type="text" placeholder="Patient First Name" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Status</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CSelect onChange={(e) => setStatus(e.target.value)} custom name="select" id="common">
                                                <option value="ALL">ALL</option>
                                                <option value="PAYER REJECTED">PAYER REJECTED</option>
                                                <option value="PRACTICEEHR REJECTED">PRACTICEEHR REJECTED</option>
                                            </CSelect>

                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                            </CRow>


                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">DOS From</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()} value={DOSFrom == undefined ? "" : moment(DOSFrom).format('YYYY-MM-DD')} onChange={(e) => setDOSFrom(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="DOS From" />
                                            <div class="divider"></div>
                                            {DOSFrom == undefined ? "" : <button onClick={() => { setDOSFrom(undefined) }} className="custom_clear">X</button>}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">DOS To</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CInput onKeyDown={(e) => e.preventDefault()} value={DOSTo == undefined ? "" : moment(DOSTo).format('YYYY-MM-DD')} onChange={(e) => setDOSTo(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="DOS To" />
                                            <div class="divider"></div>
                                            {DOSTo == undefined ? "" : <button onClick={() => { setDOSTo(undefined) }} className="custom_clear">X</button>}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                               

                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">

                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CButton type="submit" onClick={()=>{HandleSearch()}} color="primary" className="custom_button col-md-12">Search</CButton>
                                            {open && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>}
                                        </CCol>


                                    </CFormGroup>
                                </CCol>
                            </CRow>

                       </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            {isLoading ? <ClaimStatusHistoryDatatable result={data} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}
        </>
    )
}

export default ClaimStatusHistory;