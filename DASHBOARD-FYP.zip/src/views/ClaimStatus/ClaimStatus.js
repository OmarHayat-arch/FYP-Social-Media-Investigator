import React from 'react';
import {
    CButton,
    CCreateElement,
    CCard,
    CCardBody,
    CLabel,
    CCardGroup,
    CCol,
    CContainer,
    CForm,
    CInput,
    CInputGroup,
    CCardHeader,
    CModal,
    CModalHeader,
    CModalTitle,
    CModalBody,
    CModalFooter,
    CInputGroupPrepend,
    CInputGroupText,
    CValidFeedback,
    CInvalidFeedback,
    CRow,
    CTabPane,
    CNavLink,
    CTabs,
    CNav,
    CNavItem,
    CTabContent,
    CSidebarNavDivider,
    CSidebarNavDropdown,
    CSidebarNavItem,
    CSidebarNavTitle
} from '@coreui/react'
import RunClaimStatus from './RunClaimStatus';
import ClaimStatusHistory from './ClaimStatusHistory';

function ClaimStatus() {

    return (
        <>
            <CTabs>
                <CNav id="ClaimStatusTab">
                    <CNavItem >
                        <CNavLink >
                            Run Claim Status
                        </CNavLink>
                    </CNavItem>
                    <CNavItem >
                        <CNavLink >
                            Claim Status
                        </CNavLink>
                    </CNavItem>

                </CNav>
                <CTabContent>
                    <CTabPane>

                        <RunClaimStatus />

                    </CTabPane>
                    <CTabPane>
                        <ClaimStatusHistory />


                    </CTabPane>

                </CTabContent>
            </CTabs>
        </>
    )
}

export default ClaimStatus