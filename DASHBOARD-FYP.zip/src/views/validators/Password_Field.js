import React, { useState } from 'react'
import {
    CInput,
    CInvalidFeedback,
    CValidFeedback
} from '@coreui/react'
function Password_Field(props) {

    const [decide_passwordfield, setDecidePasswordField] = useState()

    const handlePasswordField = (e) => {
        props.onChangePassword(e);
    
        if (e == "" || e == undefined) {
    
            setDecidePasswordField("is-invalid");
        }
        else {
            setDecidePasswordField("is-valid");
        }
    }
    return (
        <>
            <CInput
                className={decide_passwordfield}
                type="password" placeholder={props.placeholder} autoComplete="one-time-code" onChange={(e) => { handlePasswordField(e.target.value) }}

            />
           <CInvalidFeedback >{props.invalid_msg}</CInvalidFeedback>
            <CValidFeedback >{props.valid_msg}</CValidFeedback>
        </>
    )
}

export default Password_Field
