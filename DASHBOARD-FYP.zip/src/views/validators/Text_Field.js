import React, { useState } from 'react'
import {
    CInput,
    CInvalidFeedback,
    CValidFeedback
} from '@coreui/react'
function Text_Field(props) {

    const [decide_textfield, setDecideTextField] = useState()


    const handleTextField = (e) => {
        props.onChangeText(e);

        if (e == "" || e == undefined) {
            setDecideTextField("is-invalid");
        }
        else {

            setDecideTextField("is-valid");
        }
    }


    return (
        <>
            <CInput
                 id="text_field"
                 value={props.value}
                className={decide_textfield}
                type="text" placeholder={props.placeholder} autoComplete="one-time-code" onChange={(e) => { handleTextField(e.target.value) }}


            />
            <CInvalidFeedback >{props.invalid_msg}</CInvalidFeedback>
            <CValidFeedback >{props.valid_msg}</CValidFeedback>
        </>
    )
}

export default Text_Field
