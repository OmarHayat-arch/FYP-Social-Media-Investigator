import React,{useState,useEffect} from 'react';
import {
    CBadge,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CRow,
    CCollapse,
    CFormGroup,
    CFade,
    CLabel,
    CSwitch,
    CLink
} from '@coreui/react'
import Payer_Billing_ProviderBAL from './Payer_Billing_ProviderBAL';
import FieldsController from '../validators/FieldsController';
import Label_Field from '../validators/Label_Field';

const Subscriber_Patient = (props) => {

    useEffect(() => {

    }, [props])


    return (
        <>
            <CRow>
    
                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="Subscriber Information" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(0, 8).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>




                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(8, 16).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>


                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(16, 24).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

            </CRow>


            <CRow>
    
    <CCol xs="12" sm="6" md="4">
        <CCard style={{ border: "none" }}>
            <CCardBody>
            <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                <Label_Field name="Patient Information" visibility="labelbold text-left" />
            </CCol>
                <CFormGroup row>
                    { props.result.slice(24, 32).map((e, index) => {
                        return (
                            <CCol md={index % 2 == 0 ? "3" : "9"}>
                                <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                              
                            </CCol>
                        );

                    })}
                </CFormGroup>
            </CCardBody>
        </CCard>
    </CCol>




     <CCol xs="12" sm="6" md="4">
        <CCard style={{ border: "none" }}>
            <CCardBody>
            <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                <Label_Field name="" visibility="labelbold text-left" />
            </CCol>
                <CFormGroup row>
                    { props.result.slice(32, 38).map((e, index) => {
                        return (
                            <CCol md={index % 2 == 0 ? "3" : "9"}>
                                <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                              
                            </CCol>
                        );

                    })}
                </CFormGroup>
            </CCardBody>
        </CCard>
    </CCol>


    <CCol xs="12" sm="6" md="4">
        <CCard style={{ border: "none" }}>
            <CCardBody>
            <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                <Label_Field name="" visibility="labelbold text-left" />
            </CCol>
                <CFormGroup row>
                    { props.result.slice(38, 44).map((e, index) => {
                        return (
                            <CCol md={index % 2 == 0 ? "3" : "9"}>
                                <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                              
                            </CCol>
                        );

                    })}
                </CFormGroup>
            </CCardBody>
        </CCard>
    </CCol> 

</CRow>


        </>
    )
}

export default Subscriber_Patient;