import React, { useState, useEffect } from 'react';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';


const Additional_Provider_FacilityBAL = (props) => {



    const Pin_Qualifier = [{ data: [
        { DISPLAY_VALUE: "--Select--", VALUE: "0" },
        { DISPLAY_VALUE: "State License Number", VALUE: "0B" }, 
        { DISPLAY_VALUE: "UPIN Number", VALUE: "1G" },
        { DISPLAY_VALUE: "Provider Commercial Number", VALUE: "G2" },
        { DISPLAY_VALUE: "Location Number", VALUE: "LU" },
    ] }];

    const obj = [
        {
            "type": "label",
            "name": "Lab/Facility Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm103LocOrganization) ? props.Nm103LocOrganization : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"60"
        },
        {
            "type": "label",
            "name": "City",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N401LocCity) ? props.N401LocCity : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"30"
        },
        {
            "type": "label",
            "name": "NPI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm109LocNpi) ? props.Nm109LocNpi : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"10"
        },
        {
            "type": "label",
            "name": "State",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N402LocState) ? props.N402LocState : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"2"
        },
        {
            "type": "label",
            "name": "Address",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N301LocAddress1) ? props.N301LocAddress1 : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"50"
        },
        {
            "type": "label",
            "name": "Zip Code",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N403LocZip) ? props.N403LocZip : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"9"
        },
        {
            "type": "label",
            "name": "Entity Type",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.RendEntityType) ? props.RendEntityType : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"10"
        },
        {
            "type": "label",
            "name": "MI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm105RendMi) ? props.Nm105RendMi : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"1"
        },
        {
            "type": "label",
            "name": "PIN Qualifier",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.PinQual) ? props.PinQual : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            "values":Pin_Qualifier
        },
        {
            "type": "label",
            "name": "Last Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm103RendLastName) ? props.Nm103RendLastName : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"60"
        },
        {
            "type": "label",
            "name": "NPI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm109RendNpi) ? props.Nm109RendNpi : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"10"
        },
        {
            "type": "label",
            "name": "Pin",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.PinNum) ? props.PinNum : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"50"
        },
        {
            "type": "label",
            "name": "First Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm104RendFirstName) ? props.Nm104RendFirstName : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"35"
        },
        {
            "type": "label",
            "name": "Last Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm103ReferrLastName) ? props.Nm103ReferrLastName : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"60"
        },
        {
            "type": "label",
            "name": "NPI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm109ReferrNpi) ? props.Nm109ReferrNpi : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"10"
        },
        {
            "type": "label",
            "name": "First Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm104ReferrFirstName) ? props.Nm104ReferrFirstName : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"35"
        },
        {
            "type": "label",
            "name": "MI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm105ReferrMi) ? props.Nm105ReferrMi : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"1"
        },
        {
            "type": "label",
            "name": "Last Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm103SupervLastName) ? props.Nm103SupervLastName : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"60"
        },
        {
            "type": "label",
            "name": "NPI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm109SupervNpi) ? props.Nm109SupervNpi : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"10"
        },
        {
            "type": "label",
            "name": "First Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm104SupervFirstName) ? props.Nm104SupervFirstName : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"35"
        },
        {
            "type": "label",
            "name": "MI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm105SupervMi) ? props.Nm105SupervMi : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"1"
        },
     
    ]

    return obj;

}

export default Additional_Provider_FacilityBAL;


