import React, { useState, useEffect } from 'react';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';


const Payer_Billing_ProviderBAL = (props) => {



    const Claim_Flag = [{ data: [
    { DISPLAY_VALUE: "Other Non-Federal Programs", VALUE: "11" }, 
    { DISPLAY_VALUE: "Preferred Provider Organization (PPO)", VALUE: "12" },
    { DISPLAY_VALUE: "Point of Service (POS)", VALUE: "13" },
    { DISPLAY_VALUE: "Exclusive Provider Organization (EPO)", VALUE: "14" },
    { DISPLAY_VALUE: "Indemnity Insurance", VALUE: "15" },
    { DISPLAY_VALUE: "Health Maintenance Organization (HMO) Medicare Risk", VALUE: "16" },
    { DISPLAY_VALUE: "Dental Maintenance Organization", VALUE: "17" },
    { DISPLAY_VALUE: "Automobile Medical", VALUE: "AM" },
    { DISPLAY_VALUE: "Blue Cross/Blue Shield", VALUE: "BL" },
    { DISPLAY_VALUE: "Champus", VALUE: "CH" },
    { DISPLAY_VALUE: "Commercial Insurance Co.", VALUE: "CI" },
    { DISPLAY_VALUE: "Disability", VALUE: "DS" },
    { DISPLAY_VALUE: "Federal Employees Program", VALUE: "FI" },
    { DISPLAY_VALUE: "Health Maintenance Organization", VALUE: "HM" },
    { DISPLAY_VALUE: "Liability Medical", VALUE: "LM" },
    { DISPLAY_VALUE: "Medicare Part A", VALUE: "MA" },
    { DISPLAY_VALUE: "Medicare Part B", VALUE: "MB" },
    { DISPLAY_VALUE: "Medicaid", VALUE: "MC" },
    { DISPLAY_VALUE: "Other Federal Program", VALUE: "OF" },
    { DISPLAY_VALUE: "Title V", VALUE: "TV" },
    { DISPLAY_VALUE: "Veterans Affairs Plan", VALUE: "VA" },
    { DISPLAY_VALUE: "Workers’ Compensation Health Claim", VALUE: "WC" },
    { DISPLAY_VALUE: "Mutually Defined", VALUE: "ZZ" },


] }];


const Insurance_Type = [{ data: [
    { DISPLAY_VALUE: "--Select--", VALUE: "" },
    { DISPLAY_VALUE: "Worked Aged Beneficiary", VALUE: "12" }, 
    { DISPLAY_VALUE: "End Stage Renel Disease", VALUE: "13" },
    { DISPLAY_VALUE: "No Fault Insurance", VALUE: "14" },
    { DISPLAY_VALUE: "Worker Comp", VALUE: "15" },
    { DISPLAY_VALUE: "Public Health Service", VALUE: "16" },
    { DISPLAY_VALUE: "Black Lung", VALUE: "41" },
    { DISPLAY_VALUE: "Veterans Administration", VALUE: "42" },
    { DISPLAY_VALUE: "Under Age 65 LGHP", VALUE: "43" },
    { DISPLAY_VALUE: "Other Liability Insurance is Primary", VALUE: "47" },
] }];


const TAX_ID_TYPE = [{ data: [
    { DISPLAY_VALUE: "" , VALUE: "" },
    { DISPLAY_VALUE: "EIN", VALUE: "EIN" }, 
    { DISPLAY_VALUE: "SSN", VALUE: "SSN" },
] }];



    const obj = [
        {
            "type": "label",
            "name": "Payer ID",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm109PrId) ? props.Nm109PrId : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"80"
        },
        {
            "type": "label",
            "name": "Claim Flag",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Sbr09ClaimInd) ? props.Sbr09ClaimInd : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "values": Claim_Flag,
            
        },
        {
            "type": "label",
            "name": "Status",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N402PrState) ? props.N402PrState : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"2"
        },
        {
            "type": "label",
            "name": "Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm103PrOrgName) ? props.Nm103PrOrgName : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"60"
        },
        {
            "type": "label",
            "name": "Address",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N301PrAddress1) ? props.N301PrAddress1 : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"55"
        },
        {
            "type": "label",
            "name": "Zip Code",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N403PrZipCode) ? props.N403PrZipCode : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"9"
        },
        {
            "type": "label",
            "name": "Sequence",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Sbr01PayerSequence) ? props.Sbr01PayerSequence : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":""
        },
        {
            "type": "label",
            "name": "City",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N401PrCity) ? props.N401PrCity : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"30"
        },
        {
            "type": "label",
            "name": "Insurance Type",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": "",//(props.SBR_05_INS_TYPE_CODE) ? props.SBR_05_INS_TYPE_CODE : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"",
            "values": Insurance_Type,
        },
        {
            "type": "label",
            "name": "NPI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm109BillingNpiCode) ? props.Nm109BillingNpiCode : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"10"
        },
        {
            "type": "label",
            "name": "Provider Type",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.BillProviderType) ? props.BillProviderType : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":""
        },
        {
            "type": "label",
            "name": "First Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm104BillingFirstName) ? props.Nm104BillingFirstName : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"35"
        },
        {
            "type": "label",
            "name": "City",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N401BillCity) ? props.N401BillCity : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"30"
        },
        {
            "type": "label",
            "name": "Tax ID Type",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.TaxIdType) ? props.TaxIdType : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"",
            "values":TAX_ID_TYPE
        },
        {
            "type": "label",
            "name": "Taxonomy",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Taxonomy) ? props.Taxonomy : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"50"
        },
        {
            "type": "label",
            "name": "MI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm105BillingMiddleInitial) ? props.Nm105BillingMiddleInitial : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"1"
        },
        {
            "type": "label",
            "name": "State",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N402BillState) ? props.N402BillState : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"2"
        },
        {
            "type": "label",
            "name": "Tax ID",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.TaxId) ? props.TaxId : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"9"
        },
        {
            "type": "label",
            "name": "Organization Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm103BillingLastOrgName) ? props.Nm103BillingLastOrgName : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"60"
        },
        {
            "type": "label",
            "name": "Address",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N301BillAddress1) ? props.N301BillAddress1 : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"55"
        },
        {
            "type": "label",
            "name": "Zip Code",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N403BillZipCode) ? props.N403BillZipCode : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"9"
        },
        {
            "type": "label",
            "name": "Address",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N301PaytoPrvAddress1) ? props.N301PaytoPrvAddress1 : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"55"
        },
        {
            "type": "label",
            "name": "Zip Code",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N403PaytoPrvZipCode) ? props.N403PaytoPrvZipCode : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"9"
        },
        {
            "type": "label",
            "name": "City",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N401PaytoPrvCity) ? props.N401PaytoPrvCity : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"30"
        },
        {
            "type": "label",
            "name": "State",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N402PaytoPrvState) ? props.N402PaytoPrvState : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"2"
        },

    ]

    return obj;

}

export default Payer_Billing_ProviderBAL;


