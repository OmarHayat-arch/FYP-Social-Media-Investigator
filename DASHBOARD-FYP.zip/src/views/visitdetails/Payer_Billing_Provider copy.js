import React,{useState,useEffect} from 'react';
import {
    CBadge,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CRow,
    CCollapse,
    CFormGroup,
    CFade,
    CLabel,
    CSwitch,
    CLink
} from '@coreui/react'
import Payer_Billing_ProviderBAL from './Payer_Billing_ProviderBAL';
import FieldsController from '../validators/FieldsController';

const Payer_Billing_Provider = (props) => {

    console.log("billing")
   
  
    const [obj, setObj] = useState([]);
    const [isLoading, setLoading] = useState(false);

    useEffect(() => {

        const result = Payer_Billing_ProviderBAL(props.result[1].data[0]);

        setObj(result);
        setLoading(true);

    }, [props])


    return (
        <>
            <CRow>
                <CCol xs="12" sm="6" md="6">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CFormGroup row>
                                {isLoading ? obj.slice(0, 12).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "4" : "6"}>
                                            <FieldsController  values={e.values} disabled={e.disabled} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                            {/* <Label_Field color={e.color} name={e.name} visibility={e.visibility} ></Label_Field> */}
                                        </CCol>
                                    );

                                }) : ""}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    )
}

export default Payer_Billing_Provider;