import React from 'react';
import {
    CButton,
    CCard,
    CCardBody,
    CTabPane,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CNavLink,
    CTabContent,
    CNavItem,
    CNav,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CTabs,
    CSwitch
} from '@coreui/react'
import Followup from './Followup';



function FollowupDetail(props) {



    return (
        <>
            <CRow>
                <CCol xs="12" sm="12" lg="12">
                    <CCard>

                        <CCardBody >

                            <CTabs>
                                <CNav >
                                    <CNavItem>
                                        <CNavLink >
                                            Followup
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem >
                                        <CNavLink >
                                            Documents
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Elect EOB
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Appeal
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            History
                                        </CNavLink>
                                    </CNavItem>

                                </CNav>
                                <CTabContent>
                                    <CTabPane>

                                     <Followup result = {props}/>

                                    </CTabPane>
                                    <CTabPane>

                                    <CLabel className="followup_header" htmlFor="select">Documents</CLabel>

                                    </CTabPane>
                                    <CTabPane>

                                    <CLabel className="followup_header" htmlFor="select">Elect EOB</CLabel>
                                    </CTabPane>
                                    <CTabPane>
                                    <CLabel className="followup_header" htmlFor="select">Appeal</CLabel>

                                    </CTabPane>
                                    <CTabPane>
                                    <CLabel className="followup_header" htmlFor="select">History</CLabel>

                                    </CTabPane>
                                    <CTabPane>


                                    </CTabPane>
                                    <CTabPane>


                                    </CTabPane>
                                    <CTabPane>


                                    </CTabPane>
                                </CTabContent>
                            </CTabs>

                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>


        </>
    )
}


export default FollowupDetail;