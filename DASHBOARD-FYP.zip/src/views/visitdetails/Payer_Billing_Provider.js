import React,{useState,useEffect} from 'react';
import {
    CBadge,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CRow,
    CCollapse,
    CFormGroup,
    CFade,
    CLabel,
    CSwitch,
    CLink
} from '@coreui/react'
import Payer_Billing_ProviderBAL from './Payer_Billing_ProviderBAL';
import FieldsController from '../validators/FieldsController';
import Label_Field from '../validators/Label_Field';

const Payer_Billing_Provider = (props) => {



    useEffect(() => {

       

    }, [props])


    return (
        <>
            <CRow>
            <CCol md="12" className="text-right" style={{  color: "#D35E59" }}>
                            <Label_Field name=" * Note: Changes to this section will not reflect in Electronic Practice Management
                                solution." visibility="labelbold text-left" />
                        </CCol>
                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="Payer Information" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(0, 6).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>




                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(6, 12).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>


                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(12, 18).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

            </CRow>


            <CRow>
                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="Billing Provider Information" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(18, 26).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>




               <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(26, 34).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>
  

                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(34, 42).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                            </CCol>

            </CRow>



            <CRow>
                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="Pay-To Provider" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(42, 46).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>




               <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(46, 48).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>
  

                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(48, 50).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                            </CCol>

            </CRow>


        </>
    )
}

export default Payer_Billing_Provider;