import React from 'react';

const ShowPaymentDetail = (props) => {


  console.log(Array.isArray(props.res.NewDataSet.GLOSSARY));

  return (
    <div style={{font: '"Open Sans",sans-serif', fontSize: '11px', lineHeight: '10px', width: '900px', marginLeft: 'auto', marginRight: 'auto'}}>
      {/* {JSON.parse(props.res.NewDataSet.ROOT).map((obj) => {
        console.log(obj)
        return (

          <>
          </>
        )})} */}
            <table  style={{ backgroundColor: '#b7c8e1', lineHeight: '10px', fontSize: '11px', width: '900px', height: '40px' }} border={0}>{/*<tr style="background-color:#3b4e87; color:#ffffff;">*/}
              <tbody>
                <tr style={{ height: '20px' }}>
                  <td style={{ borderRight: '1px solid #99a1aa', height: '20px', width: '78.6562px' }}><strong>REND-PROV</strong></td>
                  <td style={{ borderRight: '1px solid #99a1aa', height: '20px', width: '62.9531px' }}>{/*<div style="margin-left:3px;">*/} <strong>SERV-DATE</strong> {/*</div>*/}</td>
                  <td style={{ borderRight: '1px solid #99a1aa', height: '20px', width: '62.9531px' }}><strong>POS</strong></td>
                  <td style={{ borderRight: '1px solid #99a1aa', height: '20px', width: '104.438px' }}><strong>PD-PROC/MODS</strong></td>
                  <td style={{ borderRight: '1px solid #99a1aa', height: '20px', width: '49.3594px' }}><strong>PD-NOS</strong></td>
                  <td style={{ borderRight: '1px solid #99a1aa', height: '20px', width: '114.234px' }}><strong>BILLED</strong></td>
                  <td style={{ borderRight: '1px solid #99a1aa', height: '20px', width: '123.656px' }}><strong>ALLOWED</strong></td>
                  <td style={{ borderRight: '1px solid #99a1aa', height: '20px', width: '97.4844px' }}><strong>DEDUCT</strong></td>
                  <td style={{ borderRight: '1px solid #99a1aa', height: '20px', width: '89.125px' }}><strong>COINS</strong></td>
                  <td style={{ height: '20px', width: '53.1406px' }}><strong>PROV-PD</strong></td>
                </tr>
                <tr style={{ height: '20px' }}>
                  <td style={{ height: '20px', width: '327px' }} colSpan={4}>RARC</td>
                  <td style={{ height: '20px', width: '49.3594px' }}>SUB-NOS</td>
                  <td style={{ height: '20px', width: '114.234px' }}>SUB-PROC</td>
                  <td style={{ height: '20px', width: '123.656px' }}>GRP/CARC</td>
                  <td style={{ height: '20px', width: '97.4844px' }}>CARC-AMT</td>
                  <td style={{ height: '20px', width: '148.266px' }} colSpan={2}>ADJ-QTY</td>
                  {/*<td style="padding-left:20px">BS</td>*/}</tr>
              </tbody>
            </table>
            <table style={{ font: '"Open Sans",sans-serif', fontSize: '11px', lineHeight: '10px', width: '900px' }} border={0}>
              <tbody>
                <tr style={{ backgroundColor: '#ffffff', color: '#000000' }}>
                  <td colSpan={10}><hr /></td>
                </tr>
                <tr style={{ backgroundColor: '#e4e8f3', color: '#000000' }}>
                  {/* {props.res.ROOT.length == 0 ? "" : props.res.ROOT[0].PayerName} */}
                  {/* <td colSpan={3}><strong>NAME</strong>:&nbsp;{obj.ROOT.CLAIM_RECORD.PatientName}</td>
                  <td><strong>HIC</strong>:&nbsp;{obj.ROOT.CLAIM_RECORD.PolicyNum}</td>
                  <td colSpan={2}><strong>ACNT</strong>:&nbsp;{obj.ROOT.CLAIM_RECORD.Clp01ClaimNum}</td>
                  <td><strong>ICN</strong>:&nbsp;{obj.ROOT.CLAIM_RECORD.InsClaimNum}</td>
                  <td colSpan={3}><strong>ASG</strong>:&nbsp;{obj.ROOT.CLAIM_RECORD.Asg}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>MOA</strong>:&nbsp;{obj.ROOT.CLAIM_RECORD.Moa}</td>
                 */}
                 </tr>

                {/* {props.res.NewDataSet.ROOT.map((obj) => {

                  return (

                    <>
                      <tr style={{ backgroundColor: '#ffffff', color: '#000000', border: '!important' }}>
                        <td width="83px">&nbsp;{obj.CLAIM_RECORD.CHARGE_RECORD.RendNpi}</td>
                        <td width="60px">{obj.CLAIM_RECORD.CHARGE_RECORD.DosFrom} &nbsp;&nbsp;&nbsp;{obj.CLAIM_RECORD.CHARGE_RECORD.DosTo} </td>
                        <td width="60px">&nbsp;</td>
                        <td width="88px">&nbsp;{obj.CLAIM_RECORD.CHARGE_RECORD.CptMod}</td>
                        <td width="89px">&nbsp;{obj.CLAIM_RECORD.CHARGE_RECORD.PaidUnits}</td>
                        <td width="109px"> {obj.CLAIM_RECORD.CHARGE_RECORD.ChargeAmt}</td>
                        <td width="118px"> {obj.CLAIM_RECORD.CHARGE_RECORD.AllowedAmt}</td>
                        <td width="93px">{obj.CLAIM_RECORD.CHARGE_RECORD.Deduct}</td>
                        <td width="85px"> {obj.CLAIM_RECORD.CHARGE_RECORD.Coins}</td>
                        <td width="50px"> {obj.CLAIM_RECORD.CHARGE_RECORD.PaidAmt}</td>
                      </tr>
                      <tr>
                        <td width="83px">&nbsp; {obj.CLAIM_RECORD.CHARGE_RECORD.RemarkCode}</td>
                        <td>
                          <div style={{ verticalAlign: 'text-bottom' }}><strong>CNTL</strong>:&nbsp;#:&nbsp;: {obj.CLAIM_RECORD.CHARGE_RECORD.ChargeRef6r}</div>
                        </td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>

                        <td style={{ backgroundColor: '#c0c0c0' }}>
                          {props.res.NewDataSet.ROOT.map((obj) => {

                            return (

                              <>
                            {obj.CLAIM_RECORD.CHARGE_RECORD.REMIT_CODE.ADJ_CODE} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {obj.CLAIM_RECORD.CHARGE_RECORD.REMIT_CODE.ADJ_AMT} <br />
                              </>
                            )
                          })}
                        </td>


                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>

                    </>
                  )
                })}
                <tr style={{ backgroundColor: '#ffffff', color: '#000000', border: '!important' }}>
                  <td>&nbsp;</td>
                  <td colSpan={2}> <strong>PT RESP</strong>&nbsp;&nbsp;&nbsp; {obj.CLAIM_RECORD.PatResp} </td>
                  <td>CARC&nbsp;&nbsp; {obj.CLAIM_RECORD.TotalAdjustmentAmt}</td>
                  
                  <td colSpan={2}><strong>CLAIM TOTALS</strong>&nbsp;&nbsp; {obj.CLAIM_RECORD.TotalBilled}</td>

                  <td> {obj.CLAIM_RECORD.TotalAllowed}</td>
                  <td> {obj.CLAIM_RECORD.TotalDed}</td>
                  <td> {obj.CLAIM_RECORD.TotalCoins}</td>
                  <td> {obj.CLAIM_RECORD.TotalPaid}</td>
                </tr>
                <tr style={{ backgroundColor: '#ffffff', color: '#000000', border: '!important' }}>
                  <td>ADJ TO TOTALS:</td>
                  <td>PREV PD&nbsp;&nbsp; </td>
                  <td>INTEREST&nbsp; {obj.CLAIM_RECORD.Interest}</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td colSpan={2}>LATE FILING CHARGE&nbsp;</td>
                  
                  <td>&nbsp;</td>
                  <td>
                    <div style={{ marginLeft: '9px' }}><strong>NET</strong>&nbsp; {obj.CLAIM_RECORD.NetPaid}</div>
                  </td>
                </tr>

                <tr style={{ backgroundColor: '#b7c8e1', color: '#000000' }}>
                  <td colSpan={3} valign="top"><strong>OTHER CLAIM REL IDENTIFICATION:</strong></td>
                  <td colSpan={7}>
                    {props.res.NewDataSet.ROOT.map((obj) => {

                      return (

                        <>
                          {obj.CLAIM_RECORD.CLAIM_REF_INFO.REF_01}
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          {obj.CLAIM_RECORD.CLAIM_REF_INFO.REF_02}<br />
                        </>
                      )
                    })}
                  </td>
                </tr>
             
                <tr style={{ backgroundColor: '#b7c8e1', color: '#000000' }}>
                  <td colSpan={3} valign="top"><strong>CLAIM LEVEL ADJUSTMENT CODES:</strong></td>
                  <td colSpan={7}>
                    {props.res.NewDataSet.ROOT.map((obj) => {

                      return (

                        <>
                          {obj.CLAIM_RECORD.CLAIM_REMIT_CODE.ADJ_CODE}
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          {obj.CLAIM_RECORD.CLAIM_REMIT_CODE.ADJ_AMT}
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </>
                      )
                    })}
                  </td>
                </tr> */}
                {/* ....................................... */}</tbody>
            </table>
          {/* </>
        )
      })} */}
      <table style={{ marginLeft: '-1px' }}>

        <tbody>
          <tr>
            <td><strong> <br />GLOSSARY: </strong></td>
          </tr>
        </tbody>
      </table>
      <p>&nbsp;</p>
      <table>
        {props.res.NewDataSet.GLOSSARY.map((obj) => {

          return (

            <>
              <tbody>
                <tr>
                  <td width="100px">  {obj.Code} &nbsp; </td>
                  <td width="2000px">  {obj.Description}&nbsp; </td>
                </tr>
              </tbody>
            </>

          )

        })}
      </table >

    </div >
  );
}


export default ShowPaymentDetail;
