import React, { useState, useEffect } from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CLabel,
    CCardGroup,
    CCol,
    CContainer,
    CForm,
    CInput,
    CInputGroup,
    CCardHeader,
    CModal,
    CModalHeader,
    CModalTitle,
    CModalBody,
    CModalFooter,
    CInputGroupPrepend,
    CInputGroupText,
    CValidFeedback,
    CInvalidFeedback,
    CRow,
    CTabPane,
    CNavLink,
    CTabs,
    CNav,
    CNavItem,
    CTabContent
} from '@coreui/react'
import Summary from './Summary';
import { config } from "src/containers/API_Call_Constant";
import API_Fetcher from 'src/containers/API_Fetcher';
import progressbar from '../progressbar/progressbar';
import UserProfile from 'src/containers/UserProfile';
import Payer_Billing_Provider from './Payer_Billing_Provider';
import { func } from 'prop-types';


const VisitDetail = (props) => {
    
   
    const [tab , setTab] = useState(1);

    const [modal, setModal] = useState(false);
    const [data, setData] = useState();
    const [statusdata, setStatusData] = useState();
    const [Loading, setLoading] = useState(false);
    const lorem = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit.'
    const query = "SELECT * FROM V_VISIT_SUMMARY WHERE SEQ_NUM = " + UserProfile.getVisitSeqNum();
    const payer_billing_provider_query = "SELECT * FROM edi360.V_PORTAL_VISIT  WHERE SEQ_NUM = " + UserProfile.getVisitSeqNum();


    useEffect(() => {
        console.log("visit detail")
        async function LoadData() {

            const split = "@Splitter@";
            const url = config.url.API_URL;
            const GetReportURL = url + "/GenericPageValues";

            const input = "?param=" + btoa(query + split + payer_billing_provider_query);
            const param = GetReportURL + input;
            try {
                let result = await API_Fetcher(param);

                if (!result[0].data[0].REJECTION_REASON) {

                    const status_query = "SELECT DESCRIPTION FROM CLAIM_STATUS_CATEGORY_CODES WHERE CODE = '" + result[0].data[0].ACTUAL_STATUS_CODE.replaceAll('PR', "").replaceAll('AY', "") + "'";

                    const status_input = "?param=" + btoa(status_query);
                    const status_param = GetReportURL + status_input;
                    let status_result = await API_Fetcher(status_param);

                    setStatusData(status_result);

                }

                setData(result);
                setLoading(true);
                setModal(true);
            } catch (error) {
            }
        }
        //  setModal(false)
        //  setModal(true)
        LoadData();
    }, [props])

    // const tab1= Loading ? <Summary result={data} status_result={statusdata} /> : <div className="text-center"> progressbar(1) </div>;
    // const tab2= Loading ? <Payer_Billing_Provider result={data} status_result={statusdata} /> : <div className="text-center"> progressbar(1) </div>;


    function handle_tab(props) {

        setTab(props)
    }

    return (
        <>
            <CRow>
                <CCol>
                    <CCard>
                        <CModal
                            show={modal}
                            onClose={setModal}

                        >
                            <CModalHeader closeButton>
                                <CModalTitle>Visit Detail</CModalTitle>
                            </CModalHeader>
                            <CModalBody>
                                <CRow>
                                    <CCol xs="12" md="12" className="mb-4">
                                        <CCard>
                                            <CCardBody>
                                                <CTabs>
                                                    <CNav variant="tabs">
                                                        <CNavItem>
                                                            <CNavLink onClick={()=>handle_tab(1)}>
                                                                Summary
                                                            </CNavLink>
                                                        </CNavItem>
                                                        <CNavItem onClick={()=>handle_tab(2)}>
                                                            <CNavLink >
                                                                Payer/Billing Provider
                                                            </CNavLink>
                                                        </CNavItem>
                                                        <CNavItem>
                                                            <CNavLink>
                                                                Subscriber/Patient
                                                            </CNavLink>
                                                        </CNavItem>
                                                    </CNav>
                                                    <CTabContent>
                                                        <CTabPane>
                                                        {/* {Loading ? handle_tab(1) : ""} */}
                                                      {  Loading && tab==1 ? <Summary result={data} status_result={statusdata} /> : <div className="text-center">{ progressbar(1) }</div>}
                                                            {/* {Loading  ? <Summary result = {data} status_result = {statusdata} />  : <div className="text-center"> {progressbar(1)} </div> }  */}
                                                        </CTabPane>
                                                        <CTabPane>
                                                        {/* {Loading ? handle_tab(2) : ""} */}
                                                            { Loading && tab==2 ? <Payer_Billing_Provider result = {data} /> : <div className="text-center"> {progressbar(1)} </div>}
                                                            {/* {Loading  ? <Payer_Billing_Provider result = {data} />  : <div className="text-center"> {progressbar(1)} </div> }  */}
                                                        </CTabPane>
                                                        <CTabPane>
                                                            {/* {handle_tab(3)} */}
                                                            {`3. ${lorem}`}
                                                        </CTabPane>
                                                    </CTabContent>
                                                </CTabs>
                                            </CCardBody>
                                        </CCard>
                                    </CCol>
                                </CRow>

                            </CModalBody>

                            <CModalFooter>
                                <CButton color="primary">Save</CButton>{' '}
                            </CModalFooter>
                        </CModal>
                    </CCard>
                </CCol>
            </CRow>

        </>
    )
}

export default VisitDetail;