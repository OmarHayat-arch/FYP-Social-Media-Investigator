import React, { useState, useEffect } from 'react';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';


const Subscriber_PatientBAL = (props) => {

  

    const relationship = [{ data: [
        { DISPLAY_VALUE: "Self", VALUE: "18" }, 
        { DISPLAY_VALUE: "Spouse", VALUE: "01" },
        { DISPLAY_VALUE: "Child", VALUE: "19" },
        { DISPLAY_VALUE: "Other", VALUE: "21" },  
    
    ] }];

    const gender = [{ data: [
        { DISPLAY_VALUE: "", VALUE: "" }, 
        { DISPLAY_VALUE: "Male", VALUE: "M" }, 
        { DISPLAY_VALUE: "Female", VALUE: "F" },
    
    ] }];

    const obj = [
        {
            "type": "label",
            "name": "Relationship",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Sbr02RelationCode) ? props.Sbr02RelationCode : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            "values": relationship
        },
        {
            "type": "label",
            "name": "MI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm105SbrMi) ? props.Nm105SbrMi : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"1"
        },
        {
            "type": "label",
            "name": "Address",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N301SbrAddress1) ? props.N301SbrAddress1 : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"55"
        },
        {
            "type": "label",
            "name": "Zip Code",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N403SbrZipCode) ? props.N403SbrZipCode : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"9"
        },
        {
            "type": "label",
            "name": "Last Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm103SbrLastName) ? props.Nm103SbrLastName : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"60"
        },
        {
            "type": "label",
            "name": "Subscriber ID",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm109SbrId) ? props.Nm109SbrId : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"20"
        },
        {
            "type": "label",
            "name": "City",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N401SbrCity) ? props.N401SbrCity : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"30"
        },
        {
            "type": "label",
            "name": "Birth Date",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "date",
            "name": (props.Dmg02SbrDob) ? props.Dmg02SbrDob : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":""
        },
        {
            "type": "label",
            "name": "First Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm104SbrFirstName) ? props.Nm104SbrFirstName : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"35"
        },
        {
            "type": "label",
            "name": "Group",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Sbr03GrpNum) ? props.Sbr03GrpNum : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"50"
        },
        {
            "type": "label",
            "name": "State",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N402SbrState) ? props.N402SbrState : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"2"
        },
        {
            "type": "label",
            "name": "Sex",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Dmg03SbrGender) ? props.Dmg03SbrGender : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            "values":gender
        },
        {
            "type": "label",
            "name": "Patient Account#",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.AccountNum) ? props.AccountNum : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"38"
        },
        {
            "type": "label",
            "name": "MI",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm105PatMi) ? props.Nm105PatMi : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"1"
        },
        {
            "type": "label",
            "name": "Address",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N301PatAddress1) ? props.N301PatAddress1 : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"1"
        },
        {
            "type": "label",
            "name": "Zip Code",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N403PatZipCode) ? props.N403PatZipCode : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"9"
        },
        {
            "type": "label",
            "name": "Last Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm103PatLastName) ? props.Nm103PatLastName : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"60"
        },
        {
            "type": "label",
            "name": "Birth Date",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "date",
            "name": (props.Dmg02PatDob) ? props.Dmg02PatDob : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":""
        },
        {
            "type": "label",
            "name": "City",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N401PatCity) ? props.N401PatCity : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"30"
        },
        {
            "type": "label",
            "name": "First Name",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Nm104PatFirstName) ? props.Nm104PatFirstName : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"35"
        },
        {
            "type": "label",
            "name": "Sex",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Dmg03PatGender) ? props.Dmg03PatGender : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"",
            "values":gender
        },
        {
            "type": "label",
            "name": "State",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.N402PatState) ? props.N402PatState : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"2"
        },

    ]

    return obj;

}

export default Subscriber_PatientBAL;


