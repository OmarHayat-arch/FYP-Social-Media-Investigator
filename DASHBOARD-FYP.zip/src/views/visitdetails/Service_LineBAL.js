import React, { useState, useEffect } from 'react';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';


const Service_LineBAL = (props) => {

    const ICD = [{ data: [
        { DISPLAY_VALUE: "--Select--", VALUE: "" }, 
        { DISPLAY_VALUE: "ICD-9", VALUE: "ICD-9" }, 
        { DISPLAY_VALUE: "ICD-10", VALUE: "ICD-10" },
    
    
    ] }];

    
    const obj = [
        // {
        //     "width":"3",
        //     "type": "label",
        //     "name": "Diagnosis Code Qualifier",
        //     "color": "",
        //     "visibility": ""
        // },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "1",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi012IcdCode) ? props.Hi012IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "2",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi022IcdCode) ? props.Hi022IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "3",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi032IcdCode) ? props.Hi032IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "4",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi042IcdCode) ? props.Hi042IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"3",
        //     "type": "label",
        //     "name": "",
        //     "color": "",
        //     "visibility": ""
        // },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "5",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi052IcdCode) ? props.Hi052IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "6",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi062IcdCode) ? props.Hi062IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"4",
        //     "type": "label",
        //     "name": "",
        //     "color": "",
        //     "visibility": ""
        // },
        // {
        //     "width":"3",
        //     "type": "dropdown",
        //     "name": (props.DIAGNOSIS_CODE_QUALIFIER) ? props.DIAGNOSIS_CODE_QUALIFIER : "",
        //     "color": "",
        //     "visibility": "",
        //     "disabled":true,
        //     "maxlength":"",
        //     "values":ICD
        // },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "7",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi072IcdCode) ? props.Hi072IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "8",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi082IcdCode) ? props.Hi082IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"3",
        //     "type": "label",
        //     "name": "",
        //     "color": "",
        //     "visibility": ""
        // },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "9",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi092IcdCode) ? props.Hi092IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "10",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi102IcdCode) ? props.Hi102IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"3",
        //     "type": "label",
        //     "name": "",
        //     "color": "",
        //     "visibility": ""
        // },
        //  {
        //     "width":"0",
        //     "type": "label",
        //     "name": "11",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi112IcdCode) ? props.Hi112IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
        // {
        //     "width":"0",
        //     "type": "label",
        //     "name": "12",
        //     "color": "",
        //     "visibility": ""
        // },
        {
            "width":"2",
            "type": "text",
            "name": (props.Hi122IcdCode) ? props.Hi122IcdCode : "",
            "color": "",
            "visibility": "",
            "maxlength":"30"
        },
           {
            "width":"2",
            "type": "dropdown",
            "name": (props.DiagnosisCodeQualifier) ? props.DiagnosisCodeQualifier : "",
            "color": "",
            "visibility": "",
            "disabled":true,
            "maxlength":"",
            "values":ICD
        },
    ]

    return obj;

}

export default Service_LineBAL;


