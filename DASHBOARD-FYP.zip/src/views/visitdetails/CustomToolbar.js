
import React from "react";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import SendIcon from '@material-ui/icons/Send';
import { withStyles } from "@material-ui/core/styles";
import {
    CButton,
} from '@coreui/react'


const defaultToolbarStyles = {
    
    iconButton: {
       
    },
};

class CustomToolbar extends React.Component {

    handleClick = () => {
        
    }

    render() {
        const { classes } = this.props;

        return (
            <React.Fragment>
                <Tooltip title={"Send To PM"}>
                                        
                    <IconButton className={classes.iconButton } style={{color:"#026f7b"}} onClick={this.handleClick}>
                        <SendIcon  />
                    </IconButton>
                </Tooltip>
            </React.Fragment>
        );
    }

}

export default withStyles(defaultToolbarStyles, { name: "CustomToolbar" })(CustomToolbar);