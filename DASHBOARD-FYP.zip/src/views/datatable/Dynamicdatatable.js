import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import MUIDataTable from "mui-datatables";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import VisitDetail from "../visitdetails/VisitDetail";
import {
  CButton,
  CCard,
  CCardBody,
  CLabel,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CInput,
  CInputGroup,
  CCardHeader,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CInputGroupPrepend,
  CInputGroupText,
  CValidFeedback,
  CInvalidFeedback,
  CRow,
  CTabPane,
  CNavLink,
  CTabs,
  CNav,
  CNavItem,
  CTabContent
} from '@coreui/react'
import Text_Field from 'src/views/validators/Text_Field'
import { SettingsInputAntennaTwoTone, SettingsRemote, TitleSharp } from "@material-ui/icons";

import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from "src/containers/API_Fetcher";
import CustomToolbar from "../visitdetails/CustomToolbar";
import UserProfile from "src/containers/UserProfile";
import Table_Text_Field from "../validators/Table_Text_Field";
import CustomToolbarSelect from "../visitdetails/CustomToolbarSelect";
import progressbar from "../progressbar/progressbar";

const Dynamicdatatable = (props) => {

  
  
  
  const [responsive, setResponsive] = useState("standard");
  const [tableBodyHeight, setTableBodyHeight] = useState("400px");
  const [tableBodyMaxHeight, setTableBodyMaxHeight] = useState("");
  const [status, setStatus] = useState(false);
  const [redirectStatus, setRedirectStatus] = useState(false);
  const [selectData, setSelectData] = useState();




const url=window.location.href
if(url.includes("#"))
console.log("this is url in data table==>  "+url);

 useEffect(()=>{
  

  },[])

  let indexs= [];


  let columns = [];
  let rows = [];

  //   const columns = [
  //     {name: "sl", label: "Serial No"},
  //     {name: "name", label: "Name"},
  //     {name: "title", label: "Title"},
  //     {name: "location", label: "Location"},
  //     {name: "age", label: "Age"},
  //     {name: "salary", label: "Salary"},
  //     {
  //         name: "delete",
  //         label: "",
  //         options: {
  //             filter: false,
  //             sort: false,
  //             customBodyRender: (value, tableMeta, updateValue) => {
  //                 return <CButton
  //                     color="secondary"
  //                     onClick={(ev) =>
  //                         alert('deleted')
  //                     }> Delete
  //                 </CButton>;
  //             },
  //         }
  //     }
  // ];


  //   const rows = [
  //     {name: <a href="#" onClick={()=>alert("hello")}>Khabir Uddin</a>, title: "Senior Software Engineer", location: "Dhaka", age: 38, salary: "$150,000"},
  //     {name: "Gabby George", title: "Business Analyst", location: "Minneapolis", age: 30, salary: "$100,000"},
  //     {name: "Aiden Lloyd", title: "Business Consultant", location: "Dallas", age: 55, salary: "$200,000"}
  // ];


  if("Empty" in props.result.data){

  }
  else{
  var j = 0;

  for (var key in props.result.data) {
    for (var fetch = 0; fetch < Object.keys(props.result.data[key]).length; fetch++) {

      if (fetch == props.column_index[j]) {
        columns.push(props.column_name[j]);
        j++;
      }

      else {
      //  columns.push(Object.keys(props.result.data[key])[fetch])
      }
    }
    break
  }


  // let cells = ["PROV_CLAIM_NUM"];
  var total_index = props.cells.length;
  var cells_index = 0;

  for (var key in props.result.data) {
    
    let temp = [];
    for (var fetch = 0; fetch < Object.keys(props.result.data[key]).length; fetch++) {

      if(props.column_index.indexOf(fetch) !== -1)  {
      //if(props.column_index.includes[0]){
      
      
      if (Object.keys(props.result.data[key])[fetch] == props.cells[cells_index]) {
        if (cells_index < total_index) {
          cells_index++;
          let column_data = Object.values(props.result.data[key])[fetch];

          // Variable was declared to obtain SBR_Claim_Seq_Num amd pass to visit details
          let claim_number = Object.values(props.result.data[key])[13];
          //setText(coloumn_data);
          let column_tag = <a href="#"  onClick={()=>handleClaimNum(claim_number)}>{column_data}</a>
     
          //<Table_Text_Field value={column_data}  onChangeText={(text)=>setText(text)}/>
          temp.push(column_tag);
        }
      }    
        else if(Object.keys(props.result.data[key])[fetch] == "Amount"){
        temp.push(
           '$'+Object.values(props.result.data[key])[fetch],
          )
      }
      else {
        temp.push(
          Object.values(props.result.data[key])[fetch],
        )
      }
    }
    }
    cells_index = 0;
    rows.push(temp);

  }

}
 


  const getMuiTheme = () => createMuiTheme({
    palette: {
      primary: {
        light: "#5392aa",
        main: "#5392aa",
        dark: "#5392aa",
        contrastText: "#5392aa"
      }
    },
    overrides: {
      
        //display: table-cell;
        /* padding: 0px; */
        /* font-size: 0.875rem; */
        /* text-align: right; */
        /* font-family: "Roboto", "Helvetica", "Arial", sans-serif; */
        /* font-weight: 400; */
        /* line-height: 1.43; */
       // border-bottom: 1px solid rgba(224, 224, 224, 1);
        /* letter-spacing: 0.01071em; */
        /* vertical-align: inherit; */
    
        // MuiTableRow: { root: 
        //   { '&$hover:hover':
        //   {backgroundColor: '#55bebb'} } 
        // },
        
      MuiTableCell: {
        head: {
          backgroundColor: "#e3fbfd  !important",
        
          //fontWeight:"bold",
          //"font-weight": 'bold'
        },
        root :{
        
    
          display: "table-cell",
          borderBottom: "1px solid rgba(224, 224, 224, 1)",
         // padding:"0px",
          textAlign:"left"
        }
      },
      MuiButton: {
        label: {
          //backgroundColor: 'blue',
          fontWeight:"600",
          width: "150px" ,
          justifyContent:"left !important"
          
        }
      },
      MUIDataTableBodyCell: {
        root: {
         // backgroundColor: "red",
          // width: "150px"
          fontSize:"11px"
        }
      },
      MUIDataTableToolbar: {
        root: {
          backgroundColor: "#e9e9e9  !important",
          // color: "white !important"  5392aa
        },
        // actions: {
        //   display: 'flex',
        //   flexDirection: 'row',
        //   flex: 'initial',
        //   backgroundColor: "#e9e9e9  !important",
        // },
      },
      CustomToolbar: {
        root: {
          backgroundColor: "red !important"
        }
      }
    }

  })





  const options = {
    fixedSelectColumn: false,
    filter: true,
    download: false,
    filterType: "dropdown",
    print: false,
    responsive,
    tableBodyHeight,
    tableBodyMaxHeight,
    draggableColumns:{
      enabled: true
    },
  //   onRowClick: (rowData, rowState) => {
    
  //     // console.log(rowData)
  //     // setSelectData(rowData[13]);
  //     // setRedirectStatus(true)
  //  },
    onRowsSelect: (curRowSelected, allRowsSelected) => {
      // console.log("---RowSelect")
     
      indexs.splice(0, allRowsSelected.length)
      if(allRowsSelected.length != 0){
      indexs.push(allRowsSelected);
      }

      //const len = allRowsSelected.length;
      //console.log(len)
      
     
     // for(let i = 0;i<len;i++){
      //   let index  = allRowsSelected[i].index;
      //   console.log(index)
        
      //  for (var fetch = 0; fetch < Object.keys(props.result.data[index]).length; fetch++) {
          // console.log(Object.values(props.result.data[index])[fetch])
       //   selected_temp.push(
         //   console.log(props.result.data[index])
        //    props.result.data[index]
       //   )
          //console.log(selected_temp)
      //  }
   
      //selected_temp.splice(0,0)
        //selected_temp = [];
     // }
      
      
     // console.log(selected_temp)
     
    },
    // customToolbar: () => {
    //   return (
    //     <CButton  style={{ order: -1, color:"white",background:"gray" }}>SEND TO PM</CButton>
    //   );
    // },
    // customToolbar: () => {
    //   return (
    //     props.user_check.data[0].ALLOW_SEND_TO_PM == "Y" ? <CustomToolbar /> : ""

    //   );
    // },
    customToolbarSelect: (selectedRows, displayData, setSelectedRows) => (
      "Empty" in props.user_check.data ? "" : props.user_check.data[0] == "Y"  ? <CustomToolbarSelect selected_rows = {indexs}   selectedData={props.result.data} displayData={displayData} setSelectedRows={setSelectedRows} /> : "" 
    ),
    //   onRowClick: setModal(true),
   // onCellClick: (rowData, rowState) => {
     // console.log(rowData[11]);
     // UserProfile.setVisitSeqNum(rowData[11]);
    //  return (<VisitDetail />)
      //VisitDetail();
      //  setModal(true)
      //  setStatus(true)
  //  },

  };


function handleClaimNum(claim_num){
  setSelectData(claim_num);
  setRedirectStatus(true)
  // setClaimNum(claim_num);


//   if(url.includes("#")&&status==false){
//    setStatus(true);
//    console.log("First if")
//   }
    
//  if(!(url.includes("#"))&&status==true)
//  {
//    setStatus(false);
//    console.log("Secxonf if")

//  }
  

 // setStatus(false)
  // alert(column_data +" " +key)
  // UserProfile.setVisitSeqNum(claim_num);
//setStatus(true)
}


if(redirectStatus){
  
  document.getElementById("WorkqueueDatatable").setAttribute("class", "democlass workqueueheader card-header"); 
  document.getElementById("Filter_hidden").setAttribute("class", "democlass"); 
//  var element = document.getElementsByClassName("workqueue_hidden")
//  element.setAttribute('style',"display:none");

  return (
<VisitDetail claim_no= {selectData} onChange={(e)=>setRedirectStatus(e)}/>
  )
}
  else{

    document.getElementById("WorkqueueDatatable").classList.remove("democlass");
    document.getElementById("Filter_hidden").classList.remove("democlass");

  return (
    <React.Fragment>

      {/* { (url.includes("#")) ? <VisitDetail claim_no = {claimnum}/>:""} */}



      <MuiThemeProvider theme={getMuiTheme()}>
        <MUIDataTable
          title={""}
          data={rows}
          columns={columns}
          options={options}
        />
      </MuiThemeProvider>
    </React.Fragment>
  );
  }
}



export default Dynamicdatatable;






{/* {(screen_width<"700") ? <FormControl >
        <InputLabel id="demo-simple-select-label">Responsive Option</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={responsive}
          style={{ width: "200px", marginBottom: "10px", marginRight: 10 }}
          onChange={(e) => setResponsive(e.target.value)}
        >
          <MenuItem value={"vertical"}>vertical</MenuItem>
          <MenuItem value={"standard"}>standard</MenuItem>
          <MenuItem value={"simple"}>simple</MenuItem>

          <MenuItem value={"scroll"}>scroll (deprecated)</MenuItem>
          <MenuItem value={"scrollMaxHeight"}>
            scrollMaxHeight (deprecated)
          </MenuItem>
          <MenuItem value={"stacked"}>stacked (deprecated)</MenuItem>
        </Select>
      </FormControl>: ""} */}
{/* <FormControl>
        <InputLabel id="demo-simple-select-label">Table Body Height</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={tableBodyHeight}
          style={{ width: "200px", marginBottom: "10px", marginRight: 10 }}
          onChange={(e) => setTableBodyHeight(e.target.value)}
        >
          <MenuItem value={""}>[blank]</MenuItem>
          <MenuItem value={"400px"}>400px</MenuItem>
          <MenuItem value={"800px"}>800px</MenuItem>
          <MenuItem value={"100%"}>100%</MenuItem>
        </Select>
      </FormControl> */}





// /* eslint-disable*/
// import React, { useState, useEffect } from 'react'
// import { FreeBreakfast as CoffeeIcon } from '@material-ui/icons'
// import { Datatable } from '@o2xp/react-datatable'
// import axios from 'axios'
// import { isNumber } from 'lodash'

// // var columns = []
// // var rows = []

// // const gitHubUrl = 'https://jsonplaceholder.typicode.com/todos/'
// //const gitHubUrl =
// // 'https://epmcore.practiceehr.com/CptUtilizationReport?param=where%20%20VISIT_DATE_FROM%3E=to_date(%2707-04-2021%27,%20%27DD-MM-YYYY%27)%20%20AND%20VISIT_DATE_FROM%3C=to_date(%2707-04-2021%27,%20%27DD-MM-YYYY%27)'
// const Dynamicdatatable = () => {
//   // console.log('hi')
//   // const [res, setres] = useState([])
//   // useEffect(() => {
//   //   getGiHubUserWithAxios()
//   // }, [])

//   // const getGiHubUserWithAxios = async () => {
//   //   const response = await axios.get(gitHubUrl)
//   //   setres(response.data)
//   // }

//   // for (var key in res) {
//   //   for (var fetch = 0; fetch < Object.keys(res[key]).length; fetch++) {
//   //     columns.push({
//   //       id: Object.keys(res[key])[fetch],
//   //       label: Object.keys(res[key])[fetch],
//   //       editable: true,
//   //       // colSize: "15px"
//   //       //dataType: isNaN(Object.values(res[key])[fetch]) || isNumber(Object.values(res[key])[fetch]) ? "text" : "boolean"
//   //     })
//   //   }
//   //   break
//   // }

//   // for (var val of res) {
//   //   rows.push(val)
//   // }

//   // const data = {
//   //   columns,
//   //   rows,
//   // }

//   // const storyOptionsSample = {
//   //   title: 'WorkQueue',
//   //   dimensions: {
//   //     datatable: {
//   //       width: '100%',
//   //       height: '70vh',
//   //     },
//   //   },
//   //   keyColumn: 'id',
//   //   data: {
//   //     ...data,
//   //     rows,
//   //   },
//   //   features: {
//   //     canEdit: true,
//   //     canDelete: true,
//   //     canPrint: true,
//   //     canDownload: true,
//   //     canSearch: true,
//   //     canRefreshRows: true,
//   //     canOrderColumns: true,
//   //     canSelectRow: true,
//   //     canSaveUserConfiguration: true,
//   //     additionalIcons: [
//   //       {
//   //         title: 'Action 3',
//   //         icon: <CoffeeIcon color="primary" />,
//   //         onClick: () => alert('Coffee Time'),
//   //       },
//   //     ],
//   //   },
//   // }


// // Basic Example
// let options  = {
//     keyColumn: 'id',
//     data: {
//         columns: [ 
//             {
//                 id: "id",
//                 label: "id",
//                 colSize: "80px"
//             },
//             {
//                 id: "name",
//                 label: "name",
//                 colSize: "150px"
//             },
//             {
//                 id: "age",
//                 label: "age",
//                 colSize: "50px"
//             },
//         ],
//         rows: [
//             {
//                 id: "50cf",
//                 age: 28,
//                 name: "Kerr Mayo"
//             },
//             {
//                 id: "209",
//                 age: 34,
//                 name: "Freda Bowman"
//             },
//             {
//                 id: "2dd81ef",
//                 age: 14,
//                 name: "Becky Lawrence"
//             }
//         ],
//     },
//     features: {
//       canEdit: true,
//       canDelete: true,
//       canPrint: true,
//       canDownload: true,
//       canSearch: true,
//       canRefreshRows: true,
//       canOrderColumns: true,
//       canSelectRow: true,
//       canSaveUserConfiguration: true,
//       userConfiguration: {
//         columnsOrder: [
//           "id",
//           "age",
//           "name",

//         ],
//         copyToClipboard: true
//       },


//     }
// }

//   return (
//     <>
//       <Datatable options={options} />
//     </>
//   )
// }

// export default Dynamicdatatable
