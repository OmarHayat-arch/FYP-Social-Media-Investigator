import React, { useState, useMemo, useEffect } from 'react'
import { TableHeader, Pagination, Search } from "src/views/datatable";

import {
  CButton,
  CInput
} from '@coreui/react'

import Claim_a from "src/assets/resource/Claim_a.png"
import Claim from "src/assets/resource/Claim.png"
import ClaimDisable from "src/assets/resource/ClaimDisable.png"

import ClaimStatus_a from "src/assets/resource/ClaimStatus_a.png"
import ClaimStatus_c from "src/assets/resource/ClaimStatus_c.png"
import ClaimStatus_d from "src/assets/resource/ClaimStatus_d.png"

import ERAGrid_c from "src/assets/resource/ERAGrid_c.png"
import ERAGrid_e from "src/assets/resource/ERAGrid_e.png"
import ERAGrid_f from "src/assets/resource/ERAGrid_f.png"

import Eligibility_a from "src/assets/resource/Eligibility_a.png"
import Eligibility from "src/assets/resource/Eligibility.png"
import EligibilityDisable from "src/assets/resource/EligibilityDisable.png"
import UserProfile from 'src/containers/UserProfile';
import ReplayIcon from '@material-ui/icons/Replay';
import ExportExcelIcon from 'src/assets/resource/icons/Export_Excel_white.png';
import CIcon from '@coreui/icons-react';
import API_Fetcher from 'src/containers/API_Fetcher';
import { config } from 'src/containers/API_Call_Constant';
import exportFromJSON from 'export-from-json'



const PayerListDatatable = (props) => {
  console.log(props)

  const ITEMS_PER_PAGE = 10;

  const [sorting, setSorting] = useState({ field: "", order: "" });
  const [totalItems, setTotalItems] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState("");
  const [name, setName] = useState();
  const [id, setId] = useState();
  const [filter, setFilter] = useState();
  // useEffect(()=>{

  // },[props,currentPage])

  async function HandleExportExcel() {
    const url = config.url.API_URL;
    const GetReportURL = url + "/ediportal/api/v1/RequestHandler";


    const obj = {
      tag_name: 'ExportExcel_request',
      parameters: `${UserProfile.getPayerListTab() == 1 ? "MEDICAL" : UserProfile.getPayerListTab() == 2 ? "WC" : UserProfile.getPayerListTab() == 3 ? "DENTAL" : "undefined"}@splitter@${UserProfile.getPayerName() == "" ? "undefined" : UserProfile.getPayerName()}@splitter@${UserProfile.getPayerId() == "" ? "undefined" : UserProfile.getPayerId()}@splitter@${UserProfile.getPayerFilter() == "" ? "undefined" : UserProfile.getPayerFilter()}@splitter@LiveDB`
    }

    const param = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(obj)
    }



    try {

      let result = await API_Fetcher(GetReportURL, param);

      // result  = "["+JSON.stringify(result.data[0].data) + "]";




      let tempData = "";
      for (var i = 0; i < result.data[0].data.length; i++) {
        if (i == result.data[0].data.length - 1) {
          tempData = tempData + JSON.stringify(result.data[0].data[i]);
        } else {
          tempData = tempData + JSON.stringify(result.data[0].data[i]) + ",";
        }

      }

      console.log(tempData);

      tempData = "[" + tempData + "]";
      const data = JSON.parse(tempData);
      console.log(data);


      //     let data = [{
      //       "PayerName": "(UCS) MASONRY INDUSTRY TRUST",
      //       "PayerId": "60230",
      //       "Is837Supported": "Yes",
      //       "Is276Supported": "No",
      //       "Is835Supported": "No",
      //       "Is270Supported": "No",
      //       "Is837EnrollmentRequired": "No",
      //       "Is276EnrollmentRequired": "No",
      //       "Is835EnrollmentRequired": "No",
      //       "Is270EnrollmentRequired": "No",
      //       "Charges837": "0",
      //       "Charges276": null,
      //       "Charges835": "0",
      //       "Charges270": null
      //   },{
      //     "PayerName": "(UCS) MASONRY INDUSTRY TRUST",
      //     "PayerId": "60230",
      //     "Is837Supported": "Yes",
      //     "Is276Supported": "No",
      //     "Is835Supported": "No",
      //     "Is270Supported": "No",
      //     "Is837EnrollmentRequired": "No",
      //     "Is276EnrollmentRequired": "No",
      //     "Is835EnrollmentRequired": "No",
      //     "Is270EnrollmentRequired": "No",
      //     "Charges837": "0",
      //     "Charges276": null,
      //     "Charges835": "0",
      //     "Charges270": null
      // }];



      //     // const data = [{ foo: 'line 1 foo',bar: 'bar',title:"abc" }, { bar: 'bar' }, {title:"abc"}]  
      //     // console.log(result.data[0].data[0]);

          const fileName = 'ProfessionalPayerList'  
          const exportType = 'xls'  
          exportFromJSON({ data, fileName, exportType })  


    } catch (error) {

    }

  }



  const commentsData = useMemo(() => {


    if ("Empty" in props.result) { }
    else {
      setTotalItems(props.result.length);
      return props.result.slice(
        (currentPage - 1) * ITEMS_PER_PAGE,
        (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
      );
    }
  }, [props, currentPage])




  return (
    <>
      {/* <Header title="Building a data table in react" /> */}
      <div className="row w-100">
        <div className="col mb-3 col-12 text-center">
          <div className="d-flex customHeadTitle">
            <h2>PracticeEHR Payer List</h2>
            <div className="customHeadButton">
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) }} >ALL</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("0") || setFilter("0") }}>0-9</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("A") || setFilter("A") }}>A</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("B") || setFilter("B") }}>B</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("C") || setFilter("C") }}>C</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("D") || setFilter("D") }}>D</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("E") || setFilter("E") }}>E</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("F") || setFilter("F") }}>F</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("G") || setFilter("G") }}>G</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("H") || setFilter("H") }}>H</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("I") || setFilter("I") }}>I</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("J") || setFilter("J") }}>J</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("K") || setFilter("K") }}>K</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("L") || setFilter("L") }}>L</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("M") || setFilter("M") }}>M</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("N") || setFilter("N") }}>N</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("O") || setFilter("O") }}>O</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("P") || setFilter("P") }}>P</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("Q") || setFilter("Q") }}>Q</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("R") || setFilter("R") }}>R</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("S") || setFilter("S") }}>S</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("T") || setFilter("T") }}>T</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("U") || setFilter("U") }}>U</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("V") || setFilter("V") }}>V</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("W") || setFilter("W") }}>W</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("X") || setFilter("X") }}>X</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("Y") || setFilter("Y") }}>Y</button> <span>|</span>
              <button onClick={() => { props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("Z") || setFilter("Z") }}>Z</button>
              <button onClick={() => { HandleExportExcel() }}><CIcon src={ExportExcelIcon} /> </button>
              {/* <CIcon src={ExportExcelIcon}/>  */}
              {/* <img onClick={()=>{props.PaginationChange(Math.floor(Math.random() * 10)) || props.SearchByFilter("")}} src={{ExportExcelIcon}}/> */}
            </div>
          </div>
          <div className="row direction">
            <div className="col-md-6 d-flex">
              <CInput onChange={(e) => { setName(e.target.value) }} id="name" placeholder="Search By Name" required />
              <CInput onChange={(e) => { setId(e.target.value) }} id="payerid" placeholder="Search By Payer ID" required />
              <CButton onClick={() => { props.SearchById(id) || props.SearchByName(name) || props.PaginationChange(Math.floor(Math.random() * 10)) }} type="submit" color="primary" className="custom_button1">Search</CButton>
              {/* <Search
                            onSearch={value => {
                                setSearch(value);
                                setCurrentPage(1);
                            }}
                        /> */}
            </div>
          </div>
          <div className="row">
            <div className="col-md-6">
              <Pagination
                total={totalItems}
                itemsPerPage={ITEMS_PER_PAGE}
                currentPage={currentPage}
                onPageChange={page => setCurrentPage(page)}
                onPaginationChange={status => props.PaginationChange(status)}
              />
            </div>
          </div>
          <div className="row">
            <div className="col-md-12">
              <p>Page {currentPage} of {ITEMS_PER_PAGE} <ReplayIcon />  Displaying {UserProfile.getStart()} to {Number(UserProfile.getStart()) + 100} of {UserProfile.getTotal() == "undefined" ? 0 : UserProfile.getTotal()} Items</p>
            </div>
          </div>

          <div class="table-responsive">
            <table className="table table-striped">
              {<TableHeader
                headers={props.headers}
                onSorting={(field, order) =>
                  setSorting({ field, order })
                }
              />}
              <tbody>
                {"Empty" in props.result ? "" :
                  (() => {
                    const rows = [];

                    for (let i = 0; i < commentsData.length; i++) {

                      rows.push(
                        <tr>
                          <td>{commentsData[i].PayerName}</td>
                          <td>{commentsData[i].PayerId}</td>

                          {commentsData[i].Charges837 > 0 ? <td> <img src={Claim_a} /></td> :
                            commentsData[i].Is837Supported == "Yes" ? <td> <img src={Claim} /></td> :
                              commentsData[i].Is837Supported == "No" ? <td> <img src={ClaimDisable} /></td> :
                                " "
                          }

                          {commentsData[i].Charges276 > 0 ? <td> <img src={ClaimStatus_a} /></td> :
                            commentsData[i].Is276Supported == "Yes" ? <td> <img src={ClaimStatus_c} /></td> :
                              commentsData[i].Is276Supported == "No" ? <td> <img src={ClaimStatus_d} /></td> :
                                " "
                          }

                          {commentsData[i].Charges835 > 0 ? <td> <img src={ERAGrid_c} /></td> :
                            commentsData[i].Is835Supported == "Yes" ? <td> <img src={ERAGrid_e} /></td> :
                              commentsData[i].Is835Supported == "No" ? <td> <img src={ERAGrid_f} /></td> :
                                " "
                          }

                          {commentsData[i].Charges270 > 0 ? <td> <img src={Eligibility_a} /></td> :
                            commentsData[i].Is270Supported == "Yes" ? <td> <img src={Eligibility} /></td> :
                              commentsData[i].Is270Supported == "No" ? <td> <img src={EligibilityDisable} /></td> :
                                " "
                          }
                          {/* <td>{commentsData[i].IS_835_SUPPORTED}</td>
                        <td>{commentsData[i].IS_270_SUPPORTED}</td> */}

                          <td>{commentsData[i].Is837EnrollmentRequired}</td>
                          <td>{commentsData[i].Is276EnrollmentRequired}</td>
                          <td>{commentsData[i].Is835EnrollmentRequired}</td>
                          <td>{commentsData[i].Is270EnrollmentRequired}</td>
                        </tr>
                      )


                    }
                    return rows;
                  })()}

              </tbody>
            </table>
          </div>
        </div>
      </div>

    </>
  )

}

export default PayerListDatatable;
