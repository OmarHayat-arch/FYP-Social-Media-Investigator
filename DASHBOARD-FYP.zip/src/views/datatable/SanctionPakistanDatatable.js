import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import MUIDataTable from "mui-datatables";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import VisitDetail from "../visitdetails/VisitDetail";
import {
  CButton,
  CCard,
  CCardBody,
  CLabel,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CInput,
  CInputGroup,
  CCardHeader,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CInputGroupPrepend,
  CInputGroupText,
  CValidFeedback,
  CInvalidFeedback,
  CRow,
  CTabPane,
  CNavLink,
  CTabs,
  CNav,
  CNavItem,
  CTabContent
} from '@coreui/react'
import Text_Field from 'src/views/validators/Text_Field'
import { SettingsInputAntennaTwoTone, SettingsRemote, TitleSharp } from "@material-ui/icons";

import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from "src/containers/API_Fetcher";
import CustomToolbar from "../visitdetails/CustomToolbar";
import UserProfile from "src/containers/UserProfile";
import Table_Text_Field from "../validators/Table_Text_Field";
import CustomToolbarSelect from "../visitdetails/CustomToolbarSelect";
import progressbar from "../progressbar/progressbar";

const SanctionPakistanDatatable = (props) => {

  console.log(props);
  
  
  const [responsive, setResponsive] = useState("standard");
  const [tableBodyHeight, setTableBodyHeight] = useState("400px");
  const [tableBodyMaxHeight, setTableBodyMaxHeight] = useState("");
  const [status, setStatus] = useState(false);
  const [redirectStatus, setRedirectStatus] = useState(false);
  const [selectData, setSelectData] = useState();

  let columns = [];
  let rows = [];
  const test_columns=["Test1","Test2","Test3"];

  for (var key in props.result.data.content) { // only fetch column names 
    for (var fetch = 0; fetch < Object.keys(props.result.data.content[key]).length; fetch++) {
        columns.push(Object.keys(props.result.data.content[key])[fetch]);

    }
    break;
  } 









  for (var key in props.result.data.content) {

    let temp = [];
    for (var fetch = 0; fetch < Object.keys(props.result.data.content[key]).length; fetch++) {

     // console.log(Object.values(props.result.data.content[key])[fetch]);

        temp.push(Object.values(props.result.data.content[key])[fetch])


  }
  rows.push(temp); // appending each object 


}








  const getMuiTheme = () => createMuiTheme({
    palette: {
      primary: {
        light: "#5392aa",
        main: "#5392aa",
        dark: "#5392aa",
        contrastText: "#5392aa"
      }
    },
    overrides: {
      
    
        
      MuiTableCell: {
        head: {
          backgroundColor: "#87aaf0  !important",
       
        },
        root :{
        
    
          display: "table-cell",
          borderBottom: "1px solid rgba(224, 224, 224, 1)",
          textAlign:"left"
        }
      },
      MuiButton: {
        label: {

          fontWeight:"600",
          width: "150px" ,
          justifyContent:"left !important"
          
        }
      },
      MUIDataTableBodyCell: {
        root: {
 
          fontSize:"11px"
        }
      },
      MUIDataTableToolbar: {
        root: {
          backgroundColor: "#e9e9e9  !important",
      
        },
  
      },
      CustomToolbar: {
        root: {
          backgroundColor: "red !important"
        }
      }
    }

  })





  const options = {
    fixedSelectColumn: false,
    filter: true,
    download: false,
    filterType: "dropdown",
    print: false,
    responsive,
    tableBodyHeight,
    tableBodyMaxHeight,
    draggableColumns:{
      enabled: true
    },

  };

  return (
    <React.Fragment>


      <MuiThemeProvider theme={getMuiTheme()}>
        <MUIDataTable
          title={props.result.data.Trend}
           data={rows}
          columns={columns}
          options={options}
        />
      </MuiThemeProvider>
    </React.Fragment>
  );
  }




export default SanctionPakistanDatatable;
