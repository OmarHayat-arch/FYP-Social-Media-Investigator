import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import MUIDataTable from "mui-datatables";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import VisitDetail from "../visitdetails/VisitDetail";
import {
  CButton,
  CCard,
  CCardBody,
  CLabel,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CInput,
  CInputGroup,
  CCardHeader,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CInputGroupPrepend,
  CInputGroupText,
  CValidFeedback,
  CInvalidFeedback,
  CRow,
  CTabPane,
  CNavLink,
  CTabs,
  CNav,
  CNavItem,
  CTabContent,
  CSwitch
} from '@coreui/react'
import Text_Field from 'src/views/validators/Text_Field'
import { SettingsInputAntennaTwoTone, SettingsRemote, TitleSharp } from "@material-ui/icons";

import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from "src/containers/API_Fetcher";
import CustomToolbar from "../visitdetails/CustomToolbar";
import UserProfile from "src/containers/UserProfile";
import Table_Text_Field from "../validators/Table_Text_Field";
import CustomToolbarSelect from "../visitdetails/CustomToolbarSelect";
import progressbar from "../progressbar/progressbar";

const EligibilityDatatable = (props) => {


  const [responsive, setResponsive] = useState("standard");
  const [tableBodyHeight, setTableBodyHeight] = useState("400px");
  const [tableBodyMaxHeight, setTableBodyMaxHeight] = useState("");
  const [status, setStatus] = useState(false);

  const [redirectStatus, setRedirectStatus] = useState(false);
  const [selectData, setSelectData] = useState();




const url=window.location.href
if(url.includes("#"))
console.log("this is url in data table==>  "+url);

 useEffect(()=>{
  

  },[])

  let indexs= [];


  let columns = [];
  let rows = [];

  


  if("Empty" in props.result.data){

  }
  else{
  var j = 0;

  for (var key in props.result.data) {
    for (var fetch = 0; fetch < Object.keys(props.result.data[key]).length; fetch++) {

      if (fetch == props.column_index[j]) {
        columns.push(props.column_name[j]);
        j++;
      }

      else {
      //  columns.push(Object.keys(props.result.data[key])[fetch])
      }
    }
    break
  }


  // let cells = ["PROV_CLAIM_NUM"];
  var total_index = props.cells.length;
  var cells_index = 0;

  for (var key in props.result.data) {
    
    let temp = [];
    for (var fetch = 0; fetch < Object.keys(props.result.data[key]).length; fetch++) {

      if(props.column_index.indexOf(fetch) !== -1)  {
      //if(props.column_index.includes[0]){
      
      
    //   if (Object.keys(props.result.data[key])[fetch] == props.cells[cells_index]) {
    //     if (cells_index < total_index) {
    //       cells_index++;
    //       let column_data = Object.values(props.result.data[key])[fetch];

    //       // Variable was declared to obtain SBR_Claim_Seq_Num amd pass to visit details
    //       let claim_number = Object.values(props.result.data[key])[18];
    //       //setText(coloumn_data);
    //       let column_tag = <a href="#"  onClick={()=>handleClaimNum(claim_number)}>{column_data}</a>
     
    //       //<Table_Text_Field value={column_data}  onChangeText={(text)=>setText(text)}/>
    //       temp.push(column_tag);
    //     }
    //   }
    //   else if(Object.keys(props.result.data[key])[fetch] == "Amount"){
    //     temp.push(
    //       '$'+Object.values(props.result.data[key])[fetch],
    //     )
    //   }
    //   else {
        temp.push(
          Object.values(props.result.data[key])[fetch],
        )
    //   }
    }
    }
    cells_index = 0;
    rows.push(temp);

  }

}
 


  const getMuiTheme = () => createMuiTheme({
    palette: {
      primary: {
        light: "#5392aa",
        main: "#5392aa",
        dark: "#5392aa",
        contrastText: "#5392aa"
      }
    },
    overrides: {
      
    
      MuiTableCell: {
        head: {
          backgroundColor: "#e3fbfd  !important",
        
        },
        root :{
          display: "table-cell",
          borderBottom: "1px solid rgba(224, 224, 224, 1)",
         // padding:"0px",
          textAlign:"left"
        }
      },
      MuiButton: {
        label: {
          //backgroundColor: 'blue',
          fontWeight:"600",
          width: "150px" ,
          justifyContent:"left !important"
          
        }
      },
      MUIDataTableBodyCell: {
        root: {
         // backgroundColor: "red",
          // width: "150px"'
          fontSize:"11px"
        }
      },
      MUIDataTableToolbar: {
        root: {
            display: 'none'
        //   backgroundColor: "#e9e9e9  !important",
          // color: "white !important"  5392aa
        },
      },
      CustomToolbar: {
        root: {
          backgroundColor: "red !important"
        }
      }
    }

  })

  const options = {
    fixedSelectColumn: false,
    filter: true,
    selectableRows: "none",
    filterType: "dropdown",
    print: false,
    responsive,
    tableBodyHeight,
    tableBodyMaxHeight,
    draggableColumns:{
      enabled: true
    },
    onRowsSelect: (curRowSelected, allRowsSelected) => {
    
     
      indexs.splice(0, allRowsSelected.length)
      if(allRowsSelected.length != 0){
      indexs.push(allRowsSelected);
      }

    
     
    },

  };


function handleClaimNum(claim_num){
  setSelectData(claim_num);
  setRedirectStatus(true)
}



// if(redirectStatus){
//   document.getElementById("ClaimsFilter").setAttribute("class", "democlass");
//   document.getElementById("ClaimsBack").setAttribute("class", "democlass"); 
// //  var element = document.getElementsByClassName("workqueue_hidden")
// //  element.setAttribute('style',"display:none");

//   return (
// <VisitDetail claim_no= {selectData} onChange={(e)=>setRedirectStatus(e)}/>
//   )
// }
//   else{

    // var isClassCheck = document.getElementsByClassName('democlass');
    // if (isClassCheck.length > 0) {
    //  document.getElementById("ClaimsFilter").classList.remove("democlass");
    //  document.getElementById("ClaimsBack").classList.remove("democlass");
    // }
  return (
    <React.Fragment>

      {/* { (url.includes("#")) ? <VisitDetail claim_no = {claimnum}/>:""} */}



      <MuiThemeProvider theme={getMuiTheme()}>
        <MUIDataTable
          title={""}
          data={rows}
          columns={columns}
          options={options}
        />
      </MuiThemeProvider>
    </React.Fragment>
  );
  }




export default EligibilityDatatable;

