import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import MUIDataTable from "mui-datatables";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import VisitDetail from "../visitdetails/VisitDetail";
import {
  CButton,
  CCard,
  CCardBody,
  CLabel,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CInput,
  CInputGroup,
  CCardHeader,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CInputGroupPrepend,
  CInputGroupText,
  CValidFeedback,
  CInvalidFeedback,
  CRow,
  CTabPane,
  CNavLink,
  CTabs,
  CNav,
  CNavItem,
  CTabContent
} from '@coreui/react'
import Text_Field from 'src/views/validators/Text_Field'
import { SettingsInputAntennaTwoTone, SettingsRemote, TitleSharp } from "@material-ui/icons";

import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from "src/containers/API_Fetcher";
import CustomToolbar from "../visitdetails/CustomToolbar";
import UserProfile from "src/containers/UserProfile";
import Table_Text_Field from "../validators/Table_Text_Field";
import CustomToolbarSelect from "../visitdetails/CustomToolbarSelect";
import progressbar from "../progressbar/progressbar";
import FieldsController from "../validators/FieldsController";
import FieldGroup from "../validators/FieldGroup";
import Cities from "./cities";
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';

const CustomDatatable = (props) => {

console.log(props);

  const [responsive, setResponsive] = useState("standard");
  const [tableBodyHeight, setTableBodyHeight] = useState("400px");
  const [tableBodyMaxHeight, setTableBodyMaxHeight] = useState("");
  



  const POS = [{ data: [
    { DISPLAY_VALUE: "OFFICE", VALUE: "11" },
    { DISPLAY_VALUE: "INPATIENT HOSPITAL", VALUE: "21" }, 
    { DISPLAY_VALUE: "EMERGENCY ROOM HOSPITAL", VALUE: "23" },
    { DISPLAY_VALUE: "OUTPATIENT HOSPITAL", VALUE: "22" },
    { DISPLAY_VALUE: "PATIENT'S HOME", VALUE: "12" },
    { DISPLAY_VALUE: "AMBULATORY SURGICAL CENTER", VALUE: "24" },
    { DISPLAY_VALUE: "BIRTHING CENTER", VALUE: "25" },
    { DISPLAY_VALUE: "MILITARY TREATMENT FACILITY (MTF)", VALUE: "26" },
    { DISPLAY_VALUE: "SKILLED NURSING FACILITY (SNF)", VALUE: "31" },
    { DISPLAY_VALUE: "NURSING FACILITY", VALUE: "32" },
    { DISPLAY_VALUE: "CUSTODIAL CARE FACILITY", VALUE: "33" },
    { DISPLAY_VALUE: "HOSPICE", VALUE: "34" },
    { DISPLAY_VALUE: "AMBULANCE - LAND", VALUE: "41" },
    { DISPLAY_VALUE: "AMBULANCE - AIR OR WATER", VALUE: "42" },
    { DISPLAY_VALUE: "PSYCHIATRIC FACILITY INPATIENT", VALUE: "51" },
    { DISPLAY_VALUE: "PSYCHIATRIC FACILITY PARTIAL HOSPITALIZATION", VALUE: "52" },
    { DISPLAY_VALUE: "COMMUNITY MENTAL HEALTH CENTER", VALUE: "53" },
    { DISPLAY_VALUE: "INTERMEDIATE CARE FACILITY/MENTALLY RETARDED", VALUE: "54" },
    { DISPLAY_VALUE: "RESIDENTIAL SUBSTANCE ABUSE TREATEMENT FACILITY", VALUE: "55" },
    { DISPLAY_VALUE: "PSYCHIATRIC FACILITY RESIDENTIAL TREATMENT CENTER", VALUE: "56" },
    { DISPLAY_VALUE: "COMPREHENSIVE INPATIENT REHABILITATION FACILITY", VALUE: "61" },
    { DISPLAY_VALUE: "COMPREHENSIVE OUTPATIENT REHABILITATION FACILITY", VALUE: "62" },
    { DISPLAY_VALUE: "END STAGE RENAL DISEASE TREATMENT FACILITY", VALUE: "65" },
    { DISPLAY_VALUE: "STATE OR LOCAL HEALTH CLINIC", VALUE: "71" },
    { DISPLAY_VALUE: "RURAL HEALTH CLINIC", VALUE: "72" },
    { DISPLAY_VALUE: "INDEPENDENT LABORATORY", VALUE: "81" },
    { DISPLAY_VALUE: "OTHER UNLISTED FACILITY", VALUE: "99" },
] }];



  useEffect(() => {

  }, [])

  
  let rows = [];

  const columns = [
    {
      name: "Date of Service",
      options: {
        filter: false,
        customBodyRender: (value, tableMeta, updateValue) => {
          return (
            <div>
              <FieldsController disabled={true} maxlength={""} values={""} type={"text"} color={""} name={value} visibility={"visisble"} ></FieldsController>
            </div>)
        }
      }
    },
    {
      name: "POS",
      options: {
        filter: true,
        customBodyRender: (value, tableMeta, updateValue) => {
          
          return (
            
            <div>
              <FieldsController disabled={props.res1.InternalStatus=="F" || props.res1.InternalStatus=="J" || props.res1.InternalStatus=="O" || props.res1.InternalStatus=="V" ? false : true } maxlength={""} values={POS} type={"dropdown"} color={""} name={value} visibility={"visisble"} ></FieldsController>
            </div>)
        }
      }
    },
    {
      name: "CPT",
      options: {
        filter: true,
        customBodyRender: (value, tableMeta, updateValue) => {
          return (
            <div>
              <FieldsController disabled={props.res1.InternalStatus=="F" || props.res1.InternalStatus=="J" || props.res1.InternalStatus=="O" || props.res1.InternalStatus=="V" ? false : true} maxlength={"48"} values={""} type={"text"} color={""} name={value} visibility={"visisble"} ></FieldsController>
            </div>)
        }
      }
    },
    {
      name: "Modifiers",
      options: {
        filter: false,
        customBodyRender: (value, tableMeta, updateValue) => {
          return (
            <div style={{ display: "flex" }}>
              {value.map((e) => {
                return (
                  <FieldsController disabled={props.res1.InternalStatus=="F" || props.res1.InternalStatus=="J" || props.res1.InternalStatus=="O" || props.res1.InternalStatus=="V" ? false : true} maxlength={"2"} values={""} type={"text"} color={""} name={e} visibility={"visisble"} ></FieldsController>
                )
              })}
            </div>)
        }
      }
    },
    {
      name: "Diagnosis Pointers",
      options: {
        filter: true,
        customBodyRender: (value, tableMeta, updateValue) => {
          return (
            <div style={{ display: "flex" }}>
              {value.map((e) => {
                return (
                  <FieldsController disabled={props.res1.InternalStatus=="F" || props.res1.InternalStatus=="J" || props.res1.InternalStatus=="O" || props.res1.InternalStatus=="V" ? false : true} maxlength={"2"} values={""} type={"text"} color={""} name={e} visibility={"visisble"} ></FieldsController>
                )
              })}
            </div>)
        }
      }
    },
    {
      name: "Units Qualifier",
      options: {
        filter: true,
        customBodyRender: (value, tableMeta, updateValue) => {
          return (
            <div>
              <FieldsController disabled={true} maxlength={"2"} values={""} type={"text"} color={""} name={value} visibility={"visisble"} ></FieldsController>
            </div>)
        }
      }
    },
    {
      name: "Units",
      options: {
        filter: true,
        customBodyRender: (value, tableMeta, updateValue) => {
          return (
            <div>
              <FieldsController disabled={props.res1.InternalStatus=="F" || props.res1.InternalStatus=="J" || props.res1.InternalStatus=="O" || props.res1.InternalStatus=="V" ? false : true} maxlength={""} values={""} type={"text"} color={""} name={value} visibility={"visisble"} ></FieldsController>
            </div>)
        }
      }
    },
    {
      name: "Charges",
      options: {
        filter: true,
        customBodyRender: (value, tableMeta, updateValue) => {
          return (
            <div>
              <FieldsController disabled={props.res1.InternalStatus=="F" || props.res1.InternalStatus=="J" || props.res1.InternalStatus=="O" || props.res1.InternalStatus=="V" ? false : true} maxlength={""} values={""} type={"text"} color={""} name={value} visibility={"visisble text-right"} ></FieldsController>
            </div>)
        }
      }
    }

  ];



  for (var key in props.res2) {

    let temp = [];
    let mod = [];
    let diag = [];

    temp.push(props.res2[key].Dtp03DosDate)
    temp.push(props.res2[key].Sv105PosCode)
    temp.push(props.res2[key].Sv1012Cpt)
    mod.push(props.res2[key].Sv1013CptMod1)
    mod.push(props.res2[key].Sv1014CptMod2)
    mod.push(props.res2[key].Sv1015CptMod3)
    mod.push(props.res2[key].Sv1016CptMod4)
    temp.push(mod);
    diag.push(props.res2[key].Sv1071DiagPointer)
    diag.push(props.res2[key].Sv1072DiagPointer)
    diag.push(props.res2[key].Sv1073DiagPointer)
    diag.push(props.res2[key].Sv1074DiagPointer)
    temp.push(diag)
    temp.push(props.res2[key].Sv103ChargeUnitQual)
    temp.push(props.res2[key].Sv104ChargeUnits)
    temp.push(props.res2[key].Sv102ChargeAmt)

    rows.push(temp)
  }


  const getMuiTheme = () => createMuiTheme({
    palette: {
      primary: {
        light: "#5392aa",
        main: "#5392aa",
        dark: "#5392aa",
        contrastText: "#5392aa"
      }
    },
    overrides: {

      MuiTableCell: {
        head: {
          backgroundColor: "#e3fbfd  !important",

        },
        root: {
          display: "table-cell",
          borderBottom: "1px solid rgba(224, 224, 224, 1)",
          padding: "0px",
          textAlign: "left"
        }
      },
      MuiButton: {
        label: {

          fontWeight: "600",
          width: "150px",
          justifyContent: "left !important"

        }
      },
      MUIDataTableBodyCell: {
        root: {

          width: "150px"
        }
      },
      MUIDataTableToolbar: {
        root: {
          // display: "none",
          backgroundColor: "#e9e9e9  !important",

        },

      },
      CustomToolbar: {
        root: {
          backgroundColor: "red !important"
        }
      }
    }

  })


  const options = {
    fixedSelectColumn: false,
    filter: false,
    filterType: false,
    download:false,
    search: false,
    customSearchRender: () => null,
    print: false,
    responsive,
    selectableRows: false,
    tableBodyHeight,
    tableBodyMaxHeight,
    draggableColumns: {
      enabled: true
    },
    
  };


  return (
    <React.Fragment>



      <MuiThemeProvider theme={getMuiTheme()}>
        <MUIDataTable
          title={"Service Line Information"}
          data={rows}
          columns={columns}
          options={options}
        />
      </MuiThemeProvider>
    </React.Fragment>
  );
}



export default CustomDatatable;

