import React, { useState } from "react";
import {
    CButton,
    CInput
} from '@coreui/react'

const Search = ({ onSearch }) => {
    const [search, setSearch] = useState("");

    const onInputChange = value => {
        setSearch(value);
        onSearch(value);
    };

    return (
        <>
            <CInput id="name" placeholder="Search By Name" required />
            <CInput id="payerid" placeholder="Search By Payer ID" required />
            <CButton type="submit" color="primary" className="custom_button1">Search</CButton>
        </>
        // <input
        //     type="text"
        //     className="form-control"
        //     style={{ width: "240px" }}
        //     placeholder="Search"
        //     value={search}
        //     onChange={e => onInputChange(e.target.value)}
        // />
    );
};

export default Search;
