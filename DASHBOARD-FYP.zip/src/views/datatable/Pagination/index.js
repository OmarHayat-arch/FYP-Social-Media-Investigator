import React, { useEffect, useState, useMemo } from "react";
import UserProfile from "src/containers/UserProfile";
import Pagination from "react-bootstrap/Pagination";


const PaginationComponent = ({
    total = 0,
    itemsPerPage = 10,
    currentPage = 1,
    onPageChange,
    onPaginationChange
}) => {
    const [totalPages, setTotalPages] = useState(0);

    useEffect(() => {
        if (total > 0 && itemsPerPage > 0)
            setTotalPages(Math.ceil(total / itemsPerPage));
    }, [total, itemsPerPage]);


    const paginationItems = useMemo(() => {
        const pages = [];

        for (let i = 1; i <= totalPages; i++) {
            pages.push(
                <Pagination.Item
                    key={i}
                    active={i === currentPage}
                    onClick={() => onPageChange(i)}
                >
                    {i}
                </Pagination.Item>
            );
        }

        return pages;
    }, [totalPages, currentPage]);

    if (totalPages === 0) return null;




function handlePagination(page){
     UserProfile.setPayerListType(page);
    
     if((UserProfile.getStart() == 0 && (page == "P" || page == "F")) || ((Math.sign(UserProfile.getTotal() - UserProfile.getEnd()) == -1 || Math.sign(UserProfile.getTotal() - UserProfile.getEnd()) == 0)  && (page == "N" || page == "L"))){
        
     }else{
        onPaginationChange(Math.floor(Math.random() * 10));
     }
}

    return (
        <>
        {/* <button>test</button> */}
        <Pagination>
           <button className="customFirstLast" onClick={()=>handlePagination("F")}>First</button>
            <Pagination.First
            onClick={()=>handlePagination("P")}
            />
            <Pagination.Prev
                onClick={() => onPageChange(currentPage - 1)}
                disabled={currentPage === 1}
            />
            {paginationItems}
            <Pagination.Next
                onClick={() => onPageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
            />
            <Pagination.Last
            onClick={()=>handlePagination("N")}
            />
            <button className="customFirstLast" onClick={()=>handlePagination("L")}>Last</button>
        </Pagination>
        </>
    );
};

export default PaginationComponent;
