import React, { useState, useEffect, useRef } from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CSwitch
} from '@coreui/react'
import Dynamicdatatable from 'src/views/datatable/Dynamicdatatable'
import { config } from 'src/containers/API_Call_Constant'
import API_Fetcher from 'src/containers/API_Fetcher'
import progressbar from 'src/views/progressbar/progressbar'
import UserProfile from 'src/containers/UserProfile';
import moment from 'moment';
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';
import CIcon from '@coreui/icons-react'
import ExportExcelIcon from 'src/assets/resource/icons/Export_Excel_white.png';


// const singlequote = '\'';
// const user_query = "SELECT ALLOW_SEND_TO_PM FROM CLIENT_PORTAL_USERS  WHERE CLIENT_SEQ_NUM = "+ UserProfile.getSeqnum() + "  and USER_NAME = " + singlequote + UserProfile.getName() + singlequote ;
// const workqueue_query = "SELECT initcap(PATIENT) PATIENT, INSURED_ID,TO_CHAR(AMOUNT, '$99,999,999,999,999,999.99') AMOUNT, PAYER_ID,PROV_CLAIM_NUM,RECEIVED_DATE ENTRY_DATE,STATUS, EDI360_CLAIM_NUM, FILE_NAME ,  REJECTION_REASON , '' TEMP, X12_SBR_CLAIM_SEQ_NUM, INTERNAL_STATUS,initcap(PAYER_NAME) PAYER_NAME, DOS,' '  Space  FROM EDI360.VP_WORK_QUEUE_CLAIMS WHERE CLIENT_SEQ_NUM = " + UserProfile.getSeqnum() + " ORDER BY ENTRY_DATE desc";
// const customized_col_names=["Patient","Insured ID","Amount","Provider Claim #","Received Date","Status","Rejection Reason","Payer Name","DOS"];
// const customized_col_index=[0,1,2,4,5,6,9,13,14];

const customized_col_names = ["Provider Claim #", "Patient", "DOS", "Amount", "Payer Name", "Insured ID", "Received Date", "Status", "Rejection Reason"];
const customized_col_index = [0, 1, 2, 3, 4, 5, 6, 7, 8];

const cells = ["ProvClaimNum"]

function WorkQueue() {
    const [data, setData] = useState([]);
    const [isLoading, setLoading] = useState(false);
    const [check, setCheck] = useState();
    const [open, setOpen] = useState(false);
    const [ReceivedFrom, setReceivedFrom] = useState();
    const [ReceivedTo, setReceivedTo] = useState();
    const [Status, setStatus] = useState();
    const [RejectionReason, setRejectionReason] = useState();

    const DateInput1 = useRef();
    const DateInput2 = useRef();

    const handleClose = () => {
        setOpen(false);
    };
    const handleToggle = () => {
        setOpen(!open);
    };

    const useStyles = makeStyles((theme) => ({
        backdrop: {
            zIndex: theme.zIndex.drawer + 1,
            color: '#fff',
        },
    }));

    const classes = useStyles();

    async function hanldleSubmit() {
        handleToggle();
        const url = config.url.API_URL;
        const GetReportURL = url + "/ediportal/api/v1/RequestHandler";

        const obj = {
            tag_name: 'WorkQueue_condition_request',
            parameters: `${ReceivedFrom}@splitter@${ReceivedTo}@splitter@${Status}@splitter@${RejectionReason}@splitter@${UserProfile.getSeqnum()}@splitter@LiveDB`
        }

        const param = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(obj)
        }

        try {
            let { status, data } = await API_Fetcher(GetReportURL, param)

            setData(data[0]);
            setLoading(true);
            setOpen(false);


        } catch (error) {
        }

    }

    useEffect(() => {
        // var navElements = document.querySelectorAll('.custom_input');
        // navElements.forEach(function(navElement) {

        //     navElement.classList.remove("custom-select");
        //     navElement.classList.remove("form-control");
        //     })

        async function LoadData() {


            const url = config.url.API_URL;
            const GetReportURL = url + "/ediportal/api/v1/RequestHandler";

            const obj = {
                tag_name: 'WorkQueue_request',
                parameters: `${UserProfile.getSeqnum()}@splitter@${UserProfile.getName()}@splitter@LiveDB`
            }

            const param = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(obj)
            }

            try {
                let { status, data } = await API_Fetcher(GetReportURL, param)


                setData(data[1]);
                setCheck(data[0])
                setLoading(true);


            } catch (error) {
            }
        }
        LoadData();
    }, [])

    function HandleExportExcel(){

        console.log(data)
    }


    return (
        <div>

            <CRow id="Filter_hidden">
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardBody>
                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <label className="custom_label" htmlFor="date-input">Received From</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()} value={ReceivedFrom == undefined ? "" : moment(ReceivedFrom).format('YYYY-MM-DD')} onChange={(e) => setReceivedFrom(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="Received From" />
                                            <div class="divider"></div>
                                            {ReceivedFrom == undefined ? "" : <button onClick={() => { setReceivedFrom(undefined) }} className="custom_clear">X</button>}
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Received To</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()} value={ReceivedTo == undefined ? "" : moment(ReceivedTo).format('YYYY-MM-DD')} onChange={(e) => setReceivedTo(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="Received To" />
                                            <div class="divider"></div>
                                            {ReceivedTo == undefined ? "" : <button onClick={() => { setReceivedTo(undefined) }} className="custom_clear">X</button>}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="select">Status</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CSelect onChange={(e) => setStatus(e.target.value)} custom name="select" id="common">
                                                <option value="">ALL</option>
                                                <option value="PAYER REJECTED">PAYER REJECTED</option>
                                                <option value="PRACTICEEHR REJECTED">PRACTICEEHR REJECTED</option>
                                            </CSelect>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                            </CRow>

                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Rejected Reason</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setRejectionReason(e.target.value)} id="common" placeholder="Rejection Reason" required />
                                        </CCol>


                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            {/* <CLabel className="custom_label" htmlFor="date-input">Rejected Reason</CLabel> */}
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            {/* <CInput onChange={(e)=>setRejectionReason(e.target.value)} id="common" placeholder="Rejection Reason" required /> */}
                                        </CCol>


                                    </CFormGroup>
                                </CCol>




                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            {/* <CLabel className="custom_label" htmlFor="date-input">Rejected Reason</CLabel> */}
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CButton onClick={() => hanldleSubmit()} type="submit" color="primary" className="custom_button col-md-12">Search</CButton>
                                            {isLoading && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>}
                                            {/* <CInput onChange={(e)=>setRejectionReason(e.target.value)} id="common" placeholder="Rejection Reason" required /> */}
                                        </CCol>


                                    </CFormGroup>
                                </CCol>

                            </CRow>
                            <CRow>

                                {/* <CCol xs="12" className="text-center">
                                    <CButton onClick={()=>hanldleSubmit()} type="submit" color="primary" className="custom_button">Search</CButton>
                                    {isLoading && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>}
                                </CCol> */}
                            </CRow>
                            <CRow>
                            </CRow>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            <CRow >
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardHeader className="workqueueheader" id="WorkqueueDatatable">
                            <CRow>
                                <CCol className="col-9">
                                    <small>
                                        <strong>WorkQueue</strong>
                                    </small>
                                </CCol>
                                <CCol className="d-flex justify-content-end col-3">
                                    
                                    <button style={{background:"#73b6c2"}} onClick={() => HandleExportExcel()} type="submit"  ><CIcon src={ExportExcelIcon} /> </button>
                                    
                                </CCol>
                            </CRow>
                        </CCardHeader>
                        <CCardBody >
                            {isLoading ? <Dynamicdatatable result={data} user_check={check} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : progressbar(2)}
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>


        </div>
    )
}

export default WorkQueue
