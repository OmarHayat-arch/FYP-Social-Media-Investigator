import React, { useState, useEffect } from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CSwitch
} from '@coreui/react'
import DailySubmissionDatatable from 'src/views/datatable/DailySubmissionDatatable'
import { config } from 'src/containers/API_Call_Constant'
import API_Fetcher from 'src/containers/API_Fetcher'
import progressbar from 'src/views/progressbar/progressbar'
import UserProfile from 'src/containers/UserProfile';
import moment from 'moment';
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';
import DailySubmissionDetailDatatable from '../datatable/DailySubmissionDetailDatatable'


// const singlequote = '\'';
// const user_query = "SELECT ALLOW_SEND_TO_PM FROM CLIENT_PORTAL_USERS  WHERE CLIENT_SEQ_NUM = "+ UserProfile.getSeqnum() + "  and USER_NAME = " + singlequote + UserProfile.getName() + singlequote ;
// const workqueue_query = "SELECT initcap(PATIENT) PATIENT, INSURED_ID,TO_CHAR(AMOUNT, '$99,999,999,999,999,999.99') AMOUNT, PAYER_ID,PROV_CLAIM_NUM,RECEIVED_DATE ENTRY_DATE,STATUS, EDI360_CLAIM_NUM, FILE_NAME ,  REJECTION_REASON , '' TEMP, X12_SBR_CLAIM_SEQ_NUM, INTERNAL_STATUS,initcap(PAYER_NAME) PAYER_NAME, DOS,' '  Space  FROM EDI360.VP_WORK_QUEUE_CLAIMS WHERE CLIENT_SEQ_NUM = " + UserProfile.getSeqnum() + " ORDER BY ENTRY_DATE desc";
const customized_col_names = ["Date", "Status", "File Name", "Total Claims", "Total Amount", "Accepted By PracticeEHR", "Rejected By PracticeEHR", "Waiting From Payer", "Forwarded To Payer", "Received By Payer", "Accepted By Payer", "Payer Rejected", "Work Queue", "Send to PM"];
const customized_col_index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
const cells = ["EntryDate"]

function DailySubmissionDetail(props) {
    const [data, setData] = useState([]);
    const [isLoading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);

    const [From, setFrom] = useState();
    const [To, setTo] = useState();
    const [Status, setStatus] = useState("IN Process");




    const handleClose = () => {
        setOpen(false);
    };
    const handleToggle = () => {
        setOpen(!open);
    };

    const useStyles = makeStyles((theme) => ({
        backdrop: {
            zIndex: theme.zIndex.drawer + 1,
            color: '#fff',
        },
    }));

    const classes = useStyles();



    useEffect(() => {

        async function LoadData() {


            const url = config.url.API_URL;
            const GetReportURL = url + "/ediportal/api/v1/RequestHandler";

            const obj = {
                tag_name: 'DailySubmissionDetail_request',
                parameters: `${props.entryDate}@splitter@${UserProfile.getSeqnum()}@splitter@LiveDB`
            }

            const param = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(obj)
            }

            try {
                let { status, data } = await API_Fetcher(GetReportURL, param)



                setData(data[0]);
                setLoading(true);


            } catch (error) {
            }
        }
        LoadData();
    }, [])

    function hanldleSubmit() {
        props.onChange(false);

    }

    return (
        <div>
            <CRow id="DailySubmissionDetailBack">
                <CCol className="d-flex justify-content-end col-12">
                    <CButton onClick={() => hanldleSubmit()} type="submit" color="primary" className="custom_button">BACK</CButton>
                </CCol>
            </CRow>

            {isLoading ? <DailySubmissionDetailDatatable result={data} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : progressbar(2)}

        </div>
    )
}

export default DailySubmissionDetail
