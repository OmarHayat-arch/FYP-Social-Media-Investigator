import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  CButton,
  CCard,
  CCardBody,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CInput,
  CInputGroup,
  CCardHeader,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CInputGroupPrepend,
  CInputGroupText,
  CValidFeedback,
  CInvalidFeedback,
  CRow
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
//import Logo from 'src/assets/resource/logo.png';
import Logo from 'src/assets/resource/Lego.jpeg';

import Text_Field from '../../validators/Text_Field'
import Password_Field from '../../validators/Password_Field'
import API_Fetcher from 'src/containers/API_Fetcher'
import { config } from 'src/containers/API_Call_Constant';
import UserProfile from 'src/containers/UserProfile'
import progressbar from 'src/views/progressbar/progressbar';
import Login_Pic from "src/assets/resource/login_Banner.jpeg";
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';
import User from 'src/views/users/User';

const Login = (props) => {

  const [username, setUsername] = useState()
  const [password, setPassword] = useState()
  const [modal, setModal] = useState(false)
  const [modalTitle, setModalTitle] = useState()
  const [modalDescription, setModalDescription] = useState()
  const [isLoading, setLoading] = useState(false);
  const [status, setStatus] = useState();
  const [open, setOpen] = useState(false);

  const handleClose = () => {
    setOpen(false);
  };
  const handleToggle = () => {
    setOpen(!open);
  };

  const useStyles = makeStyles((theme) => ({
    backdrop: {
      zIndex: theme.zIndex.drawer + 1,
      color: '#fff',
    },
  }));

  const classes = useStyles();

  async function handlesubmit() {
    handleToggle();
    setLoading(true);


    if (username == undefined || password == undefined) {
      setLoading(false);
      setModal(true);
      setModalTitle("Alert");
      setModalDescription("Please Enter Username/Password");
      setStatus(100);
    }

    else {
      if (username == "omar" && password == "omar") {
        UserProfile.setSeqnum(1000);//hard coding 
        UserProfile.setName(username);
        setLoading(false);
        props.onchangestatus(false)
      }
      else {
        setLoading(false);
        setModal(true);
        setModalTitle("Alert");
        setModalDescription("Incorrect Username/Password");
      }

    }


    /* if (username == undefined || password == undefined) {
       setLoading(false);
       setModal(true);
       setModalTitle("Alert");
       setModalDescription("Please Enter Username/Password");
       setStatus(100);
     }
     else {
       const url = config.url.API_URL;
       const GetReportURL = url +"/ediportal/api/v1/RequestHandler";
 
       const obj = {
         tag_name: 'Login_request',
         parameters: `${username}@splitter@${password}@splitter@LiveDB`
       }
 
 
      
       const param = {
         method: 'POST',
         headers: { 'Content-Type': 'application/json'},
          body: JSON.stringify(obj)
       }
 
       try {
 
         let { status, data } = await API_Fetcher(GetReportURL, param)
 
       
         setStatus(status);
         switch (status) {
 
           case 200:
             UserProfile.setSeqnum(data[0].data.ClientSeqNum);
             UserProfile.setName(username);
             UserProfile.setWorkQueueCount("Empty" in data[1].data ? "0" :  data[1].data[0])
             
             setLoading(false);
             props.onchangestatus(false)
             break;
 
           case 404:
             setLoading(false);
             setModal(true);
             setModalTitle("Alert");
             setModalDescription("Incorrect Username/Password");
             break;
 
           default:
             setLoading(false);
             setModal(true);
             setModalTitle("Alert");
             setModalDescription("Error Occurred");
         }
        
       } catch (error) {
         setLoading(false);
         setModal(true);
         setModalTitle("Network Error");
         setModalDescription(error.message);
       }
 
     }*/
  }

  return (
    <div className="c-app c-default-layout flex-row align-items-center bg-image">

      <CRow>
        <CCol>
          <CCard>
            <CModal
              show={modal}
              onClose={setModal}
              color={status == 404 ? "warning" : status == 100 ? "info" : "danger"}
            >
              <CModalHeader closeButton>
                <CModalTitle>{modalTitle}</CModalTitle>
              </CModalHeader>
              <CModalBody>
                {modalDescription}
              </CModalBody>
              <CModalFooter>
                <CButton
                  color={status == 404 ? "warning" : status == 100 ? "info" : "danger"}
                  onClick={() => setModal(false)}
                >Cancel</CButton>
              </CModalFooter>
            </CModal>
          </CCard>
        </CCol>
      </CRow>


      <CContainer>
        <CRow className="justify-content-center">
          <CCol md="8">
            <CCardGroup>
              <CCard className="p-4">
                <CCardBody>
                  <div className="text-medium-emphasis text-center mb-4">
                    { <img src={Logo} align="center" alt="logo" style={{ maxWidth: '-webkit-fill-available' }} />   }
                  </div>
                  <CForm
                    onSubmit={handlesubmit}
                  >
                    {/* <h2 className="text-center">Login</h2>
                    <p className="text-muted text-center">Sign In to your account</p> */}
                    <CInputGroup className="mb-3">
                      <CInputGroupPrepend>
                        <CInputGroupText>
                          <CIcon name="cil-user" />
                        </CInputGroupText>
                      </CInputGroupPrepend>


                      <Text_Field invalid_msg="Please Enter Username" valid_msg="Looks Good!" placeholder="username" onChangeText={(username) => setUsername(username)} />


                    </CInputGroup>
                    <CInputGroup className="mb-4">
                      <CInputGroupPrepend>
                        <CInputGroupText>
                          <CIcon name="cil-lock-locked" />
                        </CInputGroupText>
                      </CInputGroupPrepend>

                      <Password_Field invalid_msg="Please Enter Password" placeholder="Password" valid_msg="Looks Good!" onChangePassword={(password) => setPassword(password)} />

                    </CInputGroup>
                    <CRow>
                      <CCol xs="12" >
                        <CButton color="primary" className="px-4 col-12 custom_button " onClick={handlesubmit} >Login</CButton>

                      </CCol>
                    </CRow>

                    <CRow>
                      <CCol className="text-center mt-md-4">

                        {isLoading && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>}


                      </CCol>
                    </CRow>
                  </CForm>
                </CCardBody>
              </CCard>
              <CCard className="text-white d-md-down-none card_login_image" >

                <img src={Login_Pic} style={{ width: 'fit-content' }} />
                {/* <div>
                    <h2>Sign up</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                      labore et dolore magna aliqua.</p>
                    <Link to="/register">
                      <CButton color="primary" className="mt-3" active tabIndex={-1}>Register Now!</CButton>
                    </Link>
                  </div> */}

              </CCard>
            </CCardGroup>
          </CCol>
        </CRow>
      </CContainer>




    </div>
  )
}

export default Login
