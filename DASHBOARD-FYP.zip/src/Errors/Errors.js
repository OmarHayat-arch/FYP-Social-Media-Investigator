import React, {useEffect } from "react";


 function Errors(props) {

  

  useEffect(()=>{
  
    

   

  },[props]);

 


 
  
  
  

  return (

    <table  className="messagePan"  align="center" cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td align="center" width="100%" valign="middle" height="50"><div class="errorMessage">{props.msg}</div></td><td valign="middle" height="50"><a class="Close"></a></td></tr></tbody></table>



  
  );
}

export default Errors;