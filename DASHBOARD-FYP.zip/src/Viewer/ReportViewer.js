import React, { Suspense, lazy, useState, useEffect } from "react";
import { Viewer } from "@grapecity/activereports-react";
import {} from "../arjs-license";

function ReportViewer(props) {
  const viewerRef = React.useRef();
  // this mode ($galleymode") was removed from below array to stablize rendering on browser end"
  useEffect(() => {
    const viewerInstance = viewerRef.current?.Viewer;
    viewerInstance?.toolbar.updateLayout({
      default: [
        "$navigation",
        "$split",
        "$refresh",
        "",
        "$zoom",
        "$fullscreen",
        "$print",
        "$singlepagemode",
         "$galleymode",
        "$continuousmode",
      ],
      fullscreen: ["$fullscreen", "$split", "$print"],
      mobile: ["$navigation"],
    });
    if (props.report && props.data) {
// console.log(props.data)
      console.log(props.data);
      props.report.DataSources[0].ConnectionProperties.ConnectString ="jsondata=" + JSON.stringify(props.data);
      viewerRef.current.Viewer.open(props.report);
    }
  }, [props.data]);

  return (
    <div id="viewer-Component">
      <Viewer ref={viewerRef} />
    </div>
  );
}
export default React.memo(ReportViewer);
