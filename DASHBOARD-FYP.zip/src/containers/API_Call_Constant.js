const prod = {
    url: {
     API_URL: 'https://epmcore.practiceehr.com',
     API_URL_USERS: 'someurl'}
   };
   const dev = {
    url: {
     API_URL: 'https://localhost:5001'
    }
   };
   const stage = {
    url: {
     API_URL: 'https://192.168.100.120:5001'
    }
   };
   export const config = process.env.NODE_ENV === 'development' ? dev : prod;