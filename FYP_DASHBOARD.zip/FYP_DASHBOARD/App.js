import React, { useState, useEffect } from 'react';
import { BrowserRouter, Route, Switch, useLocation } from 'react-router-dom';
import './scss/style.scss';
import UserProfile from './containers/UserProfile';
import { appconstant } from 'src/containers/AppConstant'
import API_Fetcher from './containers/API_Fetcher';


const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
  
)

// Containers
const TheLayout = React.lazy(() => import('./containers/TheLayout'));

// Pages
const Login = React.lazy(() => import('./views/pages/login/Login'));
const Register = React.lazy(() => import('./views/pages/register/Register'));
const Page404 = React.lazy(() => import('./views/pages/page404/Page404'));
const Page500 = React.lazy(() => import('./views/pages/page500/Page500'));

// function RemoveKeys(){
//   if(!(window.location.href.includes("PayerList") || window.location.href.includes("PayerList_Datatable")))
//   {
//     UserProfile.removeItem();
//   }
// }


const App = () => {

  
  
  const [showlogin, setshowlogin] = useState(true);




  useEffect(() => {




    let Redirect  = window.location.href;

    let TempRedirect = Redirect.split('/');

    TempRedirect = TempRedirect[0] + "//" + TempRedirect[2] +"/";

    
    if (showlogin == true && Redirect != TempRedirect) {     
      window.location.replace(TempRedirect);
    }
    if (!UserProfile.getSeqnum() == '') {

      // changestate={() => setshowlogin()}
      setshowlogin(false)
    }
    else {

      setshowlogin(true)
    }

  }, [showlogin])


  return (
    <BrowserRouter>
      <React.Suspense fallback={loading}>
        <Switch>
          {/* <Route exact path="/login" name="Login Page" render={props => <Login {...props}/>} />
              <Route exact path="/register" name="Register Page" render={props => <Register {...props}/>} />
              <Route exact path="/404" name="Page 404" render={props => <Page404 {...props}/>} />
              <Route exact path="/500" name="Page 500" render={props => <Page500 {...props}/>} />
    <Route path="/" name="Home" render={props => <TheLayout {...props}/>} />*/}
          {showlogin && <Route exact path="/" name="Login Page" render={props => <Login onchangestatus={(statestatus) => setshowlogin(statestatus)} />} />}
          {!showlogin && <Route path="/" name="Home" render={props => <TheLayout />} />}

        </Switch>
      </React.Suspense>
    </BrowserRouter>
  );
}


export default App;
