
const prod = {
    url: {
     API_URL: 'https://epmcore.practiceehr.com',
     API_URL_USERS: 'someurl'}
   };
   const dev = {
    url: {
     API_URL: 'http://localhost:3000/'
    }
   };
   const stage = {
    url: {
     API_URL: 'http://192.168.100.120:3000'
    }
   };
   export const appconstant = process.env.NODE_ENV === 'development' ? dev : prod;