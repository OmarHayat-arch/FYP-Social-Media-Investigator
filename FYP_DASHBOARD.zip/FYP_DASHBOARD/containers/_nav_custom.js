/* eslint-disable*/
import React,{useEffect} from 'react'
import CIcon from '@coreui/icons-react'
import { NavLink } from 'react-router-dom'

const _nav_custom=(name,to) =>{

    var obj;
  obj=[ 
    {
      _tag: 'CSidebarNavItem',
      name: name,
      to: `/${to}`,
     // icon: <CIcon style={{ color: 'black' }} name="cil-layers" customClasses="nav-icon" />,
    },
  ]
  
      return obj;
} 

export default _nav_custom;
