import React, { useState } from 'react'
import {
  CBadge,
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
  CImg,
  CButton,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CModal,
  CModalBody,
  CModalFooter,
  CModalHeader,
  CModalTitle,
  CRow,
  CForm,
  CInputGroup,
  CInputGroupPrepend,
  CInputGroupText,
  CInput,
  CInvalidFeedback,
  CValidFeedback
} from '@coreui/react'

import CIcon from '@coreui/icons-react'
import PowerSettingsNewIcon from '@material-ui/icons/PowerSettingsNew';
import LockOpenOutlinedIcon from '@material-ui/icons/LockOpenOutlined';
import UserProfile from './UserProfile';
import { config } from 'src/containers/API_Call_Constant';
import { appconstant } from 'src/containers/AppConstant';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import avatar from "src/assets/resource/avatar.jpg"
import Password_Field from 'src/views/validators/Password_Field';
import progressbar from 'src/views/progressbar/progressbar';
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';
import _ from 'lodash';
import API_Fetcher from './API_Fetcher';

function logout() {
  sessionStorage.clear()
  // UserProfile.setSeqnum("");
  // UserProfile.setName("");
  // UserProfile.setDashboardData("");

  window.location.replace(appconstant.url.API_URL);
}


const TheHeaderDropdown = () => {


  const [open, setOpen] = useState(false);
  const [modal, setModal] = useState(false);
  const [modal1, setModal1] = useState(false);
  const [oldpassword, setOldpassword] = useState();
  const [newpassword, setNewpassword] = useState();
  const [confirmpassword, setConfirmpassword] = useState();
  const [modalTitle, setModalTitle] = useState()
  const [modalDescription, setModalDescription] = useState()
  const [isLoading, setLoading] = useState(false);
  const [status, setStatus] = useState();
  const [decideoldpasswordfield, setDecideOldPasswordField] = useState()
  const [decidenewpasswordfield, setDecideNewPasswordField] = useState()
  const [decideconfirmpasswordfield, setDecideConfirmPasswordField] = useState()
 
  const [confirmstatus, setConfirmStatus] = useState(false);

  const handleClose = () => {
    setOpen(false);
  };
  const handleToggle = () => {
    setOpen(!open);
  };

  const useStyles = makeStyles((theme) => ({
    backdrop: {
      zIndex: theme.zIndex.drawer + 1,
      color: '#fff',
    },
  }));

  const classes = useStyles();


  function HandleChangePassword() {
    setConfirmStatus(false);
    setModal(true);

  }

  async function HandleSubmit() {



    if ((!oldpassword)) {
      setDecideOldPasswordField("is-invalid");
    }
    else {
      setDecideOldPasswordField("is-valid");
    }
    if ((!newpassword)) {
      setDecideNewPasswordField("is-invalid");
    }
    else {
      setDecideNewPasswordField("is-valid");
    }

    if (_.isEmpty(newpassword) || _.isEmpty(confirmpassword)) {
      setDecideConfirmPasswordField("is-invalid");
    }
    else if (newpassword == confirmpassword) {
      setConfirmStatus(true);
      setDecideConfirmPasswordField("is-valid");
      handleToggle();

      const url = config.url.API_URL;
      const GetReportURL = url + "/ediportal/api/v1/RequestHandler";

      const obj = {
        tag_name: 'ChangePassword_request',
        parameters: `${UserProfile.getSeqnum()}@splitter@${oldpassword}@splitter@${newpassword}@splitter@LiveDB`
      }

      const param = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(obj)
      }
     


      try {

        let { status, data } = await API_Fetcher(GetReportURL, param)


        setOpen(false);
        setOldpassword("");
        setNewpassword("");
        setConfirmpassword("");

        setStatus(status);
        switch (status) {

          case 200:

            setModal1(true);
            setModal(false);
            setModalTitle("Success");
            setModalDescription("Password Changed Successfully");
            setLoading(false);

            break;

          case 404:
            setLoading(false);
            setModal1(true);
            setModal(false);
            setModalTitle("Alert");
            setModalDescription("Password Does not match! Please Enter Correct Password");
            break;

          default:
            setLoading(false);
            setModal1(true);
            setModal(false);
            setModalTitle("Alert");
            setModalDescription("Error Occurred");
        }

      } catch (error) {
        setLoading(false);
        setModal1(true);
        setModal(false);
        setModalTitle("Network Error");
        setModalDescription(error.message);
      }



    }
    else{
      setDecideConfirmPasswordField("is-invalid");
    }


  }

  function CheckPassword() {


  }

  return (

    <>

        <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>

      <CRow>
        <CCol>
          <CCard>
            <CModal
              show={modal1}
              onClose={setModal1}
              color={status == 404 ? "warning" : status == 100 ? "info" : status == 200 ? "success" : "danger"}
            >
              <CModalHeader closeButton>
                <CModalTitle>{modalTitle}</CModalTitle>
              </CModalHeader>
              <CModalBody>
                {modalDescription}
              </CModalBody>
              <CModalFooter>
                <CButton
                  color={status == 404 ? "warning" : status == 100 ? "info" : status == 200 ? "success" : "danger"}
                  onClick={() => setModal1(false)}
                >Cancel</CButton>
              </CModalFooter>
            </CModal>
          </CCard>
        </CCol>
      </CRow>



      <CRow>
        <CCol>

          <CModal
            show={modal}
             onClose={setModal}
          >
            <CModalHeader >
              <CModalTitle>Change Password</CModalTitle>
            </CModalHeader>
            <CModalBody>
              <CForm

              >

                <CInputGroup className="mb-4">
                  <CInputGroupPrepend>
                    <CInputGroupText>
                      <CIcon name="cil-lock-locked" />
                    </CInputGroupText>
                  </CInputGroupPrepend>

                  <CInput value={oldpassword} className={decideoldpasswordfield} type="password" placeholder="OLD PASSWORD" autoComplete="one-time-code" onChange={(e) => { setOldpassword(e.target.value) }} />
                  <CInvalidFeedback >Please Enter OLD PASSWORD</CInvalidFeedback>
                  <CValidFeedback ></CValidFeedback>
                  {/* <Password_Field invalid_msg="Please Enter Password"  placeholder="OLD PASSWORD" valid_msg="Looks Good!" onChangeText={(oldpassword) => setOldpassword(oldpassword)} /> */}


                </CInputGroup>
                <CInputGroup className="mb-4">
                  <CInputGroupPrepend>
                    <CInputGroupText>
                      <CIcon name="cil-lock-locked" />
                    </CInputGroupText>
                  </CInputGroupPrepend>

                  <CInput value={newpassword} className={decidenewpasswordfield} type="password" placeholder="NEW PASSWORD" autoComplete="one-time-code" onChange={(e) => { setNewpassword(e.target.value) }} />
                  <CInvalidFeedback >Please Enter NEW PASSWORD</CInvalidFeedback>
                  <CValidFeedback ></CValidFeedback>
                  {/* <Password_Field invalid_msg="Please Enter Password" placeholder="NEW PASSWORD" valid_msg="Looks Good!" onChangeText={(newpassword) => setNewpassword(newpassword)}/> */}

                </CInputGroup>

                <CInputGroup className="mb-4">
                  <CInputGroupPrepend>
                    <CInputGroupText>
                      <CIcon name="cil-lock-locked" />
                    </CInputGroupText>
                  </CInputGroupPrepend>

                  <CInput value={confirmpassword} className={decideconfirmpasswordfield} type="password" placeholder="CONFIRM PASSWORD" autoComplete="one-time-code" onChange={(e) => { setConfirmpassword(e.target.value) }} />
                  <CInvalidFeedback >Confirm Password Does Not Match</CInvalidFeedback>
                  
                  { confirmstatus ? <CValidFeedback >Confirm Password Matches Successfully</CValidFeedback> : <CValidFeedback ></CValidFeedback>}
                 
                  {/* <Password_Field invalid_msg="Please Enter Password" placeholder="CONFIRM PASSWORD" valid_msg="Looks Good!" onChangeText={(confirmpassword) => setConfirmpassword(confirmpassword)} /> */}

                </CInputGroup>

                <CRow>
                  <CCol xs="12" >
                    <CButton color="primary" className="px-4 col-12 custom_button" onClick={() => HandleSubmit()}  >Change Password</CButton>
                    {/* {isLoading && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>} */}
                  </CCol>
                  </CRow>
                  <CRow>
                  <CCol xs="12" >
                  <div style={{marginBottom:"10px"}}></div>
                  </CCol>
                </CRow>
                  <CRow>
                  <CCol xs="12" >
                  <CButton color="primary" className="px-4 col-12 custom_button" onClick={()=> setModal(false) || setOldpassword("") || setNewpassword("") || setConfirmpassword("") } >Cancel</CButton>
                  </CCol>
                </CRow>

              </CForm>
            </CModalBody>

          </CModal>

        </CCol>
      </CRow>



      <CDropdown
        inNav
        className="c-header-nav-items mx-2"
        direction="down"
      >
        <CDropdownToggle className="c-header-nav-link" caret={false}>
          <div className="c-avatar">
            <AccountCircleIcon/>
            {/* <CImg
              src={avatar}
              className="c-avatar-img"
              alt="admin@bootstrapmaster.com"
            /> */}
          </div>
        </CDropdownToggle>
        <CDropdownMenu className="pt-0" placement="bottom-end">
          <CDropdownItem onClick={() => HandleChangePassword()}>
            <LockOpenOutlinedIcon className="mfe-2" />
            Change Password
          </CDropdownItem>
          <CDropdownItem onClick={() => { logout() }}>
            <PowerSettingsNewIcon className="mfe-2" />
            LogOut
          </CDropdownItem>
          {/* <CDropdownItem
          header
          tag="div"
          color="light"
          className="text-center"
        >
          <strong>Account</strong>
        </CDropdownItem>
        <CDropdownItem>
          <CIcon name="cil-bell" className="mfe-2" />
          Updates
          <CBadge color="info" className="mfs-auto">42</CBadge>
        </CDropdownItem>
        <CDropdownItem>
          <CIcon name="cil-envelope-open" className="mfe-2" />
          Messages
          <CBadge color="success" className="mfs-auto">42</CBadge>
        </CDropdownItem>
        <CDropdownItem>
          <CIcon name="cil-task" className="mfe-2" />
          Tasks
          <CBadge color="danger" className="mfs-auto">42</CBadge>
        </CDropdownItem>
        <CDropdownItem>
          <CIcon name="cil-comment-square" className="mfe-2" />
          Comments
          <CBadge color="warning" className="mfs-auto">42</CBadge>
        </CDropdownItem>
        <CDropdownItem
          header
          tag="div"
          color="light"
          className="text-center"
        >
          <strong>Settings</strong>
        </CDropdownItem>
        <CDropdownItem>
          <CIcon name="cil-user" className="mfe-2" />Profile
        </CDropdownItem>
        <CDropdownItem>
          <CIcon name="cil-settings" className="mfe-2" />
          Settings
        </CDropdownItem>
        <CDropdownItem>
          <CIcon name="cil-credit-card" className="mfe-2" />
          Payments
          <CBadge color="secondary" className="mfs-auto">42</CBadge>
        </CDropdownItem>
        <CDropdownItem>
          <CIcon name="cil-file" className="mfe-2" />
          Projects
          <CBadge color="primary" className="mfs-auto">42</CBadge>
        </CDropdownItem>
        <CDropdownItem divider />
        <CDropdownItem>
          <CIcon name="cil-lock-locked" className="mfe-2" />
          Lock Account
        </CDropdownItem> */}
        </CDropdownMenu>
      </CDropdown>
    </>
  )
}

export default TheHeaderDropdown
