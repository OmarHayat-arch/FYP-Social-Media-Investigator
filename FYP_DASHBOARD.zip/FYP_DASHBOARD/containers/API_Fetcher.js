
import React from "react";
 
// import useSWR from 'swr'




 
// const fetcher = (...args) => fetch(...args).then((res) => res.json())
 
//  function API_Fetcher(param) {
//     console.log(param)
//     const { data: result, error } = useSWR(param, fetcher)
     
//     if (error) return alert("error")
//     if (!result) return alert("loading")
//     return alert("ok")
// }



  // async function API_Fetcher(param) {
  //    const headers = new Headers();
  //    const dataRequest = new Request(param, {
  //      headers: headers,
  //    });
   
  //    const response = await fetch(dataRequest);
  //    const data = await response.json();
  //    return data;
  //  }
   
   
  async function API_Fetcher(url, param) {
     const response = await fetch(url,param);
      
      const status = await response.status;
      if(status == 200){
      var data = await response.json();
      }

      return {status , data};

    // fetch(url, param)
    // .then(response => response.json())
  }
  





export default API_Fetcher;