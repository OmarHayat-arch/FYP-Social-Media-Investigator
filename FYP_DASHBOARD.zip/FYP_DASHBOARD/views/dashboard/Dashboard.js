import React, { useEffect, useState } from 'react'
import {
  CBadge,
  CButton,
  CButtonGroup,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CProgress,
  CRow,
  CCreateElement,
  CWidgetIcon,
  CCallout,
  CSidebarNavDivider,
  CSidebarNavDropdown,
  CSidebarNavItem,
  CSidebarNavTitle,
} from '@coreui/react'

import Chart from "react-google-charts";
import _ from 'lodash.isequal'

import {
  CChartPie,
} from '@coreui/react-chartjs'

import _nav_custom from 'src/containers/_nav_custom';
import { config } from 'src/containers/API_Call_Constant';
import userprofile from 'src/containers/UserProfile';
import API_Fetcher from 'src/containers/API_Fetcher';
import CIcon from '@coreui/icons-react'
import progressbar from '../../views/progressbar/progressbar';
import UserProfile from 'src/containers/UserProfile';
import { Nav } from 'react-bootstrap';
import Report from '../Reports/Report';
import User from '../users/User';


const Dashboard = () => {






  return (
    <>

      {/* Widget Start */}

      <CRow>
        <CCol xs="12" sm="6" lg="4">
          <CWidgetIcon
            // header={res == "" ? progressbar(1) : ("Empty" in res[0].data) ? "No Files Submitted today" : (Object.values(res[0].data)[2]) + " Files Submitted today"}
            // text={res == "" ? "" : ("Empty" in res[0].data) ? "No Claim(s)" : Object.values(res[1].data)[0] + " Claim(s)"}
            header={"Total Tweets Today"}
            text={"446"}
            color="success"
          >
            <CIcon width={24} name="cil-calendar" className="icon icon-xl" />
          </CWidgetIcon>
        </CCol>
        <CCol xs="12" sm="6" lg="4">
          <CWidgetIcon
            // header={res == "" ? progressbar(1) : "Waiting for Processing"}
            // text={res == "" ? "" : ("Empty" in res[1].data) ? "No Files" : Object.values(res[1].data)[0]}
            header={"Total Positive Tweets Today"}
            text={"206"}
            color="success"
          >
            <CIcon width={24} name="cil-file" className="icon icon-xl" /></CWidgetIcon>
        </CCol>
        <CCol xs="12" sm="6" lg="4">
          <CWidgetIcon
            // header={res == "" ? progressbar(1) : "New ERA’s"}
            // text={res == "" ? "" : ("Empty" in res[2].data) ? "No " : <a href="#" className="customERA">{ERA}</a>}
            header={"Total Negative Tweets Today"}
            text={"240"}
            color="success"
          >
            <CIcon width={24} name="cil-dollar" className="icon icon-xl" /></CWidgetIcon>
        </CCol>
      </CRow>

      <CRow>
        <CCol xs="12" sm="6" lg="12">
          <CCard>
            <CCardHeader>
              <small>
                <strong>Sentimental Analysis</strong>
              </small>
            </CCardHeader>
            <CCardBody>
              <Chart
                width={'100%'}
                height={'300px'}
                chartType="Bar"
                loader={<div>Loading Chart</div>}
                data={[
                  ['Trend', 'Positive', 'Negative'],
                  ['#CIVILWARINPAK', 1000, 400],
                  ['#IMRANKHANZINDABAD', 1170, 460],
                  ['#OLYMPICS', 660, 1120],
                  ['#TERRORISM', 1030, 540],
                ]}
                options={{
                  // Material design options
                  chart: {
                    title: 'Model Performance',
                    subtitle: 'Senimental Analaysis of Social Media trends',
                  },
                }}
                // For tests
                rootProps={{ 'data-testid': '2' }}
              />
            </CCardBody>
          </CCard>
        </CCol>

</CRow>
<CRow>
        <CCol xs="12" sm="6" lg="12">
          <CCard>
            <CCardHeader>
              <small>
                <strong>Sentimental Analysis</strong>
              </small>
            </CCardHeader>
            <CCardBody>
              <Chart
                width={'100%'}
                height={'300px'}
                chartType="AreaChart"
                loader={<div>Loading Chart</div>}
                data={[
                  ['Year', 'Positive', 'Ngeative'],
                  ['#CIVILWARINPAK', 1000, 400],
                  ['#IMRANKHANZINDABAD', 1170, 460],
                  ['#OLYMPICS', 660, 1120],
                  ['#TERRORISM', 1030, 540],
                ]}
                options={{
                  title: 'Model Performance',
                  chartArea: { left: 'auto', top: 30, width: '100%', height: '100%' },
                  hAxis: { title: 'Year', titleTextStyle: { color: '#333' } },
                  vAxis: { minValue: 0 },
                  // For the legend to fit, we make the chart area smaller
                  chartArea: { width: '50%', height: '70%' },
                  // lineWidth: 25
                }}
                // For tests
                rootProps={{ 'data-testid': '1' }}
              />
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    





    </>
  )
}

export default Dashboard
