import React, { useEffect, useState } from 'react';

import {
    CButton,
    CCard,
    CCardBody,
    CTabPane,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CNavLink,
    CTabContent,
    CNavItem,
    CNav,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CTabs,
    CSwitch
} from '@coreui/react'
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';
import EligibilityDatatable from 'src/views/datatable/EligibilityDatatable';
import progressbar from '../progressbar/progressbar';
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';


const customized_col_names = ["Coverage Level", "Service Type", "Insurance Type", "Time Period", "Amount", "Authorization", "Network Indicator", "Message"];
const customized_col_index = [0, 1, 2, 3, 4, 5, 6, 7];

const customized_col_names_other = ["Benefit", "Coverage Level", "Service Type", "Insurance Type", "Time Period", "Amount", "Authorization", "Network Indicator", "Message"];
const customized_col_index_other = [0, 1, 2, 3, 4, 5, 6, 7, 8];

const cells = [""]



const EligibilityDetail = (props) => {

    const [isLoading, setLoading] = useState(false);
    const [data, setData] = useState();
    const [open, setOpen] = useState(false);

    const handleClose = () => {
        setOpen(false);
    };
    const handleToggle = () => {
        setOpen(!open);
    };

    const useStyles = makeStyles((theme) => ({
        backdrop: {
            zIndex: theme.zIndex.drawer + 1,
            color: '#fff',
        },
    }));

    const classes = useStyles();

    useEffect(() => {

        async function LoadData() {
            handleToggle();

            const url = config.url.API_URL;
            const GetReportURL = url + "/ediportal/api/v1/RequestHandler";

            const obj = {
                tag_name: 'EligibilityDetail_request',
                parameters: `${props.rowData[7]}@splitter@LiveDB`
            }

            const param = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(obj)
            }

            try {
                let { status, data } = await API_Fetcher(GetReportURL, param)



                console.log(data);
                setData(data);
                setLoading(true);
                setOpen(false);
                // CategoryRecord(data[1]);
                // StatusRecord(data[2]);
                setLoading(true);


            } catch (error) {
            }
        }
        LoadData();
    }, [])



    function HanldleSubmit() {
        props.onChange(false);

    }
    return (
        <>

            <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>


            <CRow>
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardHeader className="Modelheader">
                            <CRow>
                                <CCol className="col-9">
                                    <small>
                                        <strong>Eligibility Detail</strong>
                                    </small>
                                </CCol>
                                <CCol className="d-flex justify-content-end col-3">
                                    <CButton onClick={() => HanldleSubmit()} type="submit" color="primary" className="custom_button">BACK</CButton>
                                </CCol>
                            </CRow>
                        </CCardHeader>
                        <CCardBody >

                            <CTabs>
                                <CNav >
                                    <CNavItem>
                                        <CNavLink >
                                            Summary
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink >
                                            Coverage
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem >
                                        <CNavLink >
                                            Co-Insurance
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Co-Payment
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Limitations
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Deductible
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Out of Pocket (Stop Loss)
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Non-Covered
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Primary Care Provider
                                        </CNavLink>
                                    </CNavItem>

                                    <CNavItem>
                                        <CNavLink>
                                            Others
                                        </CNavLink>
                                    </CNavItem>
                                </CNav>
                                <CTabContent>
                                    <CTabPane>

                                        <CRow>
                                            <CCol xs="12" sm="6" md="6">
                                                <CCard style={{ border: "none" }}>
                                                    <CCardBody>
                                                        <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                                            <CLabel className="headerBold">Patient</CLabel>
                                                        </CCol>
                                                        <CFormGroup row>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Name</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].Patient}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Sex</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].Gender}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">DOB</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].Dob}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Address</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].PatientAddress}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>
                                                        </CFormGroup>
                                                    </CCardBody>
                                                </CCard>
                                            </CCol>


                                            <CCol xs="12" sm="6" md="6">
                                                <CCard style={{ border: "none" }}>
                                                    <CCardBody>

                                                        <CFormGroup row>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Copayment</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].Copay}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Deductible</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].Deductable}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Eligibility Date</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].EligibilityDate}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">DOS</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].ServiceDate}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>
                                                        </CFormGroup>
                                                    </CCardBody>
                                                </CCard>
                                            </CCol>
                                        </CRow>



                                        <CRow>
                                            <CCol xs="12" sm="6" md="6">
                                                <CCard style={{ border: "none" }}>
                                                    <CCardBody>
                                                        <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                                            <CLabel className="headerBold">Provider</CLabel>
                                                        </CCol>
                                                        <CFormGroup row>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Name</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].RenderingProvider}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">NPI</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].Npi}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>


                                                        </CFormGroup>
                                                    </CCardBody>
                                                </CCard>
                                            </CCol>
                                        </CRow>


                                        <CRow>
                                            <CCol xs="12" sm="6" md="6">
                                                <CCard style={{ border: "none" }}>
                                                    <CCardBody>
                                                        <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                                            <CLabel className="headerBold">Payer</CLabel>
                                                        </CCol>
                                                        <CFormGroup row>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Payer Name</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].PayerName}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Payer ID</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].PayerId}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>


                                                        </CFormGroup>
                                                    </CCardBody>
                                                </CCard>
                                            </CCol>
                                        </CRow>


                                        <CRow>
                                            <CCol xs="12" sm="6" md="6">
                                                <CCard style={{ border: "none" }}>
                                                    <CCardBody>
                                                        <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                                            <CLabel className="headerBold">Insured</CLabel>
                                                        </CCol>
                                                        <CFormGroup row>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Name</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].Insrued}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">ID Num</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].PolicyNum}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Relation</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].Relation}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Group #</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].GroupNum}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Plan Begin</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].PlanBeginDate}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Plan End</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].PlanEndDate}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>

                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                <CFormGroup row className="customizeRow">
                                                                    <CCol xs="12" sm="12" md="6" lg="6">
                                                                        <CLabel className="labelbold" htmlFor="select">Address</CLabel>
                                                                    </CCol>
                                                                    <CCol xs="12" sm="12" md="6" lg="6" >
                                                                        {isLoading ? <CLabel className="valuelabel" htmlFor="select">{"Empty" in data[0].data ? "" : data[0].data[0].InsuredAddress}</CLabel> : ""}
                                                                    </CCol>
                                                                </CFormGroup>
                                                            </CCol>


                                                        </CFormGroup>
                                                    </CCardBody>
                                                </CCard>
                                            </CCol>
                                        </CRow>

                                    </CTabPane>
                                    <CTabPane>

                                        {isLoading ? <EligibilityDatatable result={data.length != 10 ? data[1] : data[1]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}

                                    </CTabPane>
                                    <CTabPane>

                                        {isLoading ? <EligibilityDatatable result={data.length != 10 ? data[1] : data[2]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}
                                    </CTabPane>
                                    <CTabPane>

                                        {isLoading ? <EligibilityDatatable result={data.length != 10 ? data[1] : data[3]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}
                                    </CTabPane>
                                    <CTabPane>

                                        {isLoading ? <EligibilityDatatable result={data.length != 10 ? data[1] : data[4]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}
                                    </CTabPane>
                                    <CTabPane>

                                        {isLoading ? <EligibilityDatatable result={data.length != 10 ? data[1] : data[5]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}
                                    </CTabPane>
                                    <CTabPane>

                                        {isLoading ? <EligibilityDatatable result={data.length != 10 ? data[1] : data[6]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}
                                    </CTabPane>
                                    <CTabPane>

                                        {isLoading ? <EligibilityDatatable result={data.length != 10 ? data[1] : data[7]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}
                                    </CTabPane>
                                    <CTabPane>

                                        {isLoading ? <EligibilityDatatable result={data.length != 10 ? data[1] : data[8]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}
                                    </CTabPane>
                                    <CTabPane>

                                        {isLoading ? <EligibilityDatatable result={data.length != 10 ? data[1] : data[9]} column_name={customized_col_names_other} column_index={customized_col_index_other} cells={cells} /> : ""}
                                    </CTabPane>
                                </CTabContent>
                            </CTabs>


                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    )
}

export default EligibilityDetail;