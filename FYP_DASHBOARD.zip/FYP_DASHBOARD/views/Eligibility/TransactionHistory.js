import React, { useState } from 'react';
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CSwitch
} from '@coreui/react'
import moment from 'moment';
import progressbar from '../progressbar/progressbar';
import API_Fetcher from 'src/containers/API_Fetcher';
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';
import UserProfile from 'src/containers/UserProfile';
import { config } from 'src/containers/API_Call_Constant';
import EligibilityTransactionHistoryDatatable from '../datatable/EligibilityTransactionHistoryDatatable';



const customized_col_names = ["Patient", "Provider Claim #", "Payer", "Provider", "Status", "Eligibility Date", "Service Date", ""];
const customized_col_index = [0, 1, 2, 3, 4, 5, 6, 7];
const cells = ["ProviderClaimNum"]

const TransactionHistory = () => {

    var d = new Date();
    d.setDate(d.getDate() - 29);

    const [EligibilityDateFrom, setEligibilityDateFrom] = useState(moment(d).format('YYYY-MM-DD'));
    const [EligibilityDateTo, setEligibilityDateTo] = useState(moment(new Date).format('YYYY-MM-DD'));
    const [Status, setStatus] = useState("ALL");
    const [ServiceDateFrom, setServiceDateFrom] = useState();
    const [ServiceDateTo, setServiceDateTo] = useState();
    const [PatientLastName, setPatientLastName] = useState();
    const [PatientFirstName, setPatientFirstName] = useState();
    const [open, setOpen] = useState(false);
    const [isLoading,setLoading] = useState(false);
    const [data, setData] = useState();
   

const handleClose = () => {
    setOpen(false);
  };
  const handleToggle = () => {
    setOpen(!open);
  };

  const useStyles = makeStyles((theme) => ({
    backdrop: {
      zIndex: theme.zIndex.drawer + 1,
      color: '#fff',
    },
  }));

  const classes = useStyles();

async function HandleSearch(){
    handleToggle();
const url = config.url.API_URL;
const GetReportURL = url +"/ediportal/api/v1/RequestHandler";

const obj = {
  tag_name: 'EligibilityTransactionHistory_request',
  parameters: `${UserProfile.getSeqnum()}@splitter@${EligibilityDateFrom}@splitter@${EligibilityDateTo}@splitter@${Status}@splitter@${ServiceDateFrom}@splitter@${ServiceDateTo}@splitter@${PatientLastName}@splitter@${PatientFirstName}@splitter@LiveDB`
}

const param = {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(obj)
}

try {
let { status, data } = await API_Fetcher(GetReportURL, param)


setData(data[0]);
setLoading(true);
setOpen(false);

} catch (error) {
}

}

    


    return (
        <>
            <CRow id="EligibilityTransactionHistoryFilter">
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardBody>
                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <label className="custom_label" htmlFor="date-input" >Claim Status Date From</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CInput onKeyDown={(e) => e.preventDefault()} value={EligibilityDateFrom == undefined ? "" : moment(EligibilityDateFrom).format('YYYY-MM-DD')} onChange={(e) => setEligibilityDateFrom(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="Eligibility Date From" />
                                            <div class="divider"></div>
                                            {EligibilityDateFrom == undefined ? "" : <button onClick={() => { setEligibilityDateFrom(undefined) }} className="custom_clear">X</button>}
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Claim Status Date To</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CInput onKeyDown={(e) => e.preventDefault()} value={EligibilityDateTo == undefined ? "" : moment(EligibilityDateTo).format('YYYY-MM-DD')} onChange={(e) => setEligibilityDateTo(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="Eligibility Date To" />
                                            <div class="divider"></div>
                                            {EligibilityDateTo == undefined ? "" : <button onClick={() => { setEligibilityDateTo(undefined) }} className="custom_clear">X</button>}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Status</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CSelect onChange={(e) => setStatus(e.target.value)} custom name="select" id="common">
                                                <option value="ALL">ALL</option>
                                                <option value="PAYER REJECTED">PAYER REJECTED</option>
                                                <option value="PRACTICEEHR REJECTED">PRACTICEEHR REJECTED</option>
                                            </CSelect>

                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                            </CRow>


                            <CRow>


                            <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Service Date From</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()} value={ServiceDateFrom == undefined ? "" : moment(ServiceDateFrom).format('YYYY-MM-DD')} onChange={(e) => setServiceDateFrom(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="Service Date From" />
                                            <div class="divider"></div>
                                            {ServiceDateFrom == undefined ? "" : <button onClick={() => { setServiceDateFrom(undefined) }} className="custom_clear">X</button>}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">DOS To</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CInput onKeyDown={(e) => e.preventDefault()} value={ServiceDateTo == undefined ? "" : moment(ServiceDateTo).format('YYYY-MM-DD')} onChange={(e) => setServiceDateTo(moment(e.target.value).format('MM-DD-YYYY'))} type="date" name="date-input" placeholder="Service Date To" />
                                            <div class="divider"></div>
                                            {ServiceDateTo == undefined ? "" : <button onClick={() => { setServiceDateTo(undefined) }} className="custom_clear">X</button>}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Patient last Name</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setPatientLastName(e.target.value)} type="text" placeholder="Patient Last Name" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                               
                            
                            </CRow>


                            <CRow>
                             
                            <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Patient First Name</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onChange={(e) => setPatientFirstName(e.target.value)} type="text" placeholder="Patient First Name" />

                                        </CCol>
                                    </CFormGroup>
                                </CCol>

      
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">

                                        </CCol>
                                        <CCol xs="12" md="9" className="form">


                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">

                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                        <CButton type="submit" onClick={()=>{HandleSearch()}} color="primary" className="custom_button col-md-12">Search</CButton>
                                            {open && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>}
                                        </CCol>


                                    </CFormGroup>
                                </CCol>
                            </CRow>

                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            {isLoading ? <EligibilityTransactionHistoryDatatable result={data} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}
        </>
    )
}

export default TransactionHistory;