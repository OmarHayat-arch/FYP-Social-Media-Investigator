import React from 'react';
import {
    CButton,
    CCreateElement,
    CCard,
    CCardBody,
    CLabel,
    CCardGroup,
    CCol,
    CContainer,
    CForm,
    CInput,
    CInputGroup,
    CCardHeader,
    CModal,
    CModalHeader,
    CModalTitle,
    CModalBody,
    CModalFooter,
    CInputGroupPrepend,
    CInputGroupText,
    CValidFeedback,
    CInvalidFeedback,
    CRow,
    CTabPane,
    CNavLink,
    CTabs,
    CNav,
    CNavItem,
    CTabContent,
    CSidebarNavDivider,
    CSidebarNavDropdown,
    CSidebarNavItem,
    CSidebarNavTitle
} from '@coreui/react'
import RunEligibility from './RunEligibility';
import TransactionHistory from './TransactionHistory';


function Eligibility() {

    return (
        <>
            <CTabs>
             <CNav id="EligibilityTab">
                    <CNavItem>
                        <CNavLink >
                            Run Eligibility
                        </CNavLink>
                    </CNavItem>
                    <CNavItem >
                        <CNavLink >
                            Transaction History
                        </CNavLink>
                    </CNavItem>

                </CNav>
                <CTabContent>
                    <CTabPane>

                        <RunEligibility />
                    </CTabPane>
                    <CTabPane>
                        <TransactionHistory />


                    </CTabPane>

                </CTabContent>
            </CTabs>
        </>
    )
}

export default Eligibility