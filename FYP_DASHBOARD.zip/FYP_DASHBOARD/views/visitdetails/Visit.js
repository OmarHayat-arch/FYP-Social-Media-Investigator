import React,{useState,useEffect} from 'react';
import {
    CBadge,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CRow,
    CCollapse,
    CFormGroup,
    CFade,
    CLabel,
    CSwitch,
    CLink
} from '@coreui/react'
import Payer_Billing_ProviderBAL from './Payer_Billing_ProviderBAL';
import FieldsController from '../validators/FieldsController';
import Label_Field from '../validators/Label_Field';

const Visit = (props) => {

    useEffect(() => {

    }, [props])


    return (
        <>
            <CRow>
            <CCol md="12" className="text-right" style={{  color: "#D35E59" }}>
                            <Label_Field name= " * Note: CLIA # change will not reflect in Practice Management Solution." visibility="labelbold text-left" />
                        </CCol>
                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="Visit Information" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(0, 14).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>




                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(14, 28).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>


                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{  color: "#066fa1" }}>
                            <Label_Field name="" visibility="labelbold text-left" />
                        </CCol>
                            <CFormGroup row>
                                { props.result.slice(28, 42).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController checked={e.checked} disabled={e.disabled} maxlength={e.maxlength} values={e.values}  type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                          
                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

            </CRow>


            <CRow>
   

</CRow>


        </>
    )
}

export default Visit;