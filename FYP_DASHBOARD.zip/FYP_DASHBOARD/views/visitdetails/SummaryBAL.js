import React, { useState, useEffect } from 'react';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';

const SummaryBAL = (props, status) => {


    const obj = [
        {
            "type": "label",
            "name": "Claim #",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.ProvClaimNum) ? props.ProvClaimNum : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Payer Name",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.PayerName) ? props.PayerName : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Payer ID",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.PayerId) ? props.PayerId : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Patient",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.Patient) ? props.Patient : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Policy#",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.InsuredId) ? props.InsuredId : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "DOS",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.Dos) ? props.Dos : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Received By PracticeEHR",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.ReceiveDate) ? props.ReceiveDate : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Forwarded to Payer",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.ForwardedToPayerDate) ? props.ForwardedToPayerDate : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Status Date",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.AcceptedDate) ? props.AcceptedDate : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Payer Rejected",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.RejectedDate) ? props.RejectedDate : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Status",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.ActualStatusCode) ? props.ActualStatusCode : "N/A",
            "color": (props.ActualStatusCode) ? (props.StatusForClient == "F" || props.StatusForClient == "J") ? "#FF0000" : "#2A587C" : "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "",
            "color": "",
            "visibility": ""
        },
        {
            "type": "label",
            "name": (props.RejectionReason) ? props.RejectionReason : ("Empty" in status) ? "N/A" : status.DESCRIPTION,
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "IHCFA Tracking #",
            "color": "",
            "visibility": (props.CaseType && props.CaseType == "WC" || props.CaseType == "NF") ? "labelbold" : "invisible"
        },
        {
            "type": "label",
            "name": (props.IhcfaTrackingNum) ? props.IhcfaTrackingNum : "N/A",
            "color": "",
            "visibility": (props.CaseType && props.CaseType == "WC" || props.CaseType == "NF") ? "visible" : "invisible"
        },
        {
            "type": "label",
            "name": "IHCFA Comments",
            "color": "",
            "visibility": (props.CaseType && props.CaseType == "WC" || props.CaseType == "NF") ? "labelbold" : "invisible"
        },
        {
            "type": "label",
            "name": (props.IhcfaComments) ? props.IhcfaComments : "N/A",
            "color": "",
            "visibility": (props.CaseType && props.CaseType == "WC" || props.CaseType == "NF") ? "visible" : "invisible"
        },
        {
            "type": "label",
            "name": "Case Type",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.CaseType) ? props.CaseType : "",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Billing Provider",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.BillingProvName) ? props.BillingProvName : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "NPI",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.BillingProvNpi) ? props.BillingProvNpi : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Rendering Provider",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.RendProvName) ? props.RendProvName : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Claim Amount",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.ClaimAmount) ? props.ClaimAmount : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Paid Amount",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.X12835PaymentSeqNum) ? props.X12835PaymentSeqNum : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "id": "showpaymentdetail",
            "type": "button",
            "name": "Show Payment Detail",
            "color": "#026f7b ",
            "click": "HandleShowPayment",
            "visibility": (props.X12835HeaderSeqNum && props.X12835PaymentSeqNum) ? "visible" : "invisible"
        },
        {
            "type": "label",
            "name": "Eligibility",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.EligResponseDesc) ? props.EligResponseDesc : "N/A",
            "color": (props.EligResponseDesc == "Rejected") ? "#FF0000" : (props.EligResponseDesc == "Active") ? "#29AA4D" : (props.EligResponseDesc == "Inactive") ? "#FFAA2A" : "",
            "visibility": "visible"
        },

        {
            "type": "button",
            "name": "Get Eligibility",
            "color": "#026f7b ",
            "click": "GetEligibility",
            "visibility": (props.EligibiltyFlag == "Y") ? "visible" : "invisible"
        },
        {
            "type": "",
            "name": "",
            "color": "",
            "visibility": ""
        },
        {
            "type": "label",
            "name": "Plan Begin Date",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.PlanBeginDate) ? props.PlanBeginDate.replace('12:00:00 AM', '') : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Plan End Date",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.PlanEndDate) ? props.PlanEndDate.replace('12:00:00 AM', '') : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "type": "label",
            "name": "Copay",
            "color": "",
            "visibility": "labelbold"
        },
        {
            "type": "label",
            "name": (props.Copay) ? props.Copay : "N/A",
            "color": "",
            "visibility": "visible"
        },
        {
            "id": "showeligibility",
            "type": "button",
            "name": "Show Eligibility Detail",
            "color": "#026f7b ",
            "click": "HandleEligibility",
            "visibility": (props.Inbound270FileSeqNum) ? "visible" : "invisible"
        },

    ]

    return obj;

}

export default SummaryBAL;


