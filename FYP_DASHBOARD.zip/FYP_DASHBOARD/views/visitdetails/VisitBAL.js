import React, { useState, useEffect } from 'react';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';


const VisitBAL = (props) => {



    const Special_Program_Code = [{ data: [
        { DISPLAY_VALUE: "--Select--", VALUE: "" }, 
        { DISPLAY_VALUE: "EPSDT or Child Health Assessment Program", VALUE: "01" }, 
        { DISPLAY_VALUE: "Special Federal Funding", VALUE: "03" },
        { DISPLAY_VALUE: "Disability", VALUE: "05" },
        { DISPLAY_VALUE: "Induced Abortion, Danger to Life", VALUE: "07" },
        { DISPLAY_VALUE: "Induced Abortion, Rape or Incest", VALUE: "08" },
        { DISPLAY_VALUE: "Second Opinion or Surgery", VALUE: "09" },
    
    ] }];

    const Daily_Reason_Code = [{ data: [
        { DISPLAY_VALUE: "--Select--", VALUE: "" }, 
        { DISPLAY_VALUE: "Proof of Eligibility Unknown", VALUE: "1" }, 
        { DISPLAY_VALUE: "Litigation", VALUE: "2" },
        { DISPLAY_VALUE: "Authorization Delays", VALUE: "3" },
        { DISPLAY_VALUE: "Certifying Provider", VALUE: "4" },
        { DISPLAY_VALUE: "Supplying Billing Forms", VALUE: "5" },
        { DISPLAY_VALUE: "Delivery of Custom-made Appliances", VALUE: "6" },
        { DISPLAY_VALUE: "Third Party Processing Delay", VALUE: "7" },
        { DISPLAY_VALUE: "Eligibility Determination", VALUE: "8" },
        { DISPLAY_VALUE: "Original Rejected - Unrelated to the Billing Limitation Rules", VALUE: "9" },
        { DISPLAY_VALUE: "Administration Delay in Prior Approval Process", VALUE: "10" },
        { DISPLAY_VALUE: "Other", VALUE: "11" },
    
    ] }];

    const EPSDT_Refferral = [{ data: [
        { DISPLAY_VALUE: "--Select--", VALUE: "" }, 
        { DISPLAY_VALUE: "Available - Not Used", VALUE: "AV" }, 
        { DISPLAY_VALUE: "Not Used", VALUE: "NU" },
        { DISPLAY_VALUE: "Patient Under Treatment", VALUE: "S2" },
        { DISPLAY_VALUE: "New Services Requested", VALUE: "ST" },
        
    ] }];

    const Accident_Cause = [{ data: [
        { DISPLAY_VALUE: "--Select--", VALUE: "" }, 
        { DISPLAY_VALUE: "Auto Accident", VALUE: "AA" }, 
        { DISPLAY_VALUE: "Employment", VALUE: "EM" },
        { DISPLAY_VALUE: "Patient Under Treatment", VALUE: "S2" },
        { DISPLAY_VALUE: "Other Accident", VALUE: "OA" },
        
    ] }];

    const Claim_Frequency = [{ data: [
        { DISPLAY_VALUE: "ORIGINAL", VALUE: "1" }, 
        { DISPLAY_VALUE: "CORRECTED", VALUE: "6" },
        { DISPLAY_VALUE: "REPLACEMENT", VALUE: "7" },
        { DISPLAY_VALUE: "VOID", VALUE: "8" },
        
    ] }];

    const Service_Exception_Code = [{ data: [
        { DISPLAY_VALUE: "--Select--", VALUE: "" }, 
        { DISPLAY_VALUE: "Immediate/Urgent Care", VALUE: "1" },
        { DISPLAY_VALUE: "Services Rendered in a Retroactive Period", VALUE: "2" },
        { DISPLAY_VALUE: "Client has Temporary Medicaid", VALUE: "4" },
        { DISPLAY_VALUE: "Request from County for Second Opinion to Recipient can work", VALUE: "5" },
        { DISPLAY_VALUE: "Request for Override Pending", VALUE: "6" },
        { DISPLAY_VALUE: "Special Handling", VALUE: "7" },
        
        
    ] }];

    
    const obj = [
        {
            "type": "label",
            "name": "Claim #",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Clm01ProviderClaimNum) ? props.Clm01ProviderClaimNum : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"38",
        },
        {
            "type": "label",
            "name": "PAN",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Ref02G1PriorAuthNum) ? props.Ref02G1PriorAuthNum : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"50",
        },
        {
            "type": "label",
            "name": "Accident State",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Clm114State) ? props.Clm114State : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"",
        },
        {
            "type": "label",
            "name": "Injury(Accident)",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "date",
            "name": (props.Dtp03AccidentDate) ? props.Dtp03AccidentDate : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
        },
        {
            "type": "label",
            "name": "Hospital Admission",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "date",
            "name": (props.Dtp03435AdmissionDate) ? props.Dtp03435AdmissionDate : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
        },
        {
            "type": "label",
            "name": "DCN/ICN",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Ref02F8ClaimCntNum) ? props.Ref02F8ClaimCntNum : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"50",
        },
        {
            "type": "label",
            "name": "Special Program Code",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Clm12SpecialProgram) ? props.Clm12SpecialProgram : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            "values":Special_Program_Code
        },
        {
            "type": "label",
            "name": "Claim Amount",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Clm02FeeAmount) ? props.Clm02FeeAmount : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":""
        },
        {
            "type": "label",
            "name": "Refferral #",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Ref029fReferralNum) ? props.Ref029fReferralNum : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"50"
        },
        {
            "type": "label",
            "name": "LMP Date",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "date",
            "name": (props.Dtp03LmpDate) ? props.Dtp03LmpDate : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":""
        },
        {
            "type": "label",
            "name": "Initial Treatment",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "date",
            "name": (props.Dtp03InitialTreatDate) ? props.Dtp03InitialTreatDate : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":""
        },
        {
            "type": "label",
            "name": "Hospital Discharge",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "date",
            "name": (props.Dtp03435AdmissionDate) ? props.Dtp03435AdmissionDate : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":""
        },
        {
            "type": "label",
            "name": "Delay Reason Code",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Clm20DelayReason) ? props.Clm20DelayReason : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            'values':Daily_Reason_Code
        },
        {
            "type": "label",
            "name": "EPSDT REFERRAL",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Crc03EpsdtCondInd1) ? props.Crc03EpsdtCondInd1 : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            'values':EPSDT_Refferral
        },
        {
            "type": "label",
            "name": "CLIA #",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "text",
            "name": (props.Ref02X4CliaCode) ? props.Ref02X4CliaCode : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"50",
            
        },
        {
            "type": "label",
            "name": "Accident Cause",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Clm111RelatedCause) ? props.Clm111RelatedCause : "",
            "color": "",
            "visibility": "visible",
            "disabled": true,
            "maxlength":"",
            "values":Accident_Cause
            
        },
        {
            "type": "label",
            "name": "EMG",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "checkbox",
            "name": (props.EmgFlag) ? props.EmgFlag : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            "checked":(props.EmgFlag == "Y") ? true : false
            
        },
        {
            "type": "label",
            "name": "Last Seen",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "date",
            "name": (props.Dtp03LastSeenDate) ? props.Dtp03LastSeenDate : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            
        },
  
        {
            "type": "label",
            "name": "Last X-Ray",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "date",
            "name": (props.Dtp03XrayDate) ? props.Dtp03XrayDate : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            
        },
        {
            "type": "label",
            "name": "Claim Frequency",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Clm053ClaimFrequency) ? props.Clm053ClaimFrequency : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            "values":Claim_Frequency
            
        },
        {
            "type": "label",
            "name": "Service Exception Code",
            "color": "#066fa1",
            "visibility": ""
        },
        {
            "type": "dropdown",
            "name": (props.Ref024nServiceAuthCode) ? props.Ref024nServiceAuthCode : "",
            "color": "",
            "visibility": "visible",
            "disabled": false,
            "maxlength":"",
            "values":Service_Exception_Code
            
        },
    ]

    return obj;

}

export default VisitBAL;


