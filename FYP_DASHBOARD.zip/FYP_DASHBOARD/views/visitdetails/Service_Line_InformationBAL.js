import FieldsController from "../validators/FieldsController";


const Service_Line_InformationBAL = (verify,data) =>{

  console.log(verify);
  console.log(data);
    
    const POS = [{ data: [
        { DISPLAY_VALUE: "OFFICE", VALUE: "11" },
        { DISPLAY_VALUE: "INPATIENT HOSPITAL", VALUE: "21" }, 
        { DISPLAY_VALUE: "EMERGENCY ROOM HOSPITAL", VALUE: "23" },
        { DISPLAY_VALUE: "OUTPATIENT HOSPITAL", VALUE: "22" },
        { DISPLAY_VALUE: "PATIENT'S HOME", VALUE: "12" },
        { DISPLAY_VALUE: "AMBULATORY SURGICAL CENTER", VALUE: "24" },
        { DISPLAY_VALUE: "BIRTHING CENTER", VALUE: "25" },
        { DISPLAY_VALUE: "MILITARY TREATMENT FACILITY (MTF)", VALUE: "26" },
        { DISPLAY_VALUE: "SKILLED NURSING FACILITY (SNF)", VALUE: "31" },
        { DISPLAY_VALUE: "NURSING FACILITY", VALUE: "32" },
        { DISPLAY_VALUE: "CUSTODIAL CARE FACILITY", VALUE: "33" },
        { DISPLAY_VALUE: "HOSPICE", VALUE: "34" },
        { DISPLAY_VALUE: "AMBULANCE - LAND", VALUE: "41" },
        { DISPLAY_VALUE: "AMBULANCE - AIR OR WATER", VALUE: "42" },
        { DISPLAY_VALUE: "PSYCHIATRIC FACILITY INPATIENT", VALUE: "51" },
        { DISPLAY_VALUE: "PSYCHIATRIC FACILITY PARTIAL HOSPITALIZATION", VALUE: "52" },
        { DISPLAY_VALUE: "COMMUNITY MENTAL HEALTH CENTER", VALUE: "53" },
        { DISPLAY_VALUE: "INTERMEDIATE CARE FACILITY/MENTALLY RETARDED", VALUE: "54" },
        { DISPLAY_VALUE: "RESIDENTIAL SUBSTANCE ABUSE TREATEMENT FACILITY", VALUE: "55" },
        { DISPLAY_VALUE: "PSYCHIATRIC FACILITY RESIDENTIAL TREATMENT CENTER", VALUE: "56" },
        { DISPLAY_VALUE: "COMPREHENSIVE INPATIENT REHABILITATION FACILITY", VALUE: "61" },
        { DISPLAY_VALUE: "COMPREHENSIVE OUTPATIENT REHABILITATION FACILITY", VALUE: "62" },
        { DISPLAY_VALUE: "END STAGE RENAL DISEASE TREATMENT FACILITY", VALUE: "65" },
        { DISPLAY_VALUE: "STATE OR LOCAL HEALTH CLINIC", VALUE: "71" },
        { DISPLAY_VALUE: "RURAL HEALTH CLINIC", VALUE: "72" },
        { DISPLAY_VALUE: "INDEPENDENT LABORATORY", VALUE: "81" },
        { DISPLAY_VALUE: "OTHER UNLISTED FACILITY", VALUE: "99" },
    ] }];

   

    const heaader = ["Date of Service","POS","CPT","Diagnosis Pointers","Modifiers","Units Qualifier","Units","Charges"];

    const obj=[];
    const fields_obj = [];
    
    
    //console.log(verify)
    //console.log(data)

for(let i=0;i<1 ; i++)
{
  obj.push(
   
    {
        
          "width":"3",
          "type":"date",
          "name" : data[i].DTP_03_DOS_DATE ? data[i].DTP_03_DOS_DATE : "",
          "color":"",
          "visibility" : "visisble",
          "disabled": true,

      },
      {
        
        "width":"3",
        "type":"dropdown",
        "name" : data[i].SV1_05_POS_CODE ? data[i].SV1_05_POS_CODE : "",
        "color":"",
        "visibility" : "visisble",
        "disabled": false,
        "values":POS

    },
    {
      
      "width":"3",
      "type":"text",
      "name" : data[i].SV1_01_2_CPT ? data[i].SV1_01_2_CPT : "",
      "color":"",
      "visibility" : "visisble",
      "disabled": false,

  },
  {
    
    "width":"3",
    "type":"text",
    "name" : data[i].SV1_01_3_CPT_MOD1 ? data[i].SV1_01_3_CPT_MOD1 : "",
    "color":"",
    "visibility" : "visisble",
    "disabled": false,

},
{
  
  "width":"3",
  "type":"text",
  "name" : data[i].SV1_01_3_CPT_MOD2 ? data[i].SV1_01_3_CPT_MOD2 : "",
  "color":"",
  "visibility" : "visisble",
  "disabled": false,

},
{
  
  "width":"3",
  "type":"text",
  "name" : data[i].SV1_01_3_CPT_MOD3 ? data[i].SV1_01_3_CPT_MOD3 : "",
  "color":"",
  "visibility" : "visisble",
  "disabled": false,

},
{
  
  "width":"3",
  "type":"text",
  "name" : data[i].SV1_01_3_CPT_MOD4 ? data[i].SV1_01_3_CPT_MOD4 : "",
  "color":"",
  "visibility" : "visisble",
  "disabled": false,

},
  )

//   console.log(obj)
}





return obj



}

export default Service_Line_InformationBAL;