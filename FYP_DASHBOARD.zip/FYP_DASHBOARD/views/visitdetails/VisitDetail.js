import React, { useState, useEffect,useMemo } from 'react'
import {
    CButton,
    CCreateElement,
    CCard,
    CCardBody,
    CLabel,
    CCardGroup,
    CCol,
    CContainer,
    CForm,
    CInput,
    CInputGroup,
    CCardHeader,
    CModal,
    CModalHeader,
    CModalTitle,
    CModalBody,
    CModalFooter,
    CInputGroupPrepend,
    CInputGroupText,
    CValidFeedback,
    CInvalidFeedback,
    CRow,
    CTabPane,
    CNavLink,
    CTabs,
    CNav,
    CNavItem,
    CTabContent,
    CSidebarNavDivider,
    CSidebarNavDropdown,
    CSidebarNavItem,
    CSidebarNavTitle
} from '@coreui/react'
import Summary from './Summary';
import { config } from "src/containers/API_Call_Constant";
import API_Fetcher from 'src/containers/API_Fetcher';
import progressbar from '../progressbar/progressbar';
import UserProfile from 'src/containers/UserProfile';
import Payer_Billing_Provider from './Payer_Billing_Provider';
import SummaryBAL from './SummaryBAL';
import Payer_Billing_ProviderBAL from './Payer_Billing_ProviderBAL';
import CIcon from '@coreui/icons-react'
import Subscriber_PatientBAL from './Subscriber_PatientBAL';
import Subscriber_Patient from './Subscriber_Patient';
import Visit from './Visit';
import VisitBAL from './VisitBAL';
import Service_Line from './Service_Line';
import Service_LineBAL from './Service_LineBAL';
import Additional_Provider_FacilityBAL from './Additional_Provider_FacilityBAL';
import Additional_Provider_Facility from './Additional_Provider_Facility';
import Service_Line_InformationBAL from './Service_Line_InformationBAL';
import AttachmentDatatable from '../datatable/AttachmentDatatable';
import FollowupDetail from './FollowupDetail';


const VisitDetail = (props) => {


 

    const [summary, setSummary] = useState([]);
    const [payer, setPayer] = useState([]);
    const [subscriber, setSubscriber] = useState([]);
    const [visit, setVisit] = useState([]);
    const [service, setService] = useState([]);
    const [serviceinfo1, setServiceInfo1] = useState([])
    const [serviceinfo2, setServiceInfo2] = useState([])
    const [additional, setAdditional] = useState([])
    const [Loading, setLoading] = useState(false);
    const [data, setData] = useState();
    const [attachment, setAttachment] = useState([]);
    const [followup, setFollowup] = useState([]);
    const [eligibility, setEligibility] = useState([]);
    const [statusSummary, setStatusSummary] = useState([]);
    const [statusCharges, setStatusCharges] = useState([]);
    const customized_col_names = ["Attachment #", "Document Type", "Transmission Mode", "File Type", "View Attachment"];
    const customized_col_index = [0, 1, 2, 3, 4];

    const cells = ["SeqNum"]


  



     useEffect(() => {


        async function LoadData() {

            const url = config.url.API_URL;
            const GetReportURL = url + "/ediportal/api/v1/RequestHandler";

            const obj = {
                tag_name: 'VisitDetail_request',
                parameters: `${props.claim_no}@splitter@${UserProfile.getSeqnum()}@splitter@LiveDB`
            }

            const param = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(obj)
            }

            try {

                
                let { status, data } = await API_Fetcher(GetReportURL, param)
               



                const summary_result = SummaryBAL(data[0].data[0], data[1].data);
                const payer_result = Payer_Billing_ProviderBAL(data[2].data[0]);
                const subscriber_result = Subscriber_PatientBAL(data[2].data[0]);
                const visit_result = VisitBAL(data[2].data[0]);
                const service_result = Service_LineBAL(data[2].data[0]);
                const additional_result = Additional_Provider_FacilityBAL(data[2].data[0]);

                setSummary(summary_result);
                setPayer(payer_result);
                setSubscriber(subscriber_result);
                setVisit(visit_result);
                setService(service_result);
                setServiceInfo1(data[2].data[0])
                setServiceInfo2(data[3].data)
                setAdditional(additional_result)
                setAttachment(data[4]);
                setFollowup(data[0].data[0]);
                setStatusSummary(data[5]);
                setStatusCharges(data[6]);
                setEligibility(data);
                setLoading(true);


            } catch (error) {
            }
        }
        LoadData();
     }, [])



    function hanldleSubmit() {
        props.onChange(false);

    }

    return (<>

        <CRow>
            <CCol xs="12" sm="12" lg="12">
                <CCard>
                    <CCardHeader className="providerenrollmentheader">
                        <CRow>
                            <CCol className="col-9">
                                <small>
                                    <strong>Visit Detail</strong>
                                </small>
                            </CCol>
                            <CCol className="d-flex justify-content-end col-3">
                                <CButton onClick={() => hanldleSubmit()} type="submit" color="primary" className="custom_button">BACK</CButton>
                            </CCol>
                        </CRow>
                    </CCardHeader>
                    <CCardBody >
                        <CTabs>
                            <CNav >
                                <CNavItem>
                                    <CNavLink >
                                        Summary
                                    </CNavLink>
                                </CNavItem>
                                <CNavItem >
                                    <CNavLink >
                                        Payer/Billing Provider
                                    </CNavLink>
                                </CNavItem>
                                <CNavItem>
                                    <CNavLink>
                                        Subscriber/Patient
                                    </CNavLink>
                                </CNavItem>
                                <CNavItem>
                                    <CNavLink>
                                        Visit
                                    </CNavLink>
                                </CNavItem>
                                <CNavItem>
                                    <CNavLink>
                                        Service Line
                                    </CNavLink>
                                </CNavItem>
                                <CNavItem>
                                    <CNavLink>
                                        Additional Provider/Facility
                                    </CNavLink>
                                </CNavItem>
                                <CNavItem>
                                    <CNavLink>
                                        Attachments
                                    </CNavLink>
                                </CNavItem>
                                <CNavItem>
                                    <CNavLink>
                                        FollowUp
                                    </CNavLink>
                                </CNavItem>
                            </CNav>
                            <CTabContent>
                                <CTabPane>

                                    {Loading ? <Summary result={summary} eligibility={eligibility}/> : <div className="text-center">{progressbar(1)}</div>}

                                </CTabPane>
                                <CTabPane>

                                    {Loading ? <Payer_Billing_Provider result={payer} /> : <div className="text-center"> {progressbar(1)} </div>}

                                </CTabPane>
                                <CTabPane>

                                    {Loading ? <Subscriber_Patient result={subscriber} /> : <div className="text-center"> {progressbar(1)} </div>}
                                </CTabPane>
                                <CTabPane>

                                    {Loading ? <Visit result={visit} /> : <div className="text-center"> {progressbar(1)} </div>}
                                </CTabPane>
                                <CTabPane>

                                    {Loading ? <Service_Line result={service} result1={serviceinfo1} result2={serviceinfo2} /> : <div className="text-center"> {progressbar(1)} </div>}
                                </CTabPane>
                                <CTabPane>

                                    {Loading ? <Additional_Provider_Facility result={additional} /> : <div className="text-center"> {progressbar(1)} </div>}
                                </CTabPane>
                                <CTabPane>

                                    {Loading ? <AttachmentDatatable result={attachment} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : <div className="text-center"> {progressbar(1)} </div>}
                                </CTabPane>
                                <CTabPane>

                                    {Loading ? <FollowupDetail result={followup} summaryresult= {statusSummary}  chargesresult={statusCharges}/> : <div className="text-center"> {progressbar(1)} </div>}
                                </CTabPane>
                            </CTabContent>
                        </CTabs>

                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>









    </>)

    //     const workqueue_nav = [{
    //         _tag: 'CSidebarNavItem',
    //         name: 'X',
    //         to: '/WorkQueue',
    //     }]


    //     const [render, setRender] = useState(true);
    //     const [summary, setSummary] = useState([]);
    //     const [payer, setPayer] = useState([]);
    //     const [subscriber, setSubscriber] = useState([]);
    //     const [visit, setVisit] = useState([]);
    //     const [service, setService] = useState([]);
    //     const [serviceinfo1,setServiceInfo1] = useState([])
    //     const [serviceinfo2,setServiceInfo2] = useState([])
    //     const [additional, setAdditional] = useState([])

    //     const [modal, setModal] = useState(false);
    //     const [data, setData] = useState();
    //     const [statusdata, setStatusData] = useState();
    //     const [Loading, setLoading] = useState(false);


    //     const lorem = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit.'
    //     const query = "SELECT * FROM V_VISIT_SUMMARY WHERE SEQ_NUM = " + UserProfile.getVisitSeqNum();
    //     const payer_billing_provider_query = "SELECT * FROM edi360.V_PORTAL_VISIT  WHERE SEQ_NUM = " + UserProfile.getVisitSeqNum();
    //     const service_line_information_query= "select VISIT_SEQ_NUM,   SEQ_NUM, EPM_CHARGE_SEQ_NUM,  to_char(DTP_03_DOS_DATE,'MM/DD/YYYY') DTP_03_DOS_DATE,   SV1_05_POS_CODE,   SV1_09_EMG_IND,   SV1_01_2_CPT,   SV1_01_3_CPT_MOD1,   SV1_01_4_CPT_MOD2,   SV1_01_5_CPT_MOD3,   SV1_01_6_CPT_MOD4,   SV1_07_1_DIAG_POINTER,   SV1_07_2_DIAG_POINTER,   SV1_07_3_DIAG_POINTER,   SV1_07_4_DIAG_POINTER,   SV1_03_CHARGE_UNIT_QUAL,   SV1_04_CHARGE_UNITS,  trim(TO_CHAR(SV1_02_CHARGE_AMT,'9999999999999999.99')) SV1_02_CHARGE_AMT, SBR_01_PAYER_SEQUENCE from V_PORTAL_VISIT_CHARGES  WHERE VISIT_SEQ_NUM = " + + UserProfile.getVisitSeqNum();


    //     useEffect(() => {

    //         async function LoadData() {

    //             const split = "@Splitter@";
    //             const url = config.url.API_URL;
    //             const GetReportURL = url + "/GenericPageValues";

    //             const input = "?param=" + btoa(query + split + payer_billing_provider_query + split + service_line_information_query);
    //             const param = GetReportURL + input;
    //             try {
    //                 let result = await API_Fetcher(param);

    //                 if (!result[0].data[0].REJECTION_REASON) {

    //                     const status_query = "SELECT DESCRIPTION FROM CLAIM_STATUS_CATEGORY_CODES WHERE CODE = '" + result[0].data[0].ACTUAL_STATUS_CODE.replaceAll('PR', "").replaceAll('AY', "") + "'";

    //                     const status_input = "?param=" + btoa(status_query);
    //                     const status_param = GetReportURL + status_input;
    //                     let status_result = await API_Fetcher(status_param);

    //                     setStatusData(status_result);

    //                 }

    //                 const summary_result = SummaryBAL(result[0].data[0], statusdata);
    //                 const payer_result = Payer_Billing_ProviderBAL(result[1].data[0]);
    //                 const subscriber_result = Subscriber_PatientBAL(result[1].data[0]);
    //                 const visit_result = VisitBAL(result[1].data[0]);
    //                 const service_result = Service_LineBAL(result[1].data[0]);
    //                 const service_info_result = Service_Line_InformationBAL(result[1].data[0],result[2].data)

    //                 const additional_result = Additional_Provider_FacilityBAL(result[1].data[0]);

    //                 setSummary(summary_result);
    //                 setPayer(payer_result);
    //                 setSubscriber(subscriber_result);
    //                 setVisit(visit_result);
    //                 setService(service_result);
    //                 setServiceInfo1(result[1].data[0])
    //                 setServiceInfo2(result[2].data)
    //                 setAdditional(additional_result)

    //                 setLoading(true);
    //                 setModal(true);

    //             } catch (error) {
    //             }
    //         }

    //         LoadData();
    //     }, [props])


    //     function navigation() {
    //         return (
    //             <>
    //     <CCreateElement items={workqueue_nav}

    //     components={{
    //         CSidebarNavDivider,
    //         CSidebarNavDropdown,
    //         CSidebarNavItem,
    //         CSidebarNavTitle
    //     }}
    // />
    //             </>
    //         )
    //     }

    //     return (
    //         <>



    //             <CRow>
    //                 <CCol>
    //                     <CCard>
    //                         <CModal
    //                             show={modal}
    //                             onClose={setModal}
    //                         >
    //                             <CModalHeader >

    //                                 <CModalTitle>Visit Detail</CModalTitle>
    //                                 {navigation()}
    //                             </CModalHeader>
    //                             <CModalBody>
    //                                 <CRow>
    //                                     <CCol xs="12" md="12" className="mb-4">
    //                                         <CCard>
    //                                             <CCardBody>
    //                                                 <CTabs>
    //                                                     <CNav variant="tabs">
    //                                                         <CNavItem>
    //                                                             <CNavLink >
    //                                                                 Summary
    //                                                             </CNavLink>
    //                                                         </CNavItem>
    //                                                         <CNavItem >
    //                                                             <CNavLink >
    //                                                                 Payer/Billing Provider
    //                                                             </CNavLink>
    //                                                         </CNavItem>
    //                                                         <CNavItem>
    //                                                             <CNavLink>
    //                                                                 Subscriber/Patient
    //                                                             </CNavLink>
    //                                                         </CNavItem>
    //                                                         <CNavItem>
    //                                                             <CNavLink>
    //                                                                 Visit
    //                                                             </CNavLink>
    //                                                         </CNavItem>
    //                                                         <CNavItem>
    //                                                             <CNavLink>
    //                                                                 Service Line
    //                                                             </CNavLink>
    //                                                         </CNavItem>
    //                                                         <CNavItem>
    //                                                             <CNavLink>
    //                                                                 Additional Provider/Facility
    //                                                             </CNavLink>
    //                                                         </CNavItem>
    //                                                     </CNav>
    //                                                     <CTabContent>
    //                                                         <CTabPane>

    //                                                             {Loading ? <Summary result={summary} /> : <div className="text-center">{progressbar(1)}</div>}

    //                                                         </CTabPane>
    //                                                         <CTabPane>

    //                                                             {Loading ? <Payer_Billing_Provider result={payer} /> : <div className="text-center"> {progressbar(1)} </div>}

    //                                                         </CTabPane>
    //                                                         <CTabPane>

    //                                                             {Loading ? <Subscriber_Patient result={subscriber} /> : <div className="text-center"> {progressbar(1)} </div>}
    //                                                         </CTabPane>
    //                                                         <CTabPane>

    //                                                             {Loading ? <Visit result={visit} /> : <div className="text-center"> {progressbar(1)} </div>}
    //                                                         </CTabPane>
    //                                                         <CTabPane>

    //                                                             {Loading ? <Service_Line result={service} result1={serviceinfo1} result2={serviceinfo2}/> : <div className="text-center"> {progressbar(1)} </div>}
    //                                                         </CTabPane>
    //                                                         <CTabPane>

    //                                                             {Loading ? <Additional_Provider_Facility result={additional} /> : <div className="text-center"> {progressbar(1)} </div>}
    //                                                         </CTabPane>
    //                                                     </CTabContent>
    //                                                 </CTabs>
    //                                           </CCardBody>
    //                                         </CCard>
    //                                     </CCol>
    //                                 </CRow>

    //                             </CModalBody>

    //                             <CModalFooter>
    //                                 <CButton color="primary">Save</CButton>{' '}
    //                             </CModalFooter>
    //                         </CModal>
    //                     </CCard>
    //                 </CCol>
    //             </CRow>

    //         </>
    //     )
}

export default VisitDetail;