import React, { useState, useEffect } from 'react';
import {
    CBadge,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CRow,
    CCollapse,
    CFormGroup,
    CFade,
    CLabel,
    CSwitch,
    CLink
} from '@coreui/react'
import Payer_Billing_ProviderBAL from './Payer_Billing_ProviderBAL';
import FieldsController from '../validators/FieldsController';
import Label_Field from '../validators/Label_Field';
import CustomDatatable from '../datatable/CustomDatatable';

const Service_Line = (props) => {


    
    const header = ["Date of Service","POS","CPT","Modifiers","Diagnosis Pointers","Units Qualifier","Units","Charges"];
    useEffect(() => {

      // console.log(props)
       

    }, [props])


    return (
        <>
            <CRow>
                <CCol md="12" className="text-right" style={{ color: "#D35E59" }}>
                    <Label_Field name="" visibility="labelbold text-left" />
                </CCol>
                <CCol xs="12" sm="6" md="12">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                                <Label_Field name="Diagnosis Codes" visibility="labelbold text-left" />
                            </CCol>
                            <CCol md="12" className="text-left" style={{ color: "" }}>
                                <Label_Field name="Diagnosis Code Qualifier" visibility="" />
                            </CCol>
                            <CFormGroup row>
                           
                  
                                    {props.result.slice(0, 30).map((e, index) => {


                                        return (

                                        
                                       
                                                    <CCol md={e.width}>
                                           { (index == 12) ? "" : index+1}
                                                        
                                                        <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                                  

                                                    </CCol>
                                       
                                  

                                        );


                                    })}
                                            
                              
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>




            </CRow>
{/* 
<div style={{overflow:"auto"}}>
            <table>
				
				     
                        <tr>
				       {header.map((e)=>{
                           
                           return(
                           <th>{e}</th>
                           )

                       })}
				             <th>Column 1</th>
				            <th>Column 2</th>
				            <th>column 3</th>
				            <th>Column 4</th>
				            <th>Column 5</th>
				            <th>Column 6</th>
				            <th>Column 7</th>
				            <th>Column 8</th>
				            <th>Column 9</th>
				            <th>Column 10</th>
				        </tr>
				    
<tbody>
                   
                        {props.result1}
                        </tbody>
                        <tr>
                        
                           {props.result1.map((e)=>{ 
                                   
                                    <div style={{display:"flex"}}>        
                               return(
                             
                                      <td>
                          
                                     <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                          
                                      </td>
                                     
                               )
                              
                                </div>    
                           })} 
                        
                        </tr>
                  
				</table>
                </div> */}

<CustomDatatable res1 = {props.result1} res2 = {props.result2}/> 

            {/* <CRow>
                <CCol md="12" className="text-right" style={{ color: "#D35E59" }}>
                    <Label_Field name="" visibility="labelbold text-left" />
                </CCol>
                <CCol xs="12" sm="6" md="12">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                                <Label_Field name="Diagnosis Codes" visibility="labelbold text-left" />
                            </CCol>
                            <CCol md="12" className="text-left" style={{ color: "" }}>
                                <Label_Field name="Diagnosis Code Qualifier" visibility="" />
                            </CCol>
                            <CFormGroup row>
                           
                  
                                    {props.result1.splice(0,2).map((e, index) => {


                                        return (

                                        
                                     
                                                    <CCol md={e.width}>
                              <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                                  

                                                    </CCol>
                                     
                                  

                                        );


                                    })}
                                            
                              
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>




            </CRow> */}

        </>
    )
}

export default Service_Line;