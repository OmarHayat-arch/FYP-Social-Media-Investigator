import React from 'react';
import {
    CButton,
    CCard,
    CCardBody,
    CTabPane,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CNavLink,
    CTabContent,
    CNavItem,
    CNav,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CTabs,
    CSwitch
} from '@coreui/react'
import FollowupChargesDatatable from '../datatable/FollowupChargesDatatable';

function Followup(props) {



    const customized_col_names = ["CPT", "Modifiers", "Charge Amount", "Paid Amount", "Units", "Remit Codes", "Claim Status Codes"];
    const customized_col_index = [0, 1, 2, 3, 4, 5, 6];
    const cells = ["CptCode"]

    return (
        <>


            <CRow >
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardBody>
                            <CRow>

                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="select">Reason</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CSelect custom name="select" id="common">
                                                <option value="">SELECT</option>

                                            </CSelect>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="select">Group</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CSelect custom name="select" id="common">
                                                <option value="">SELECT</option>

                                            </CSelect>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>


                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Tickle Date</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput value={"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.TickleDate) ? (props.result.summaryresult.data.TickleDate) : ""} type="date" name="date-input" placeholder="Tickle Date" />
                                            {/* <div class="divider"></div> */}
                                            {/* {ReceivedTo == undefined ?"" : <button onClick={()=> {setReceivedTo(undefined)}} className="custom_clear">X</button> } */}

                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                            </CRow>


                            <CRow>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="select">Additional Info</CLabel>
                                        </CCol>
                                        <CCol xs="9" md="9" className="form">
                                            {/* style={{ marginTop: "0px", marginBottom: "5px", height: "59px" }} */}
                                            <CTextarea 
                                                value={"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.Comments) ? (props.result.summaryresult.data.Comments) : ""}
                                                name="textarea-input"
                                                id="textarea-input"
                                                rows="12"

                                                placeholder="Content..."
                                            />
                                        </CCol>
                                    </CFormGroup>
                                </CCol>


                            </CRow>

                            <CRow>
                                <CCol xs="12" sm="12" lg="12">
                                    <CCard>

                                        <CCardBody >
                                            <CTabs>
                                                <CNav >
                                                    <CNavItem>
                                                        <CNavLink >
                                                            Status Summary
                                                        </CNavLink>
                                                    </CNavItem>
                                                    <CNavItem >
                                                        <CNavLink >
                                                            Charges Status
                                                        </CNavLink>
                                                    </CNavItem>
                                                    <CNavItem>
                                                        <CNavLink>
                                                            Codes Glossary
                                                        </CNavLink>
                                                    </CNavItem>

                                                </CNav>
                                                <CTabContent>
                                                    <CTabPane>

                                                        <CRow>
                                                            <CCol xs="12" sm="6" md="6">
                                                                <CCard style={{ border: "none" }}>
                                                                    <CCardBody>
                                                                        <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                                                            <CLabel className="headerBold">ERA Summary</CLabel>
                                                                        </CCol>
                                                                        <CFormGroup row>

                                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                                <CFormGroup row>
                                                                                    <CCol md="3">
                                                                                        <CLabel className="labelbold" htmlFor="select">ERA Received Date</CLabel>
                                                                                    </CCol>
                                                                                    <CCol xs="12" md="9" className="form">
                                                                                        <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.EraReceivedDate) ? (props.result.summaryresult.data.EraReceivedDate) : ""}</CLabel>
                                                                                    </CCol>
                                                                                </CFormGroup>
                                                                            </CCol>

                                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                                <CFormGroup row>
                                                                                    <CCol md="3">
                                                                                        <CLabel className="labelbold" htmlFor="select">Payer Claim Control #</CLabel>
                                                                                    </CCol>
                                                                                    <CCol xs="12" md="9" className="form">
                                                                                        <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.EraPayerCntrlNum) ? (props.result.summaryresult.data.EraPayerCntrlNum) : ""}</CLabel>

                                                                                    </CCol>
                                                                                </CFormGroup>
                                                                            </CCol>


                                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                                <CFormGroup row>
                                                                                    <CCol md="3">
                                                                                        <CLabel className="labelbold" htmlFor="select">Group Code</CLabel>
                                                                                    </CCol>
                                                                                    <CCol xs="12" md="9" className="form">

                                                                                    </CCol>

                                                                                </CFormGroup>
                                                                            </CCol>


                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonGroup1) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form" >
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonGroup1) ? (props.result.summaryresult.data.AdjReasonGroup1) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}

                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonGroup2) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonGroup2) ? (props.result.summaryresult.data.AdjReasonGroup2) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}
                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonGroup3) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonGroup3) ? (props.result.summaryresult.data.AdjReasonGroup3) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}





                                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                                <CFormGroup row>
                                                                                    <CCol md="3">
                                                                                        <CLabel className="labelbold" htmlFor="select">Reason Code</CLabel>
                                                                                    </CCol>
                                                                                    <CCol xs="12" md="9" className="form">

                                                                                    </CCol>

                                                                                </CFormGroup>
                                                                            </CCol>


                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonCode1) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form" >
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonCode1) ? (props.result.summaryresult.data.AdjReasonCode1) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}

                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonCode2) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonCode2) ? (props.result.summaryresult.data.AdjReasonCode2) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}
                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonCode3) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonCode3) ? (props.result.summaryresult.data.AdjReasonCode3) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}



                                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                                <CFormGroup row>
                                                                                    <CCol md="3">
                                                                                        <CLabel className="labelbold" htmlFor="select">Amount</CLabel>
                                                                                    </CCol>
                                                                                    <CCol xs="12" md="9" className="form">

                                                                                    </CCol>

                                                                                </CFormGroup>
                                                                            </CCol>


                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonAmount1) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form" >
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonAmount1) ? (props.result.summaryresult.data.AdjReasonAmount1) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}

                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonAmount2) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonAmount2) ? (props.result.summaryresult.data.AdjReasonAmount2) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}
                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonAmount3) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.AdjReasonAmount3) ? (props.result.summaryresult.data.AdjReasonAmount3) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}

                                                                        </CFormGroup>
                                                                    </CCardBody>
                                                                </CCard>
                                                            </CCol>


                                                            <CCol xs="12" sm="6" md="6">
                                                                <CCard style={{ border: "none" }}>
                                                                    <CCardBody>
                                                                        <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                                                            <CLabel className="headerBold">Claim Status Summary</CLabel>
                                                                        </CCol>
                                                                        <CFormGroup row>

                                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                                <CFormGroup row>
                                                                                    <CCol md="3">
                                                                                        <CLabel className="labelbold" htmlFor="select">Claim Status Date</CLabel>
                                                                                    </CCol>
                                                                                    <CCol xs="12" md="9" className="form">
                                                                                        <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.ClaimStatusDate) ? (props.result.summaryresult.data.ClaimStatusDate) : ""}</CLabel>
                                                                                    </CCol>
                                                                                </CFormGroup>
                                                                            </CCol>

                                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                                <CFormGroup row>
                                                                                    <CCol md="3">
                                                                                        <CLabel className="labelbold" htmlFor="select">Payer Claim Control #</CLabel>
                                                                                    </CCol>
                                                                                    <CCol xs="12" md="9" className="form">
                                                                                        <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsPayerCntrlNum) ? (props.result.summaryresult.data.CsPayerCntrlNum) : ""}</CLabel>

                                                                                    </CCol>
                                                                                </CFormGroup>
                                                                            </CCol>


                                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                                <CFormGroup row>
                                                                                    <CCol md="3">
                                                                                        <CLabel className="labelbold" htmlFor="select">Category Code</CLabel>
                                                                                    </CCol>
                                                                                    <CCol xs="12" md="9" className="form">

                                                                                    </CCol>

                                                                                </CFormGroup>
                                                                            </CCol>


                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsCategoryCode1) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form" >
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsCategoryCode1) ? (props.result.summaryresult.data.CsCategoryCode1) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}

                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsCategoryCode2) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsCategoryCode2) ? (props.result.summaryresult.data.CsCategoryCode2) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}
                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsCategoryCode3) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsCategoryCode3) ? (props.result.summaryresult.data.CsCategoryCode3) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}





                                                                            <CCol xs="12" sm="12" md="4" lg="12">
                                                                                <CFormGroup row>
                                                                                    <CCol md="3">
                                                                                        <CLabel className="labelbold" htmlFor="select">Status Code</CLabel>
                                                                                    </CCol>
                                                                                    <CCol xs="12" md="9" className="form">

                                                                                    </CCol>

                                                                                </CFormGroup>
                                                                            </CCol>


                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsStatusCode1) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form" >
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsStatusCode1) ? (props.result.summaryresult.data.CsStatusCode1) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}

                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsStatusCode2) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsStatusCode2) ? (props.result.summaryresult.data.CsStatusCode2) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}
                                                                            {"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsStatusCode3) ?
                                                                                <CCol xs="12" sm="12" md="4" lg="12" >
                                                                                    <CFormGroup row>
                                                                                        <CCol md="3">

                                                                                        </CCol>
                                                                                        <CCol xs="12" md="9" className="form">
                                                                                            <CLabel htmlFor="select">{"Empty" in props.result.summaryresult.data ? "" : (props.result.summaryresult.data.CsStatusCode3) ? (props.result.summaryresult.data.CsStatusCode3) : ""}</CLabel>

                                                                                        </CCol>

                                                                                    </CFormGroup>
                                                                                </CCol>
                                                                                : ""}





                                                                        </CFormGroup>
                                                                    </CCardBody>
                                                                </CCard>
                                                            </CCol>

                                                        </CRow>

                                                    </CTabPane>
                                                    <CTabPane>

                                                        {"Empty" in props.result.chargesresult.data ? "" : <FollowupChargesDatatable result={props.result.chargesresult} column_name={customized_col_names} column_index={customized_col_index} cells={cells} />}

                                                    </CTabPane>
                                                    <CTabPane>


                                                    </CTabPane>
                                                    <CTabPane>


                                                    </CTabPane>
                                                    <CTabPane>


                                                    </CTabPane>
                                                    <CTabPane>


                                                    </CTabPane>
                                                    <CTabPane>


                                                    </CTabPane>
                                                    <CTabPane>


                                                    </CTabPane>
                                                </CTabContent>
                                            </CTabs>
                                        </CCardBody>
                                    </CCard>
                                </CCol>
                            </CRow>

                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            {/* <CRow>
                <CCol xs="12" sm="12" lg="12">
                    <CCard>

                        <CCardBody >



                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow> */}

            <CRow >
                <CCol xs="12" sm="12" lg="4">
                    <CCard className="customizeCard">
                        <CCardBody>
                            <CRow>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6" >
                                            <CLabel className="labelbold" htmlFor="select">Claim #</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.ProvClaimNum}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Payer Name</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.PayerName}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Patient</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.Patient}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Policy #</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.InsuredId}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">DOS</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.Dos}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                            </CRow>



                        </CCardBody>
                    </CCard>
                </CCol>



                <CCol xs="12" sm="12" lg="4">
                    <CCard className="customizeCard">
                        <CCardBody>
                            <CRow>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6" >
                                            <CLabel className="labelbold" htmlFor="select">Billing Provider</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.BillingProvName}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">NPI</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.BillingProvNpi}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6" >
                                            <CLabel className="labelbold" htmlFor="select">Rendering Provider</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.RendProvName}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Claim Amount</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.ClaimAmount}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Paid Amount</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.PaidAmount}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                            </CRow>
                        </CCardBody>
                    </CCard>
                </CCol>


                <CCol xs="12" sm="12" lg="4">
                    <CCard className="customizeCard">
                        <CCardBody>
                            <CRow>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Received By PracticeEHR</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.ReceiveDate}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow" >
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Forwarded to Payer</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.ForwardedToPayerDate}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Payer Accepted</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.AcceptedDate}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Payer Rejected</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.RejectedDate}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="12">
                                    <CFormGroup row className="customizeRow">
                                        <CCol md="6">
                                            <CLabel className="labelbold" htmlFor="select">Status</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="6" className="form">
                                            <CLabel htmlFor="select">{props.result.result.Status}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                            </CRow>

                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>


        </>
    )
}


export default Followup;