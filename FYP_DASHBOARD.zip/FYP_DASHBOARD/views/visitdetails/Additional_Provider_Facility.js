import React, { useState, useEffect } from 'react';
import {
    CBadge,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CRow,
    CCollapse,
    CFormGroup,
    CFade,
    CLabel,
    CSwitch,
    CLink
} from '@coreui/react'
import Payer_Billing_ProviderBAL from './Payer_Billing_ProviderBAL';
import FieldsController from '../validators/FieldsController';
import Label_Field from '../validators/Label_Field';

const Additional_Provider_Facility = (props) => {

    //     console.log("billing")
    //    console.log(props)

    // const [obj, setObj] = useState([]);
    // const [isLoading, setLoading] = useState(false);

    useEffect(() => {

        // const result = Payer_Billing_ProviderBAL(props.result[1].data[0]);

        // setObj(result);
        // setLoading(true);

    }, [props])


    return (
        <>
            <CRow>
                <CCol md="12" className="text-right" style={{ color: "#D35E59" }}>
                    <Label_Field name=" * Note: Changes to this section will not reflect in Electronic Practice Management
                                solution." visibility="labelbold text-left" />
                </CCol>
                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                                <Label_Field name="Facility / Location Information" visibility="labelbold text-left" />
                            </CCol>
                            <CFormGroup row>
                                {props.result.slice(0, 4).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                                <Label_Field name="" visibility="labelbold text-left" />
                            </CCol>
                            <CFormGroup row>
                                {props.result.slice(4, 8).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>


                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                                <Label_Field name="" visibility="labelbold text-left" />
                            </CCol>
                            <CFormGroup row>
                                {props.result.slice(8, 12).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

            </CRow>


            <CRow>
        
                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                                <Label_Field name="Rendering Provider" visibility="labelbold text-left" />
                            </CCol>
                            <CFormGroup row>
                                {props.result.slice(12, 18).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

        <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                                <Label_Field name="" visibility="labelbold text-left" />
                            </CCol>
                            <CFormGroup row>
                                {props.result.slice(18, 24).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

      
                <CCol xs="12" sm="6" md="4">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                        <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                                <Label_Field name="" visibility="labelbold text-left" />
                            </CCol>
                            <CFormGroup row>
                                {props.result.slice(24, 26).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "3" : "9"}>
                                            <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                })}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol> 

            </CRow>




            <CRow>
        
        <CCol xs="12" sm="6" md="4">
            <CCard style={{ border: "none" }}>
                <CCardBody>
                    <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                        <Label_Field name="Referring Provider" visibility="labelbold text-left" />
                    </CCol>
                    <CFormGroup row>
                        {props.result.slice(26, 30).map((e, index) => {
                            return (
                                <CCol md={index % 2 == 0 ? "3" : "9"}>
                                    <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                </CCol>
                            );

                        })}
                    </CFormGroup>
                </CCardBody>
            </CCard>
        </CCol>

 <CCol xs="12" sm="6" md="4">
            <CCard style={{ border: "none" }}>
                <CCardBody>
                <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                        <Label_Field name="" visibility="labelbold text-left" />
                    </CCol>
                    <CFormGroup row>
                        {props.result.slice(30, 32).map((e, index) => {
                            return (
                                <CCol md={index % 2 == 0 ? "3" : "9"}>
                                    <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                </CCol>
                            );

                        })}
                    </CFormGroup>
                </CCardBody>
            </CCard>
        </CCol>


        <CCol xs="12" sm="6" md="4">
            <CCard style={{ border: "none" }}>
                <CCardBody>
                <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                        <Label_Field name="" visibility="labelbold text-left" />
                    </CCol>
                    <CFormGroup row>
                        {props.result.slice(32, 34).map((e, index) => {
                            return (
                                <CCol md={index % 2 == 0 ? "3" : "9"}>
                                    <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                </CCol>
                            );

                        })}
                    </CFormGroup>
                </CCardBody>
            </CCard>
        </CCol>  

    </CRow>


    <CRow>
        
        <CCol xs="12" sm="6" md="4">
            <CCard style={{ border: "none" }}>
                <CCardBody>
                    <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                        <Label_Field name=" Supervising Provider" visibility="labelbold text-left" />
                    </CCol>
                    <CFormGroup row>
                        {props.result.slice(34, 38).map((e, index) => {
                            return (
                                <CCol md={index % 2 == 0 ? "3" : "9"}>
                                    <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                </CCol>
                            );

                        })}
                    </CFormGroup>
                </CCardBody>
            </CCard>
        </CCol>

 <CCol xs="12" sm="6" md="4">
            <CCard style={{ border: "none" }}>
                <CCardBody>
                <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                        <Label_Field name="" visibility="labelbold text-left" />
                    </CCol>
                    <CFormGroup row>
                        {props.result.slice(38, 40).map((e, index) => {
                            return (
                                <CCol md={index % 2 == 0 ? "3" : "9"}>
                                    <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                </CCol>
                            );

                        })}
                    </CFormGroup>
                </CCardBody>
            </CCard>
        </CCol>


        <CCol xs="12" sm="6" md="4">
            <CCard style={{ border: "none" }}>
                <CCardBody>
                <CCol md="12" className="text-left" style={{ color: "#066fa1" }}>
                        <Label_Field name="" visibility="labelbold text-left" />
                    </CCol>
                    <CFormGroup row>
                        {props.result.slice(40, 42).map((e, index) => {
                            return (
                                <CCol md={index % 2 == 0 ? "3" : "9"}>
                                    <FieldsController disabled={e.disabled} maxlength={e.maxlength} values={e.values} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                </CCol>
                            );

                        })}
                    </CFormGroup>
                </CCardBody>
            </CCard>
        </CCol>   

    </CRow>

        </>
    )
}

export default Additional_Provider_Facility;