import React, { useEffect, useState } from 'react'
import Label_Field from '../validators/Label_Field';
import {
    CBadge,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CRow,
    CCollapse,
    CFormGroup,
    CFade,
    CLabel,
    CSwitch,
    CNavLink,
    CTabPane,
    CNavItem,
    CTabContent,
    CButton,
    CTabs,
    CNav,
    CLink
} from '@coreui/react'
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';
import SummaryBAL from './SummaryBAL';
import FieldsController from '../validators/FieldsController';
import EligibilityDatatable from '../datatable/EligibilityDatatable';
import ShowPaymentDetail from './ShowPaymentDetail';

const Summary = (propss) => {


    

    const [show, setShow] = useState(false);
    const [paymentshow, setPaymentShow] = useState(false);
    const [props, setProps] = useState()

    const customized_col_names = ["Coverage Level", "Service Type", "Insurance Type", "Time Period", "Amount","Authorization","Network Indicator"];
    const customized_col_index = [0, 1, 2, 3, 4,5,6];

    const customized_col_names_other = ["Benefit", "Coverage Level", "Service Type", "Insurance Type", "Time Period","Amount","Authorization","Network Indicator"];
    const customized_col_index_other = [0, 1, 2, 3, 4,5,6, 7];

    const cells = [""]



    useEffect(() => {

        setProps(propss);

        // document.getElementById("xmlSourceIframeID").src = "https://portal.edisimplified.com/ERA/39083054.xml";

    }, [propss])


    const ActionHanlder = (props) => {
        switch (true) {
            case props == "GetEligibility":

                break;
            case props == "HandleEligibility":
                show == true ? document.getElementById("showeligibility").innerHTML = "Show Eligibility Detail" : document.getElementById("showeligibility").innerHTML = "Hide Eligibility Detail"
                setShow(!show);
                break;

                case props == "HandleShowPayment":
                    alert("adfsd");
                    paymentshow == true ? document.getElementById("showpaymentdetail").innerHTML = "Show Payment Detail" : document.getElementById("showpaymentdetail").innerHTML = "Hide Payment Detail"
                    setPaymentShow(!paymentshow);
                    break;
        }
    }
    return (
        <>

            <CRow>
                <CCol xs="12" sm="6" md="6">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CFormGroup row>

                                {props ? props.result.slice(0, 12).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "4" : "6"}>
                                            <FieldsController id={e.id}  onClick={() => ActionHanlder(e.click)} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                }) : ""}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

                <CCol xs="12" sm="6" md="6">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                <Label_Field name="Claim Processing Status" visibility="headerBold" />
                            </CCol>
                            <CFormGroup row>

                                {props ? props.result.slice(12, 28).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "4" : "6"}>
                                            <FieldsController id={e.id}  onClick={() => ActionHanlder(e.click)} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                }) : ""}

                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>


            <CRow>
                <CCol xs="12" sm="6" md="6">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CFormGroup row>


                                {props ? props.result.slice(28, 41).map((e, index) => {
                                    return (
                                        <CCol md={index % 2 == 0 ? "4" : "6"}>
                                            <FieldsController id={e.id}  onClick={() => ActionHanlder(e.click)} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                }) : ""}
                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

                <CCol xs="12" sm="6" md="6">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                <Label_Field name="Eligibility" visibility="headerBold" />
                            </CCol>
                            <CFormGroup row>

                                {props ? props.result.slice(41, 52).map((e, index) => {

                                    return (
                                        <CCol md={index % 2 == 0 ? "4" : "6"}>
                                            <FieldsController id={e.id}  onClick={() => ActionHanlder(e.click)} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>

                                        </CCol>
                                    );

                                }) : ""}

                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            {/* <div>
                <iframe id="xmlSourceIframeID"/>
            </div> */}

                
             {propss.eligibility.length == 17 ? paymentshow ? <ShowPaymentDetail res = {propss.eligibility[16].data}/> : "" : ""}


           {propss.eligibility.length == 8 ? "" :  show ? <CRow>
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardBody >
                            <CTabs>
                                <CNav >
                                    <CNavItem>
                                        <CNavLink >
                                            Coverage
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem >
                                        <CNavLink >
                                            Co-Insurance
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Co-Payment
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Limitations
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Deductible
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Out of Pocket (Stop Loss)
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Non-Covered
                                        </CNavLink>
                                    </CNavItem>
                                    <CNavItem>
                                        <CNavLink>
                                            Primary Care Provider
                                        </CNavLink>
                                    </CNavItem>

                                    <CNavItem>
                                        <CNavLink>
                                            Others
                                        </CNavLink>
                                    </CNavItem>
                                </CNav>
                                <CTabContent>
                                    <CTabPane>

                                        { <EligibilityDatatable result={propss.eligibility[7]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> }

                                    </CTabPane>
                                    <CTabPane>

                                    { <EligibilityDatatable result={propss.eligibility[8]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> }

                                    </CTabPane>
                                    <CTabPane>

                                    { <EligibilityDatatable result={propss.eligibility[9]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> }
                                    </CTabPane>
                                    <CTabPane>

                                    { <EligibilityDatatable result={propss.eligibility[10]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> }
                                    </CTabPane>
                                    <CTabPane>

                                    { <EligibilityDatatable result={propss.eligibility[11]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> }
                                    </CTabPane>
                                    <CTabPane>

                                    { <EligibilityDatatable result={propss.eligibility[12]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> }
                                    </CTabPane>
                                    <CTabPane>

                                    { <EligibilityDatatable result={propss.eligibility[13]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> }
                                    </CTabPane>
                                    <CTabPane>

                                    { <EligibilityDatatable result={propss.eligibility[14]} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> }
                                    </CTabPane>
                                    <CTabPane>

                                    { <EligibilityDatatable result={propss.eligibility[15]} column_name={customized_col_names_other} column_index={customized_col_index_other} cells={cells} /> }
                                    </CTabPane>
                                </CTabContent>
                            </CTabs>

                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
: ""}





            {/* <div class="table-responsive">
        <table border={0} style={{backgroundColor: '#B7C8E1', font: '"Open Sans",sans-serif', lineHeight: '10px', fontSize: '11px', width: '900px'}}>
          <tbody><tr>
              <td width="75px" style={{borderRight: '1px solid #99A1AA'}}><strong>REND-PROV</strong></td>
              <td width="60px" style={{borderRight: '1px solid #99A1AA'}}><strong>SERV-DATE</strong></td>
              <td width="60px" style={{borderRight: '1px solid #99A1AA'}}><strong>POS</strong></td>
              <td width="88px" style={{borderRight: '1px solid #99A1AA'}}><strong>PD-PROC/MODS</strong></td>
              <td width="47px" style={{borderRight: '1px solid #99A1AA'}}><strong>PD-NOS</strong></td>
              <td width="109px" style={{borderRight: '1px solid #99A1AA'}}><strong>BILLED</strong></td>
              <td width="118px" style={{borderRight: '1px solid #99A1AA'}}><strong>ALLOWED</strong></td>
              <td width="93px" style={{borderRight: '1px solid #99A1AA'}}><strong>DEDUCT</strong></td>
              <td width="85px" style={{borderRight: '1px solid #99A1AA'}}><strong>COINS</strong></td>
              <td width="50px"><strong>PROV-PD</strong></td>
            </tr>
            <tr>
              <td colSpan={4}>RARC</td>
              <td>SUB-NOS</td>
              <td>SUB-PROC</td>
              <td>GRP/CARC</td>
              <td>CARC-AMT</td>
              <td colSpan={2}>ADJ-QTY</td>
            </tr>
          </tbody></table>
        <table border={0} style={{font: '"Open Sans",sans-serif', fontSize: '11px', lineHeight: '10px', width: '900px'}}>
          <tbody><tr style={{backgroundColor: '#ffffff', color: '#000000'}}><td colSpan={10}><hr /></td></tr>
            <tr style={{backgroundColor: '#e4e8f3', color: '#000000'}}>
              <td colSpan={3}>
                <strong>NAME</strong>:&nbsp;GOTTSCHALK-SHANNON,R</td>
              <td>
                <strong>HIC</strong>:&nbsp;</td>
              <td colSpan={2}>
                <strong>ACNT</strong>:&nbsp;338973V841873</td>
              <td>
                <strong>ICN</strong>:&nbsp;EHY1TG9930000</td>
              <td colSpan={3}>
                <strong>ASG</strong>:&nbsp;Y&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>MOA</strong>:&nbsp;</td>
            </tr>
            <tr style={{backgroundColor: '#ffffff', color: '#000000', border: '!important'}}>
              <td width="83px" />
              <td width="60px">0803&nbsp;&nbsp;&nbsp;080321</td>
              <td width="60px" />
              <td width="88px">992135725</td>
              <td width="89px" />
              <td width="109px">176</td>
              <td width="118px">158.40</td>
              <td width="93px">0</td>
              <td width="85px">0</td>
              <td width="50px">158.40</td>
            </tr>
            <tr>
              <td width="83px" />
              <td>         <div style={{verticalAlign: 'text-bottom'}}>
                  <strong>CNTL</strong>:&nbsp;#:&nbsp;:<strong>00000000001</strong>
                </div>
              </td>
              <td />
              <td />
              <td />
              <td />
              <td style={{backgroundColor: '#c0c0c0'}}>CO-45&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;17.60<br />
              </td>
              <td />
              <td />
              <td />
            </tr>
            <tr style={{backgroundColor: '#ffffff', color: '#000000', border: '!important'}}>
              <td width="83px" />
              <td width="60px">0803&nbsp;&nbsp;&nbsp;080321</td>
              <td width="60px" />
              <td width="88px">26055F7</td>
              <td width="89px" />
              <td width="109px">2503</td>
              <td width="118px">2252.70</td>
              <td width="93px">0</td>
              <td width="85px">0</td>
              <td width="50px">2252.70</td>
            </tr>
            <tr>
              <td width="83px" />
              <td>         <div style={{verticalAlign: 'text-bottom'}}>
                  <strong>CNTL</strong>:&nbsp;#:&nbsp;:<strong>00000000004</strong>
                </div>
              </td>
              <td />
              <td />
              <td />
              <td />
              <td style={{backgroundColor: '#c0c0c0'}}>CO-45&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;250.30<br />
              </td>
              <td />
              <td />
              <td />
            </tr>
            <tr style={{backgroundColor: '#ffffff', color: '#000000', border: '!important'}}>
              <td width="83px" />
              <td width="60px">0803&nbsp;&nbsp;&nbsp;080321</td>
              <td width="60px" />
              <td width="88px">J3490</td>
              <td width="89px" />
              <td width="109px">32</td>
              <td width="118px">28.80</td>
              <td width="93px">0</td>
              <td width="85px">0</td>
              <td width="50px">28.80</td>
            </tr>
            <tr>
              <td width="83px" />
              <td>         <div style={{verticalAlign: 'text-bottom'}}>
                  <strong>CNTL</strong>:&nbsp;#:&nbsp;:<strong>00000000002</strong>
                </div>
              </td>
              <td />
              <td />
              <td />
              <td />
              <td style={{backgroundColor: '#c0c0c0'}}>CO-45&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.20<br />
              </td>
              <td />
              <td />
              <td />
            </tr>
            <tr style={{backgroundColor: '#ffffff', color: '#000000', border: '!important'}}>
              <td width="83px" />
              <td width="60px">0803&nbsp;&nbsp;&nbsp;080321</td>
              <td width="60px" />
              <td width="88px">J2400</td>
              <td width="89px" />
              <td width="109px">132</td>
              <td width="118px">118.80</td>
              <td width="93px">0</td>
              <td width="85px">0</td>
              <td width="50px">118.80</td>
            </tr>
            <tr>
              <td width="83px" />
              <td>         <div style={{verticalAlign: 'text-bottom'}}>
                  <strong>CNTL</strong>:&nbsp;#:&nbsp;:<strong>00000000003</strong>
                </div>
              </td>
              <td />
              <td />
              <td />
              <td />
              <td style={{backgroundColor: '#c0c0c0'}}>CO-45&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13.20<br />
              </td>
              <td />
              <td />
              <td />
            </tr>
            <tr style={{backgroundColor: '#ffffff', color: '#000000', border: '!important'}}>
              <td />
              <td colSpan={2}>
                <strong>PT RESP</strong>&nbsp;&nbsp;&nbsp;</td>
              <td>
                CARC&nbsp;&nbsp;284.30</td>
              <td colSpan={2}>
                <strong>CLAIM TOTALS</strong>&nbsp;&nbsp;
                2843</td>
              <td>2558.70</td>
              <td>0</td>
              <td>0</td>
              <td>2558.70</td>
            </tr>
            <tr style={{backgroundColor: '#ffffff', color: '#000000', border: '!important'}}>
              <td>ADJ TO TOTALS:</td>
              <td>
                PREV PD&nbsp;&nbsp;</td>
              <td>
                INTEREST&nbsp;</td>
              <td />
              <td />
              <td />
              <td colSpan={2}>
                LATE FILING CHARGE&nbsp;</td>
              <td />
              <td><div style={{marginLeft: '9px'}}>
                  <strong>NET</strong>&nbsp;2558.70</div></td>
            </tr>
            <tr style={{backgroundColor: '#B7C8E1', color: '#000000'}}>
              <td colSpan={3} valign="top"><strong>OTHER CLAIM REL IDENTIFICATION:</strong></td>
              <td colSpan={7}>1L&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                0820409-033-00001-IA<br />CE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                AETNA HEALTHFUND  AETNA CHOICE  POS II NET 07895<br />
              </td>
            </tr>
            <tr style={{backgroundColor: '#B7C8E1', color: '#000000'}}>
              <td colSpan={3} valign="top"><strong>CLAIM LEVEL ADJUSTMENT CODES:</strong></td>
              <td colSpan={7} />
            </tr>
          </tbody></table>
        <table style={{marginLeft: '-1px'}}><tbody><tr><td><strong><br />GLOSSARY:
                </strong></td></tr></tbody></table>
        <br /><table>
          <tbody><tr>
              <td width="100px">45</td>
              <td width="2000px">Charge exceeds fee schedule/maximum allowable or contracted/legislated fee arrangement. (Use only with Group Codes PR or CO depending upon liability)</td>
            </tr>
            <tr>
              <td width="100px">CO</td>
              <td width="2000px">Contractual Obligations.</td>
            </tr>
          </tbody></table>
    </div> */}

        </>
    )
}

export default Summary;