import React, { useEffect, useState } from 'react'
import Label_Field from '../validators/Label_Field';
import {
    CBadge,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CRow,
    CCollapse,
    CFormGroup,
    CFade,
    CLabel,
    CSwitch,
    CLink
} from '@coreui/react'
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';
import SummaryBAL from './SummaryBAL';
import FieldsController from '../validators/FieldsController';




// function abc(a,props,check){

//     return(a == 1 ?  <Label_Field data={props} check={check} /> : "")
// }

const Summary = (props) => {

    console.log("summary")
    const [obj, setObj] = useState([]);
    const [isLoading, setLoading] = useState(false);


    useEffect(() => {

        const result = SummaryBAL(props.result[0].data[0], props);

        setObj(result);
        setLoading(true);

        //setObj(result);
    }, [props])

    // console.log(props.result[0].data[0]);

    // const [statusdescription, setStatusDescription] = useState();

    // const global_settings = [{
    //     name:"a",
    //     type: "label",
    //     flag: "true",
    //     color: "red",
    // },
    // {
    //     name:"b",
    //     type: "button",
    //     flag: "true",
    //     color: "yellow",
    // },
    // {
    //     name:"c",
    //     type: "textfield",
    //     flag: "false",
    //     color: "pink",
    // },
    // {
    //     name:"d",
    //     type: "textfield",
    //     flag: "false",
    //     color: "pink",
    // }, {
    //     name:"e",
    //     type: "textfield",
    //     flag: "false",
    //     color: "pink",
    // }, {
    //     name:"f",
    //     type: "textfield",
    //     flag: "false",
    //     color: "pink",
    // }, {
    //     name:"g",
    //     type: "textfield",
    //     flag: "false",
    //     color: "pink",
    // },
    // ]

    // const label_visibility_flag = [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,,1,1,1,1,1,1,1,1];

    // useEffect(() => {
    //     async function LoadData() {
    //         const query = "SELECT DESCRIPTION FROM CLAIM_STATUS_CATEGORY_CODES WHERE CODE = '" + props.result[0].data[0].ACTUAL_STATUS_CODE.replaceAll('PR', "").replaceAll('AY', "") + "'";
    //         const split = "@Splitter@";
    //         const url = config.url.API_URL;
    //         const GetReportURL = url + "/GenericPageValues";
    //         const input = "?param=" + btoa(query);
    //         const param = GetReportURL + input;
    //         try {
    //             let result = await API_Fetcher(param);
    //             setStatusDescription(result);
    //         } catch (error) {
    //         }
    //     }
    //     if (props.result[0].data[0].REJECTION_REASON == null || props.result[0].data[0].REJECTION_REASON == "" ||
    //         props.result[0].data[0].REJECTION_REASON == undefined) {
    //         LoadData();
    //     } else { }
    // }, [])

    const ActionHanlder = (props) => {
        switch (true) {
        case props == "GetEligibility":
    
        break;
case props == "HandleEligibility":
    
        break;
    }
}
return (
    <>
        <CRow>
            <CCol xs="12" sm="6" md="6">
                <CCard style={{ border: "none" }}>
                    <CCardBody>
                        <CFormGroup row>

                            {isLoading ? obj.slice(0, 12).map((e, index) => {
                                return (
                                    <CCol md={index % 2 == 0 ? "4" : "6"}>
                                        <FieldsController type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                        {/* <Label_Field color={e.color} name={e.name} visibility={e.visibility} ></Label_Field> */}
                                    </CCol>
                                );

                            }) : ""}
                        </CFormGroup>
                    </CCardBody>
                </CCard>
            </CCol>

            <CCol xs="12" sm="6" md="6">
                <CCard style={{ border: "none" }}>
                    <CCardBody>
                        <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                            <Label_Field name="Claim Processing Status" visibility="labelbold" />
                        </CCol>
                        <CFormGroup row>
                            {isLoading ? obj.slice(12, 28).map((e, index) => {
                                return (
                                    <CCol md={index % 2 == 0 ? "6" : "6"}>
                                        <FieldsController type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                        {/* <Label_Field color={e.color} name={e.name} visibility={e.visibility} ></Label_Field> */}
                                    </CCol>
                                );

                            }) : ""}

                        </CFormGroup>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>


        <CRow>
            <CCol xs="12" sm="6" md="6">
                <CCard style={{ border: "none" }}>
                    <CCardBody>
                        <CFormGroup row>

                            {isLoading ? obj.slice(28, 40).map((e, index) => {
                                return (
                                    <CCol md={index % 2 == 0 ? "6" : "6"}>
                                        <FieldsController type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                        {/* <Label_Field color={e.color} name={e.name} visibility={e.visibility} ></Label_Field> */}
                                    </CCol>
                                );

                            }) : ""}
                        </CFormGroup>
                    </CCardBody>
                </CCard>
            </CCol>

            <CCol xs="12" sm="6" md="6">
                <CCard style={{ border: "none" }}>
                    <CCardBody>
                        <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                            <Label_Field name="Eligibility" visibility="labelbold" />
                        </CCol>
                        <CFormGroup row>
                            {isLoading ? obj.slice(40, 51).map((e, index) => {
                                console.log(e.click)
                                return (
                                    <CCol md={index % 2 == 0 ? "6" : "6"}>
                                        <FieldsController onClick={() => ActionHanlder(e.click)} type={e.type} color={e.color} name={e.name} visibility={e.visibility} ></FieldsController>
                                        {/* <Label_Field color={e.color} name={e.name} visibility={e.visibility} ></Label_Field> */}
                                    </CCol>
                                );

                            }) : ""}

                        </CFormGroup>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>




        {/* <CRow>
                <CCol xs="12" sm="6" md="6">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CFormGroup row>
                                <CCol md="4">
                                    <Label_Field name="Claim #" bold="labelbold" check={1} data={props.result[0].data[0]} />
                                </CCol>
                                <CCol md="6">
                                    
                                    <Label_Field data={props.result[0].data[0]} check={1} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field name="Payer Name" bold="labelbold" data={props.result[0].data[0]} check={2} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={2} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field name="Payer ID" bold="labelbold" data={props.result[0].data[0]} check={3} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={3} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field name="Patient" bold="labelbold" data={props.result[0].data[0]} check={4} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={4} />
                                </CCol>

                                <CCol md="4">
                                    <Label_Field name="Policy#" bold="labelbold" data={props.result[0].data[0]} check={5} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={5} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field name="DOS" bold="labelbold" data={props.result[0].data[0]} check={6} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={6} />
                                </CCol>
                            </CFormGroup>

                        </CCardBody>
                    </CCard>
                </CCol>


                <CCol xs="12" sm="6" md="6">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>
                            <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                <Label_Field name="Claim Processing Status" bold="labelbold" />
                            </CCol>
                            <CFormGroup row>

                                <CCol md="4">
                                    <Label_Field name="Received By PracticeEHR" bold="labelbold" data={props.result[0].data[0]} check={7} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={7} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field name="Forwarded to Payer" bold="labelbold" data={props.result[0].data[0]} check={8} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={8} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field name="Status Date" bold="labelbold" data={props.result[0].data[0]} check={9} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={9} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field name="Payer Rejected" bold="labelbold" data={props.result[0].data[0]} check={10} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={10} />
                                </CCol>

                                <CCol md="4">
                                    <Label_Field name="Status" bold="labelbold" data={props.result[0].data[0]} check={11} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={11} />
                                    <Label_Field data={props.result[0].data[0]} check={12} status_description={statusdescription} />
                                </CCol>

                                <CCol md="4">
                                    <Label_Field name="IHCFA Tracking #" bold="labelbold" data={props.result[0].data[0]} check={23} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={23} />
                                </CCol>

                                <CCol md="4">
                                    <Label_Field name="IHCFA Comments" bold="labelbold" data={props.result[0].data[0]} check={24} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field data={props.result[0].data[0]} check={24} />
                                </CCol>

                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>



            </CRow>

            <CRow>
                <CCol xs="12" sm="6" md="6">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>

                            <CFormGroup row>
                                <CCol md="4">
                                    <Label_Field id="22" name="Case Type" bold="labelbold" data={props.result[0].data[0]} check={22} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="22" data={props.result[0].data[0]} check={22} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field id="13" name="Billing Provider" bold="labelbold" data={props.result[0].data[0]} check={13} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="13" data={props.result[0].data[0]} check={13} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field id="14" name="NPI" bold="labelbold" data={props.result[0].data[0]} check={14} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="14" data={props.result[0].data[0]} check={14} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field id="15" name="Rendering Provider" bold="labelbold" data={props.result[0].data[0]} check={15} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="15" data={props.result[0].data[0]} check={15} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field id="16" name="Claim Amount" bold="labelbold" data={props.result[0].data[0]} check={16} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="16" data={props.result[0].data[0]} check={16} />
                                </CCol>

                                <CCol md="4">
                                    <Label_Field id="17" name="Paid Amount" bold="labelbold" data={props.result[0].data[0]} check={17} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="17" data={props.result[0].data[0]} check={17} />
                                </CCol>

                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>


                <CCol xs="12" sm="6" md="6">
                    <CCard style={{ border: "none" }}>
                        <CCardBody>

                            <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                <Label_Field name="Eligibility" bold="labelbold" />
                            </CCol>
                            <CFormGroup row>

                                <CCol md="4">
                                    <Label_Field id="18" name="Eligibility" bold="labelbold" data={props.result[0].data[0]} check={18} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="18" data={props.result[0].data[0]} check={18} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field id="19" name="Plan Begin Date" bold="labelbold" data={props.result[0].data[0]} check={19} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="19" data={props.result[0].data[0]} check={19} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field id="20" name="Plan End Date" bold="labelbold" data={props.result[0].data[0]} check={20} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="20" data={props.result[0].data[0]} check={20} />
                                </CCol>
                                <CCol md="4">
                                    <Label_Field id="21" name="Copay" bold="labelbold" data={props.result[0].data[0]} check={21} />
                                </CCol>
                                <CCol md="6">
                                    <Label_Field id="21" data={props.result[0].data[0]} check={21} />
                                </CCol>

                            </CFormGroup>
                        </CCardBody>
                    </CCard>
                </CCol>

            </CRow> */}

    </>
)
}

export default Summary;