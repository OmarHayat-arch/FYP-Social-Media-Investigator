import React,{useState,useEffect} from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CSwitch
} from '@coreui/react'
import Dynamicdatatable from 'src/views/datatable/Dynamicdatatable'
import {config} from 'src/containers/API_Call_Constant'
import API_Fetcher from 'src/containers/API_Fetcher'
import progressbar from 'src/views/progressbar/progressbar'
import UserProfile from 'src/containers/UserProfile';
import ERADatatable from '../datatable/ERADatatable'
import moment from 'moment';
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';

//const era_query = "SELECT RECEIVED_DATE, CHECK_DATE, CHECK_NUM,TO_CHAR(CHECK_AMT, '$99,999,999,999,999,999.99') CHECK_AMT, initcap(PAYER) PAYER, initcap(PAYEE) PAYEE, PAYEE_ID, FILE_STATUS, VEN_835_FILE_SEQ_NUM as SEQ_NUM, CLIENT_SEQ_NUM, STATUS, SHARED_PATH as FILE_PATH, FILE_FLAG,  SEQ_NUM as ERA_SEQ_NUM, PAYMENT_METHOD, PAYMENT_METHOD_DESC, IS_PLB_AVAILABLE, DOWNLOAD_DATE FROM VP_ERA_CHECKS  WHERE CLIENT_SEQ_NUM = " + UserProfile.getSeqnum() + " and rownum < 50";
const customized_col_names=["Received Date","Check Date","Check #","Amount","Payment Method","Payer","Payee","Payee ID","Status","Download Date"];
const customized_col_index=[0,1,2,3,4,5,6,7,8,9];
const cells = ["CheckAmt"]

function ERA() {
    const [data,setData]=useState([]);
    const [isLoading,setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    
    const [FromDate, setFromDate] = useState();
    const [ToDate, setToDate] = useState();
    const [Status, setStatus] = useState("NEW");
    const [Check, setCheck] = useState();
    const [Payer, setPayer] = useState();
    const [Payee, setPayee] = useState();
    
    
    
    
    const handleClose = () => {
        setOpen(false);
      };
      const handleToggle = () => {
        setOpen(!open);
      };
    
      const useStyles = makeStyles((theme) => ({
        backdrop: {
          zIndex: theme.zIndex.drawer + 1,
          color: '#fff',
        },
      }));
    
      const classes = useStyles();
    
    async function hanldleSubmit(){
        handleToggle();
    const url = config.url.API_URL;
    const GetReportURL = url +"/ediportal/api/v1/RequestHandler";
    
    const obj = {
      tag_name: 'ERA_condition_request',
      parameters: `${FromDate}@splitter@${ToDate}@splitter@${Status}@splitter@${Check}@splitter@${Payer}@splitter@${Payee}@splitter@${UserProfile.getSeqnum()}@splitter@LiveDB`
    }
    
    const param = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(obj)
    }
    
    try {
    let { status, data } = await API_Fetcher(GetReportURL, param)
    
    
    setData(data[0]);
    setLoading(true);
    setOpen(false);
    
    } catch (error) {
    }
    
    }
    
        useEffect(() => {
        
            async function LoadData() {
    
    
                const url = config.url.API_URL;
                const GetReportURL = url +"/ediportal/api/v1/RequestHandler";
          
                const obj = {
                  tag_name: 'ERA_request',
                  parameters: `${Status}@splitter@${UserProfile.getSeqnum()}@splitter@LiveDB`
                }
          
                const param = {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(obj)
                }
    
              try {
                let { status, data } = await API_Fetcher(GetReportURL, param)
                
                
    
                setData(data[0]);
                setLoading(true);
    
                
              } catch (error) {
              }
            }
            LoadData();
          }, [])


    return (
        <div>
            <CRow>
            <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardBody>
                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>

                                    <CCol md="3">
                                            <label className="custom_label" htmlFor="date-input">Check Date From</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()}  value={FromDate==undefined? "": moment(FromDate).format('YYYY-MM-DD')}  onChange={(e)=>setFromDate(moment(e.target.value).format('MM-DD-YYYY'))} type="date"   name="date-input" placeholder="Check Date From" />
                                            <div class="divider"></div>
                                            {FromDate == undefined ?"" : <button onClick={()=> {setFromDate(undefined)}} className="custom_clear">X</button> }
                                        </CCol>

                                       
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>



                                    <CCol md="3">
                                            <label className="custom_label" htmlFor="date-input">Check Date To</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()}  value={ToDate==undefined? "": moment(ToDate).format('YYYY-MM-DD')}  onChange={(e)=>setToDate(moment(e.target.value).format('MM-DD-YYYY'))} type="date"   name="date-input" placeholder="Check Date To" />
                                            <div class="divider"></div>
                                            {ToDate == undefined ?"" : <button onClick={()=> {setToDate(undefined)}} className="custom_clear">X</button> }
                                        </CCol>

                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="select">Status</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CSelect onChange={(e)=>setStatus(e.target.value)} custom name="select" id="select">
                                                <option value="NEW">NEW</option>
                                                <option value="DOWNLOADED">DOWNLOADED</option>
                                                <option value="ALL">ALL</option>
                                            </CSelect>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                            </CRow>

                            <CRow>
                            <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Check#</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CInput onChange={(e)=>setCheck(e.target.value)} id="name" placeholder="Check #" required />
                                        </CCol>
                                    </CFormGroup>
                                    </CCol>
                                    <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Payer</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CInput onChange={(e)=>setPayer(e.target.value)} id="name" placeholder="Payer" required />
                                        </CCol>
                                    </CFormGroup>
                                    </CCol>
                                    <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Payee</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CInput onChange={(e)=>setPayee(e.target.value)} id="name" placeholder="Payee" required />
                                        </CCol>
                                    </CFormGroup>
                                
                                </CCol>

                            </CRow>
                            <CRow>

                            <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                       
                                        </CCol>
                                        <CCol xs="12" md="9">
                                       
                                        </CCol>
                                    </CFormGroup>
                                
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                       
                                        </CCol>
                                        <CCol xs="12" md="9">
                                       
                                        </CCol>
                                    </CFormGroup>
                                
                                </CCol>


                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                       
                                        </CCol>
                                        <CCol xs="12" md="9">
                                        <CButton onClick={()=>hanldleSubmit()}  type="submit" color="primary" className="custom_button col-md-12">Search</CButton>
                                    {isLoading && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>}
                                        </CCol>
                                    </CFormGroup>
                                
                                </CCol>
{/* 
                                <CCol xs="12" className="text-center">
                                    <CButton onClick={()=>hanldleSubmit()}  type="submit" color="primary" className="custom_button">Search</CButton>
                                    {isLoading && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>}
                                </CCol> */}
                            </CRow>
                            <CRow>
                            </CRow>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
 
{isLoading  ? <ERADatatable result = {data}   column_name = {customized_col_names} column_index = {customized_col_index} cells={cells}   /> :progressbar(2) } 

        </div>
    )
}

export default ERA
