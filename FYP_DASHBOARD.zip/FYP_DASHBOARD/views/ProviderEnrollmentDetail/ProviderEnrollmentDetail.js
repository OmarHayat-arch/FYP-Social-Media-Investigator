import react, { useEffect, useState } from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CTabPane,
    CNavLink,
    CTabs,
    CNav,
    CNavItem,
    CTabContent,
    CLabel,
    CSelect,
    CRow,
    CSwitch
} from '@coreui/react'
import UserProfile from 'src/containers/UserProfile';
import progressbar from '../progressbar/progressbar';
import ProviderEnrollmentDetailDatatable from '../datatable/ProviderEnrollmentDetailDatatable';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';

const ProviderEnrollmentDetail = (props) => {

const [data,setData] = useState();
const [isLoading, setisLoading] = useState();

        
    const headers = [
        { name: "Payer Name", field: "payername", sortable: false },
        { name: "Payer ID", field: "payerid", sortable: true },
        { name: "Claims", field: "claim", sortable: true },
        { name: "Claim Status", field: "claimstatus", sortable: false },
        { name: "ERA", field: "era", sortable: false },
        { name: "Eligibility", field: "eligibility", sortable: false },
        { name: "Claims", field: "claim1", sortable: true },
        { name: "Claim Status", field: "claimstatus1", sortable: false },
        { name: "ERA", field: "era1", sortable: false },
        { name: "Eligibility", field: "eligibility1", sortable: false }
    ];


    useEffect(() => {
        

        async function LoadData() {

            if (UserProfile.getStart() === null && UserProfile.getEnd() === null) {
                
                UserProfile.setStart(0)
                UserProfile.setEnd(100)

            }
            else {

        

            }

            if (UserProfile.getProviderEnrollmentTab() === null) {
                UserProfile.setProviderEnrollmentTab(1)
            }

            TabData(UserProfile.getProviderEnrollmentTab())

        }

        LoadData();
    }, [])

    async function TabData(tab) {

        if (tab == 1) {
            UserProfile.setProviderEnrollmentTab(1)
            setisLoading(false);
            


        }

        else if (tab == 2) {
            UserProfile.setProviderEnrollmentTab(2)
            setisLoading(false);
            
        }
        else if (tab == 3) {
            UserProfile.setProviderEnrollmentTab(3)
            setisLoading(false);
            
        }



        const url = config.url.API_URL;
        const GetReportURL = url +"/ediportal/api/v1/RequestHandler";
  
        const obj = {
          tag_name: 'ProviderEnrollmentDetail_request',
          parameters: `${UserProfile.getProviderEnrollmentTab() == 1 ? "ALL" : UserProfile.getProviderEnrollmentTab() == 2 ? "INUSE" : UserProfile.getProviderEnrollmentTab() == 3 ? "NOTINUSE" : "undefined" }@splitter@${props.data[3] == "" ? "undefined" : props.data[3]}@splitter@${UserProfile.getSeqnum()}@splitter@LiveDB`
        }
  
        const param = {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(obj)
        }



        try {

        
            let result = await API_Fetcher(GetReportURL, param);

            console.log(data);
            
            // UserProfile.setTotal(result.data[0].data.Total)

            setData(data);
            setisLoading(true);
        } catch (error) {

        }

    }

    // const handlePagination = useMemo(() => {

    //     if (UserProfile.getPayerListType() == "P") {
    //         if (Number(UserProfile.getStart()) == 0) {

    //         }
    //         else {
                
                
    //             UserProfile.setStart(Number(UserProfile.getStart()) < 100 ? Number(0) : Number(UserProfile.getStart()) - 100);
                
    //             UserProfile.setEnd(Number(UserProfile.getEnd()));
    //         }

    //     }
    //     else if (UserProfile.getPayerListType() == "N") {
    //         if (Number(UserProfile.getEnd()) >= Number(UserProfile.getTotal())) {

    //         }
    //         else {
    //             UserProfile.setStart(Number(UserProfile.getStart()) + 100);
    //             UserProfile.setEnd(Number(UserProfile.getEnd()));
    //         }
    //     }
    //     else if (UserProfile.getPayerListType() == "F") {
    //         UserProfile.setStart(0)
    //         UserProfile.setEnd(100)
    //     }
    //     else if (UserProfile.getProviderEnrollmentTab() == "L") {
    //         UserProfile.setStart(UserProfile.getTotal()-100)
    //         UserProfile.setEnd(UserProfile.getTotal())
    //     }
        
    //     TabData(UserProfile.getProviderEnrollmentTab());
    //     return "";
    // }, [count])

    function hanldleSubmit() {
        props.onChange(false);

    }
    return (
        <>
  


            <CRow>
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardHeader className="providerenrollmentheader">
                            <CRow>
                        <CCol className="col-9">
                            <small>
                                <strong>{props.data[0].props.children}</strong>
                            </small>
                           </CCol>
                           <CCol className="d-flex justify-content-end col-3">
                            <CButton onClick={() => hanldleSubmit()} type="submit" color="primary" className="custom_button">X</CButton>
                            </CCol>
                            </CRow>
                        </CCardHeader>
                        <CCardBody >
                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="3">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="labelbold" htmlFor="date-input">NPI</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CLabel className="" htmlFor="date-input">{props.data[2]}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="3">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="labelbold" htmlFor="date-input">Tax ID</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CLabel className="" htmlFor="date-input">{props.data[3]}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="3">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="labelbold" htmlFor="select">Address</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CLabel className="" htmlFor="select">{props.data[4]}</CLabel>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>



                            </CRow>


                            <CRow>

                                <CCol xs="12" sm="12" md="4" lg="3">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="labelbold" htmlFor="date-input">City</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CLabel className="" htmlFor="date-input">{props.data[5]}</CLabel>
                                        </CCol>


                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="3">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="labelbold" htmlFor="date-input">State</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CLabel className="" htmlFor="date-input">{props.data[6]}</CLabel>
                                        </CCol>


                                    </CFormGroup>
                                </CCol>

                                <CCol xs="12" sm="12" md="4" lg="3">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="labelbold" htmlFor="date-input">Zip</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CLabel className="" htmlFor="date-input">{props.data[7]}</CLabel>
                                        </CCol>


                                    </CFormGroup>
                                </CCol>



                                <CCol xs="12" sm="12" md="4" lg="3">
                                    <div class="table-responsive customize_table">
                                        <table class="table providerenrollmenttable">
                                            <tr><th>Enrollmemnt Indicator</th></tr>
                                            <tbody>
                                                <tr>

                                                    <td style={{background:"#A9D08E"}}>
                                                        Not Required
                                                    </td>

                                                    {/* <td style={{background: "#A9D08E"}}>
                                                        
                                                    </td> */}
                                                </tr>
                                                <tr>
                                                <td style={{background:"#FCE4D6"}}>
                                                        Required
                                                    </td>

                                                    {/* <td style={{background:'#FCE4D6'}}>
                                                        
                                                    </td> */}
                                                </tr>
                                                <tr>
                                                <td style={{background:"#C3C3C3"}}>
                                                        Not Supported
                                                    </td>
{/* style={{background:"#C3C3C3"}} */}
                                                    {/* <td>
                                                        
                                                    </td> */}
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                </CCol>




                            </CRow>


                        </CCardBody>
                    </CCard>
                </CCol>

            </CRow>







            <CTabs>
                <CNav >
                    <CNavItem>
                        <CNavLink className={UserProfile.getProviderEnrollmentTab() == 1 ? "custom_tab" : ""} onClick={() => UserProfile.setStart(0) || UserProfile.setEnd(100)  || TabData(1)}>
                            Show ALL
                        </CNavLink>

                    </CNavItem>
                    <CNavItem >
                        <CNavLink className={UserProfile.getProviderEnrollmentTab() == 2 ? "custom_tab" : ""} onClick={() => UserProfile.setStart(0) || UserProfile.setEnd(100)  || TabData(2)}>
                            Payer In Use
                        </CNavLink>
                    </CNavItem>
                    <CNavItem>
                        <CNavLink className={UserProfile.getProviderEnrollmentTab() == 3 ? "custom_tab" : ""} onClick={() => UserProfile.setStart(0) || UserProfile.setEnd(100)  || TabData(3)}>
                            Available Payers Not in Use
                        </CNavLink>
                    </CNavItem>
                </CNav>
                <CTabContent>
                    <CTabPane>
                        {isLoading ? <ProviderEnrollmentDetailDatatable  /> : progressbar(2)}
                    </CTabPane>
                    <CTabPane>
                        {isLoading ? <ProviderEnrollmentDetailDatatable /> : progressbar(2)}
                    </CTabPane>
                    <CTabPane>
                        {isLoading ? <ProviderEnrollmentDetailDatatable/> : progressbar(2)}
                    </CTabPane>

                </CTabContent>
            </CTabs>




        </>
    )
}


export default ProviderEnrollmentDetail;