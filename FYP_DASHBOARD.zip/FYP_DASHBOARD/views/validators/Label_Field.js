import React from 'react';
import {
  CLabel,
} from '@coreui/react'
import { AddAlertRounded } from '@material-ui/icons';
const Label_Field = (props) => {

  // let name = props.name;
  // let property = props.bold;

  // switch (true) {

  //   case props.check == 1:
  //     if (name == "Claim #") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     } else {
  //       name = (!props.data.PROV_CLAIM_NUM) ? "N/A" : props.data.PROV_CLAIM_NUM;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 2:
  //     if (name == "Payer Name") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.PAYER_NAME) ? "N/A" : props.data.PAYER_NAME;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 3:
  //     if (name == "Payer ID") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.PAYER_ID) ? "N/A" : props.data.PAYER_ID;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 4:
  //     if (name == "Patient") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.PATIENT) ? "N/A" : props.data.PATIENT;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 5:
  //     if (name == "Policy#") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.INSURED_ID) ? "N/A" : props.data.INSURED_ID;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 6:
  //     if (name == "DOS") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.DOS) ? "N/A" : props.data.DOS;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 7:
  //     if (name == "Received By PracticeEHR") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.RECEIVE_DATE) ? "N/A" : props.data.RECEIVE_DATE;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 8:
  //     if (name == "Forwarded to Payer") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.FORWARDED_TO_PAYER_DATE) ? "N/A" : props.data.FORWARDED_TO_PAYER_DATE;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 9:
  //     if (name == "Status Date") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     } else {
  //       name = (!props.data.ACCEPTED_DATE) ? "N/A" : props.data.ACCEPTED_DATE;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 10:
  //     if (name == "Payer Rejected") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.REJECTED_DATE) ? "N/A" : props.data.REJECTED_DATE;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 11:
  //     if (name == "Status") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.ACTUAL_STATUS_DESC) ? "N/A" : props.data.ACTUAL_STATUS_DESC;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 12:
  //     name = (!props.data.REJECTION_REASON) ? (!props.status_description) ? "N/A" : props.status_description : props.data.REJECTION_REASON;
  //     property = true ? "visible" : "invisible";
  //     break

  //   case props.check == 13:
  //     if (name == "Billing Provider") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.BILLING_PROV_NAME) ? "N/A" : props.data.BILLING_PROV_NAME;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 14:
  //     if (name == "NPI") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.BILLING_PROV_NPI) ? "N/A" : props.data.BILLING_PROV_NPI;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 15:
  //     if (name == "Rendering Provider") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.REND_PROV_NAME) ? "N/A" : props.data.REND_PROV_NAME;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 16:
  //     if (name == "Claim Amount") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.CLAIM_AMOUNT) ? "N/A" : props.data.CLAIM_AMOUNT;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 17:
  //     if (name == "Paid Amount") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.X12_835_PAYMENT_SEQ_NUM) ? "N/A" : props.data.X12_835_PAYMENT_SEQ_NUM;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 18:
  //     if (name == "Eligibility") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.ELIG_RESPONSE_DESC) ? "N/A" : props.data.ELIG_RESPONSE_DESC;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 19:
  //     if (name == "Plan Begin Date") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.PLAN_BEGIN_DATE) ? "N/A" : props.data.PLAN_BEGIN_DATE;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 20:
  //     if (name == "Plan End Date") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.PLAN_END_DATE) ? "N/A" : props.data.PLAN_END_DATE;
  //       property = true ? "visible" : "invisible";

  //     }
  //     break

  //   case props.check == 21:
  //     if (name == "Copay") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.COPAY) ? "N/A" : props.data.COPAY;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 22:
  //     if (name == "Case Type") {
  //       property = true ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.CASE_TYPE) ? "" : props.data.CASE_TYPE;
  //       property = true ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 23:
  //     if (name == "IHCFA Tracking #") {
  //       property = (props.data.CASE_TYPE && props.data.CASE_TYPE == "WC" || props.data.CASE_TYPE == "NF") ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.IHCFA_TRACKING_NUM) ? "N/A" : props.data.IHCFA_TRACKING_NUM;
  //       property = (props.data.CASE_TYPE && props.data.CASE_TYPE == "WC" || props.data.CASE_TYPE == "NF") ? "visible" : "invisible";
  //     }
  //     break

  //   case props.check == 24:
  //     if (name == "IHCFA Comments") {
  //       property = (props.data.CASE_TYPE && props.data.CASE_TYPE == "WC" || props.data.CASE_TYPE == "NF") ? "visible" + " " + props.bold : "invisible";
  //     }
  //     else {
  //       name = (!props.data.IHCFA_COMMENTS) ? "N/A" : props.data.IHCFA_COMMENTS;
  //       property = (props.data.CASE_TYPE && props.data.CASE_TYPE == "WC" || props.data.CASE_TYPE == "NF") ? "visible" : "invisible";
  //     }
  //     break
  // }



  return (
    <>
    <CLabel style={{color:props.color}} className={props.visibility} htmlFor={props.name}>{props.name}</CLabel>
      {/* {property == "invisible" ? "" : <CLabel id={props.id} className={property} htmlFor={name}>{name}</CLabel>} */}
    </>
  )
}

export default Label_Field;