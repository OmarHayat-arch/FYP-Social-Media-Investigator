import React, { useEffect, useState } from 'react';
import {
    CButton,
    CLabel,
    CInput,
    CSelect,
    CInputCheckbox,
    CRow
} from '@coreui/react'


const FieldGroup = (props) => {

    const [state, setState] = useState(
        {}
    )


    const [ddlstate, setddlstate] = useState([]);


    useEffect(() => {

        setState(props)




    }, [props])

    useEffect(() => {

        async function createSelectItems() {

            let items = [];
            for (let i = 0; i < props.values[0].data.length; i++) {
                items.push(<option selected={props.name == props.values[0].data[i].VALUE ? props.name : ""} key={i} value={props.values[0].data[i].VALUE}>{props.values[0].data[i].DISPLAY_VALUE}</option>);
                //here I will be creating my options dynamically based on
                //what props are currently passed to the parent component
                //setddlstate("hi");
            }

            setddlstate(items);
            //console.log(items)
            //  return items;

        }
        if (props.values) {
            createSelectItems()
        }

    }, [])


    const handlechange = e => {
        e.persist();
        setState(prevstate => ({ ...prevstate, [e.target.name]: e.target.value }));
    }
    //    function handlechange(e){


    //        setState({value : e.target.value})
    //    }

    function formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    }

    function renderSwitch() {
        switch (true) {
            case props.type == "label":
                return (
                    <>
                        {props.visibility == "invisible" ? "" : <CLabel name={"name"} value={state.name} style={{ color: props.color }} className={props.visibility} htmlFor={props.name}>{props.name}</CLabel>}

                    </>
                )

            case props.type == "button":
                return (
                    <>
                        {props.visibility == "invisible" ? "" : <CButton onClick={props.onClick} style={{ color: props.color }} className={props.visibility}>{props.name}</CButton>}
                        {/* {property == "invisible" ? "" : <CLabel id={props.id} className={property} htmlFor={name}>{name}</CLabel>} */}
                    </>
                )

            case props.type == "text":

                // const ab1 = <input type="text"/>
                // const ab2 = <input type="text"/>
                // const ab3 = <input type="text"/>
                // const ab4 = <input type="text"/>
                return (
                    <div style={{ display: "flex" }}>
                    {props.name.map((e, index) => {
                       
                        return (
                          
                                <CInput  disabled={props.disabled} maxLength={props.maxlength} name={e} value={state.name} onChange={handlechange} style={{ color: props.color }} className={props.visibility} />
                            

                        );
            
                    })}
                                </div>
                )
                // props.loops.map((e)=>{

                // {console.log(e)}


                {/* {props.visibility == "invisible" ? "" : <CInput disabled={props.disabled}  maxLength={props.maxlength} name={"name"} value={state.name} onChange={handlechange}  style={{ color: props.color }} className={props.visibility}/>} */ }
                {/* {props.visibility == "invisible" ? "" : <CInput disabled={props.disabled}  maxLength={props.maxlength} name={"name"} value={state.name} onChange={handlechange}  style={{ color: props.color }} className={props.visibility}/>}
                        {props.visibility == "invisible" ? "" : <CInput disabled={props.disabled}  maxLength={props.maxlength} name={"name"} value={state.name} onChange={handlechange}  style={{ color: props.color }} className={props.visibility}/>}
                        {props.visibility == "invisible" ? "" : <CInput disabled={props.disabled}  maxLength={props.maxlength} name={"name"} value={state.name} onChange={handlechange}  style={{ color: props.color }} className={props.visibility}/>}
                        {property == "invisible" ? "" : <CLabel id={props.id} className={property} htmlFor={name}>{name}</CLabel>}
                       */}


            // })








            case props.type == "dropdown":
                return (
                    <>
                        {props.visibility == "invisible" ? "" : <CSelect disabled={props.disabled} name={"name"} value={state.name} onChange={handlechange} id="select">{ddlstate}</CSelect>}
                    </>
                )
            case props.type == "date":

                return (
                    <>
                        {/* <input type="date" value= {d}/> */}
                        {props.visibility == "invisible" ? "" : <CInput disabled={props.disabled} type="date" id="date-input" name={"name"} value={formatDate(state.name)} onChange={handlechange} style={{ color: props.color }} className={props.visibility} />}
                    </>
                )

            case props.type == "checkbox":

                return (
                    <>
                        {/* <input type="date" value= {d}/> */}
                        {props.visibility == "invisible" ? "" : <CInputCheckbox value={state.name} disabled={props.disabled} id="inline-checkbox1" name={"name"} style={{ color: props.color }} className={props.visibility} />}
                    </>
                )

            //   return(  
            //     props.visibility == "invisible" ? "" : props.type == "button" ?  <CButton onClick={props.onClick} style={{color:props.color}} className={props.visibility}>{props.name}</CButton>
            // : props.type == "label" ?  <CLabel  style={{color:props.color}} className={props.visibility} htmlFor={props.name}>{props.name}</CLabel>
            // :""
            //   )
            //   }
        }
    }

    // {abc(state)}
    return (
        <>
            {renderSwitch()}
        </>
    )

}

export default FieldGroup;



// export const abc = (props) => {
//     console.log("abc")
//        console.log(props)
// }