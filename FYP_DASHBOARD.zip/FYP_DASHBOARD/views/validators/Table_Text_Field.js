import React, { useEffect, useState } from 'react'
import {
    CInput,
    CInvalidFeedback,
    CValidFeedback
} from '@coreui/react'
import { PinDropSharp } from '@material-ui/icons'
function Text_Field(props) {

 const [decide_textfield, setDecideTextField] = useState()
    
useEffect(()=>{
    setDecideTextField(props.value)
},[props.value])

    return (
        <>
            <CInput
            
                type="text" value={decide_textfield}  onChange={(e)=>setDecideTextField(e.target.value) || props.onChangeText(decide_textfield) }   


            />
        </>
    )
}

export default Text_Field
