import React, { useState, useEffect, useRef } from 'react'
import ReactDOM from 'react-dom';
import {
    CButton,
    CCreateElement,
    CCard,
    CCardBody,
    CLabel,
    CCardGroup,
    CCol,
    CContainer,
    CForm,
    CInput,
    CInputGroup,
    CCardHeader,
    CModal,
    CModalHeader,
    CModalTitle,
    CModalBody,
    CModalFooter,
    CInputGroupPrepend,
    CInputGroupText,
    CValidFeedback,
    CInvalidFeedback,
    CRow,
    CTabPane,
    CNavLink,
    CTabs,
    CNav,
    CNavItem,
    CTabContent,
    CSidebarNavDivider,
    CSidebarNavDropdown,
    CSidebarNavItem,
    CSidebarNavTitle
} from '@coreui/react'
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';
import PayerListDatatable from '../datatable/PayerListDatatable';
import progressbar from '../progressbar/progressbar';
import UserProfile from 'src/containers/UserProfile';

const PayerList = () => {

    const tab_input = useRef();
    const [data, setData] = useState([]);
    const [Loading, setLoading] = useState(false);
    const total_query = "select COUNT(*) total from EDI360.V_PORTAL_PAYER_LIST ";
    const query = "SELECT PAYER_NAME, PAYER_ID, IS_837_SUPPORTED, IS_276_SUPPORTED, IS_835_SUPPORTED, IS_270_SUPPORTED, IS_837_ENROLLMENT_REQUIRED, IS_276_ENROLLMENT_REQUIRED, IS_835_ENROLLMENT_REQUIRED, IS_270_ENROLLMENT_REQUIRED, CHARGES_837, CHARGES_276, CHARGES_835, CHARGES_270 FROM EDI360.V_PORTAL_PAYER_LIST ";
    let where_condition = "";


    useEffect(() => {


       
        async function LoadData() {

            if (UserProfile.getStart() === null && UserProfile.getEnd() === null) {
                UserProfile.setStart(0)
                UserProfile.setEnd(100)

            }
            else {

                if (UserProfile.getPayerListType() == "P") {
                    if (UserProfile.getStart() == 0) {

                    }
                    else {
                        UserProfile.setStart(Number(UserProfile.getStart()) - 100);
                        UserProfile.setEnd(Number(UserProfile.getEnd()) - 100);
                    }

                }
                else if (UserProfile.getPayerListType() == "N") {
                    if (UserProfile.getEnd() >= UserProfile.getTotal()) {

                    }
                    else {
                        UserProfile.setStart(Number(UserProfile.getStart()) + 100);
                        UserProfile.setEnd(Number(UserProfile.getEnd()) + 100);

                    }
                }
                else {

                }


            }




            if (UserProfile.getPayerListTab() === null) {
                UserProfile.setPayerListTab(1)
            }

            TabData(UserProfile.getPayerListTab());

        }

        LoadData();
    }, [])


    // useEffect(()=>{

    //     console.log("are you render")
    //     console.log(render)
    //     TabData(1);
    // },[UserProfile.getStart(), UserProfile.getEnd() ])




    async function TabData(tab) {

        if (tab == 1) {
            UserProfile.setPayerListTab(1)
            setLoading(false);
            where_condition = "WHERE CATEGORY='MEDICAL'";

        }

        else if (tab == 2) {
            UserProfile.setPayerListTab(2)
            setLoading(false);
            where_condition = "WHERE CATEGORY='WC'";
        }
        else if (tab == 3) {
            UserProfile.setPayerListTab(3)
            setLoading(false);
            where_condition = "WHERE CATEGORY ='DENTAL'";
        }

        const inline_q1 = "select b.*,rownum rnum from ( " + query + where_condition + " ) b where rownum< " + UserProfile.getEnd();
        const inline_q2 = "select * from ( " + inline_q1 + " ) where rnum >= " + UserProfile.getStart();
        const split = "@Splitter@";
        const url = config.url.API_URL;
        const GetReportURL = url + "/GenericPageValues";
        console.log(inline_q2)
        const input = "?param=" + btoa(inline_q2 + split + total_query + where_condition);

        const param = GetReportURL + input;

        try {

            // var element = document.getElementsByClassName("active")
            // element.classList.remove("active");
        

            let result = await API_Fetcher(param);

            UserProfile.setTotal(result[1].data[0].TOTAL)

            setData(result);
            setLoading(true);

//  let element = document.getElementsByClassName("click_first")
// ReactDOM.findDOMNode(element).classList.remove("active")
           

        } catch (error) {

        }

    }


    return (
        <>


 {/* UserProfile.getPayerListTab() !=1 ? event.target.classList.remove('active') : "" || */}
            <CTabs>
                <CNav >
                    <CNavItem>
                        <CNavLink  className={UserProfile.getPayerListTab() == 1 ?  "custom_tab" : ""}  onClick={() =>  UserProfile.setStart(0) || UserProfile.setEnd(100) || UserProfile.setPayerListType("R") || TabData(1)}>
                            Professional Payer List
                        </CNavLink>
                        
                    </CNavItem>
                    <CNavItem >
                    <CNavLink className={UserProfile.getPayerListTab() == 2 ?  "custom_tab" : ""}  onClick={() =>  UserProfile.setStart(0) || UserProfile.setEnd(100) || UserProfile.setPayerListType("R") || TabData(2)}>
                            Worker Comp and No-Fault Payers List
                        </CNavLink>
                    </CNavItem>
                    <CNavItem>
                    <CNavLink  className={UserProfile.getPayerListTab() == 3 ?  "custom_tab" : ""}  onClick={() =>   UserProfile.setStart(0) || UserProfile.setEnd(100) || UserProfile.setPayerListType("R") || TabData(3)}>
                            Dental Payer List
                        </CNavLink>
                    </CNavItem>

                </CNav>
                <CTabContent>
                    <CTabPane>
                        {/*  */}
                        {/* onStart={(start)=>setStart(start) || alert(start)} onEnd={(end)=>setEnd(end) || alert(end)} */}
                        {Loading ? <PayerListDatatable result={data}  /> : progressbar(2)}

                    </CTabPane>
                    <CTabPane>

                        {Loading ? <PayerListDatatable result={data} /> : progressbar(2)}

                    </CTabPane>
                    <CTabPane>

                        {Loading ? <PayerListDatatable result={data} /> : progressbar(2)}
                    </CTabPane>

                </CTabContent>
            </CTabs>
        </>
    )
}

export default PayerList;