import React, { Suspense, lazy, useState, useEffect } from "react";
import loadReport from "../../ConstantMethods/LoadReport";
import Loader from "../../ConstantMethods/Loader";
import data from 'src/Data/DummyData'
import Error from "../../Errors/Errors";
import axios from 'axios';
import SanctionPakistanDatatable from "../datatable/SanctionPakistanDatatable";
import {
    CBadge,
    CButton,
    CButtonGroup,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CProgress,
    CRow,
    CCreateElement,
    CWidgetIcon,
    CCallout,
    CSidebarNavDivider,
    CSidebarNavDropdown,
    CSidebarNavItem,
    CSidebarNavTitle,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'

const ReportViewer = lazy(() => import("src/Viewer/ReportViewer"));

const SanctionPakistan = () => {

    const[records,setRecords]=useState([]);
    const[loader,setLoader]=useState(false);
    const[tweet,setTweet]=useState("");
    const[user,setUser]=useState("");
    const[sentiment,setSentiment]=useState("");
 





    useEffect(() => {
        axios.get('http://localhost:5000/trends/SanctionPakistan')
        .then(res =>{setRecords(res)
        setLoader(true);
        //setTweet(records.data.Trend);

        
        //console.log(records.data.content.length);
        //console.log(records);
        }
        );
    }, [])
    function check()
    {
        let max_index=0;
        let min=0
        let max=0;
        for(let i=0;i<records.data.content.length;i++)
        {
            let current=records.data.content[i].RETWEETS;
            if(max<current)
            {
                max=current;
                max_index=i;
            }
            
        }
        setTweet(records.data.content[max_index].TWEET)
        //setSentiment(records.data.content[max_index].Sentiment)
        setSentiment(records.data.content[max_index].Sentiment)
        setUser(records.data.content[max_index].RETWEETS)
    }
   
    // console.log(data)

    return (
        <>

 {loader ? <SanctionPakistanDatatable result={records}/>:""}
 <br/>
 <br/>
 <CRow id="test">
                <CCol xs="12" sm="6" lg="4">
                    <CWidgetIcon
                        style={{cursor:"pointer"}}
                        onClick={()=>  check()}
                        header={"Most Influential Tweet"}
                        text={tweet}
                        color="danger" //success danger primary warning
                    >
                        <CIcon width={24} name="cil-calendar" className="icon icon-xl" />
                    </CWidgetIcon>
                </CCol>
                <CCol xs="12" sm="6" lg="4">
                    <CWidgetIcon
                        header={"Sentiment"}
                        text={sentiment}
                        color="success" //success danger primary warning
                    >
                        <CIcon width={24} name="cil-calendar" className="icon icon-xl" />
                    </CWidgetIcon>
                </CCol>
                <CCol xs="12" sm="6" lg="4">
                    <CWidgetIcon
                        header={"User Name"}
                        text={user}
                        color="primary" //success danger primary warning
                    >
                        <CIcon width={24} name="cil-calendar" className="icon icon-xl" />
                    </CWidgetIcon>
                </CCol>
            </CRow>


        </>
    )
}
export default SanctionPakistan;
