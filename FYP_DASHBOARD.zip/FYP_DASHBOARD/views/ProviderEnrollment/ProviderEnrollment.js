import React,{useState,useEffect} from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CSwitch
} from '@coreui/react'
import Dynamicdatatable from 'src/views/datatable/Dynamicdatatable'
import {config} from 'src/containers/API_Call_Constant'
import API_Fetcher from 'src/containers/API_Fetcher'
import progressbar from 'src/views/progressbar/progressbar'
import UserProfile from 'src/containers/UserProfile';
import moment from 'moment';
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';
import ProvEnrollmentDatatable from '../datatable/ProvEnrollmentDatatable'

//const era_query = "SELECT RECEIVED_DATE, CHECK_DATE, CHECK_NUM,TO_CHAR(CHECK_AMT, '$99,999,999,999,999,999.99') CHECK_AMT, initcap(PAYER) PAYER, initcap(PAYEE) PAYEE, PAYEE_ID, FILE_STATUS, VEN_835_FILE_SEQ_NUM as SEQ_NUM, CLIENT_SEQ_NUM, STATUS, SHARED_PATH as FILE_PATH, FILE_FLAG,  SEQ_NUM as ERA_SEQ_NUM, PAYMENT_METHOD, PAYMENT_METHOD_DESC, IS_PLB_AVAILABLE, DOWNLOAD_DATE FROM VP_ERA_CHECKS  WHERE CLIENT_SEQ_NUM = " + UserProfile.getSeqnum() + " and rownum < 50";
const customized_col_names=["Billing Provider","NPI Type","NPI","Tax ID","Address","City","State","Zip"];
const customized_col_index=[0,1,2,3,4,5,6,7];
const cells = ["BillingProv"]

function ProviderEnrollment() {
    const [data,setData]=useState([]);
    const [isLoading,setLoading] = useState(false);

    
    
        useEffect(() => {
        
            async function LoadData() {
    
    
                const url = config.url.API_URL;
                const GetReportURL = url +"/ediportal/api/v1/RequestHandler";
          
                const obj = {
                  tag_name: 'ProvEnrollment_request',
                  parameters: `${UserProfile.getSeqnum()}@splitter@LiveDB`
                }
          
                const param = {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(obj)
                }
    
              try {
                let { status, data } = await API_Fetcher(GetReportURL, param)
                
                
    
                setData(data[0]);
                setLoading(true);
    
                
              } catch (error) {
              }
            }
            LoadData();
          }, [])


    return (
        <div>
           
 
{isLoading  ? <ProvEnrollmentDatatable result = {data}   column_name = {customized_col_names} column_index = {customized_col_index}  cells={cells}   /> :progressbar(2) } 

        </div>
    )
}

export default ProviderEnrollment
