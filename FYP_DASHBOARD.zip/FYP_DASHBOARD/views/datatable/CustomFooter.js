import React from "react";
import TableFooter from "@material-ui/core/TableFooter";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import { withStyles } from "@material-ui/core/styles";
import TablePagination from "@material-ui/core/TablePagination";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import AddIcon from "@material-ui/icons/Add";
import SkipNextIcon from '@material-ui/icons/SkipNext';
import SkipPreviousIcon from '@material-ui/icons/SkipPrevious';
import UserProfile from "src/containers/UserProfile";
import {
    CButton,
    CCreateElement,
    CLabel,
    CSidebarNavDivider,
    CSidebarNavDropdown,
    CSidebarNavItem,
    CSidebarNavTitle
} from '@coreui/react'
import { BrowserRouter as Router, Route, Switch, Link, Redirect, withRouter } from "react-router-dom";
import PayerList from "../PayerList/PayerList";
import history from 'history';

const defaultFooterStyles = {
    //   root: {
    //     "&:last-child": {
    //       padding: "0px 0px 0px 590px"
    //     }
    //  }
};

class CustomFooter extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            start: this.props.start,
            end: this.props.end,
            render: false,
        }
        //  this.handleClick = this.handleClick.bind(this)
        // this.handlePev = this.handlePrev.bind(this)



        // this.routeChange = this.routeChange.bind(this);
    }



    // handleClick = (type) => {
    //     UserProfile.setPayerListType(type)
    // };

    // routeChange() {
    //     let path = `dashboard`;
    //     this.props.history.push(path);
    //   }




    handlepagination(symbol) {

        
        this.customfootbar_nav = [{
            _tag: 'CSidebarNavItem',
            name: symbol,
            to: window.location.href.includes("Datatable") ? "PayerList" : "PayerList_Datatable",
            
        }]


        return (
            <>
                <CCreateElement items={this.customfootbar_nav}

                    components={{
                        CSidebarNavDivider,
                        CSidebarNavDropdown,
                        CSidebarNavItem,
                        CSidebarNavTitle
                    }}
                />
            </>
        );

    }

    // handleNext() {
    //     return <Redirect to="/dashboard" />
    //     //     alert("hjshdf")
    //     //    return <Redirect to="/dashboard"/>
    //     //  {this.check()};

    //     // if (this.state.render == false) {
    //     //     this.setState({
    //     //         render: true,
    //     //     })
    //     // }
    //     // else {
    //     //     this.setState({
    //     //         render: false,
    //     //     })
    //     // }

    //     // UserProfile.setStart(Number(this.props.start) + 100);
    //     // UserProfile.setEnd(Number(this.props.end) + 100);
    //     // this.props.onChangeRender(this.state.render)
    //     // this.setState({
    //     //     start: this.state.start + 100,
    //     //     end: this.state.end + 100,
    //     // }
    //     //     , () => {
    //     //         UserProfile.setStart(this.state.start);
    //     //         UserProfile.setEnd(this.state.end);

    //     //         this.props.onChangeRender(this.state.render)
    //     //     }
    //     // )
    // }

    // handlePrev() {
    //     if (this.state.render == false) {
    //         this.setState({
    //             render: true,
    //         })
    //     }
    //     else {
    //         this.setState({
    //             render: false,
    //         })
    //     }

    //     UserProfile.setStart(this.props.start - 100);
    //     UserProfile.setEnd(this.props.end - 100);
     
    // }

   

    render() {

        const { classes } = this.props;


        //    return <Redirect to="/PayerList"/>
        return (

            <TableFooter>
                <TableRow>
                    <TableCell>
                        <React.Fragment>

                            {/* <Router>
                                <Link to="/dashboard">Landing</Link>
                                <Switch>
                                    <Route exact path="/dashboard" />
                                </Switch>

                            </Router> */}




                            <Tooltip title={"Previous 100"}>
                                <IconButton
                                    className={classes.iconButton}
                                    onClick={()=>UserProfile.setPayerListType("P")}
                                >
                                    {this.handlepagination("<<")}
                                    {/* <SkipPreviousIcon className={classes.deleteIcon} /> */}
                                </IconButton>
                            </Tooltip>

                            <Tooltip title={"Next 100"}>
                                <IconButton
                                    className={classes.iconButton}
                                    onClick={()=>UserProfile.setPayerListType("N")}
                                >
                                    {this.handlepagination(">>")}
                                    
                                    {/* <SkipNextIcon className={classes.deleteIcon} /> */}
                                </IconButton>
                            </Tooltip>

                            <CLabel htmlFor="name"><b>{UserProfile.getStart()}-{UserProfile.getEnd()} of {UserProfile.getTotal()}</b></CLabel>


                        </React.Fragment>
                    </TableCell>

                    <TableCell>
                        <TablePagination
                            className={classes.root}
                            count={this.props.count}
                            page={this.props.page}
                            rowsPerPage={this.props.rowsPerPage}
                            onChangePage={this.props.onChangePage}
                            onChangeRowsPerPage={this.props.onChangeRowsPerPage}

                        />
                    </TableCell>
                </TableRow>
            </TableFooter>
        );
    }
}

export default withStyles(defaultFooterStyles, { name: "CustomFooter" })(
    CustomFooter
);


