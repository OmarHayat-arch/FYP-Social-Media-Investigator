import React, { useEffect, useState,useRef } from "react";
import ReactDOM from "react-dom";
import MUIDataTable from "mui-datatables";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import VisitDetail from "../visitdetails/VisitDetail";
import {
  CButton,
  CCard,
  CCardBody,
  CLabel,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CInput,
  CInputGroup,
  CCardHeader,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CInputGroupPrepend,
  CInputGroupText,
  CValidFeedback,
  CInvalidFeedback,
  CRow,
  CTabPane,
  CNavLink,
  CTabs,
  CNav,
  CNavItem,
  CTabContent
} from '@coreui/react'
import Text_Field from 'src/views/validators/Text_Field'
import { SettingsInputAntennaTwoTone, SettingsRemote, TitleSharp } from "@material-ui/icons";

import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from "src/containers/API_Fetcher";
import CustomToolbar from "../visitdetails/CustomToolbar";
import UserProfile from "src/containers/UserProfile";
import Table_Text_Field from "../validators/Table_Text_Field";
import CustomToolbarSelect from "../visitdetails/CustomToolbarSelect";
import progressbar from "../progressbar/progressbar";
import CustomFooter from "./CustomFooter";

const PayerListDatatable = (props) => {

const test_ref = useRef();


const[render,setRender] = useState([]);

    // const [start,setStart] = useState();
    // const [end,setEnd]=useState();

    
  const [responsive, setResponsive] = useState("standard");
  const [tableBodyHeight, setTableBodyHeight] = useState("400px");
  const [tableBodyMaxHeight, setTableBodyMaxHeight] = useState("");

 useEffect(()=>{
  // const x = document.getElementsByTagName("h6")[0];
  // if(x != undefined){
  //   // console.log(x)
  //   x.innerHTML = "Change";
  //   var h = document.createElement("H1");
  //   var t = document.createTextNode("testing");
  //   h.appendChild(t);
  //   x.appendChild(h);
  //   // console.log(x)
  //   //  x.classList.add("what");
  //   }
  //   else{
  //     }
  
  // setRender(x)


  
  

// console.log(test_ref.current.props.components.TableHead)

  },[props])





  
   let columns = [];
  let rows = [];

  // const columns = [];

  // columns.push([
  //      {
  //     label: "POS",
  //     options: {
  //       filter: true,
    
  //     }
  //   },
  // ])
  
  // const columns = [
  //     {
  //     name: "POS",
  //     options: {
  //       filter: true,
    
  //     }
  //   }
  // ]

  // const columns = [
  //   "Date",
  // {
  //   name: "Description",
  //   options: {
  //     filter: false,
  //   }
  // },
  //   {
  //     name: "POS",
  //     options: {
  //       filter: true,
    
  //     }
  //   },
  //   {
  //     name: "CPT",
  //     options: {
  //       filter: true,
       
  //     }
  //   },
  //   {
  //     name: "Modifiers",
  //     options: {
  //       filter: false,
       
  //     }
  //   },
  //   {
  //     name: "Diagnosis Pointers",
  //     options: {
  //       filter: true,
       
  //     }
  //   },
  //   {
  //     name: "Units Qualifier",
  //     options: {
  //       filter: true,
     
  //     }
  //   },
  //   {
  //     name: "Units",
  //     options: {
  //       filter: true,
       
  //     }
  //   },
  //   {
  //     name: "Charges",
  //     options: {
  //       filter: true,
     
  //     }
  //   }

  // ];

  
  // console.log(columns)

  for (var key in props.result[0].data) {
    for (var fetch = 0; fetch < Object.keys(props.result[key].data[key]).length; fetch++) {

        columns.push(Object.keys(props.result[key].data[key])[fetch])
      
    }
    break
  }


  for(var i=0 ; i< props.result[0].data.length; i++){

    let temp = [];
    for (var fetch = 0; fetch < Object.keys(props.result[0].data[i]).length; fetch++) {
    
        temp.push(
          Object.values(props.result[0].data[i])[fetch],
        )
    
    }
  
    rows.push(temp);
  }

  
 
  const getMuiTheme = () => createMuiTheme({
    palette: {
      primary: {
        light: "#5392aa",
        main: "#5392aa",
        dark: "#5392aa",
        contrastText: "#5392aa"
      }
    },
    overrides: {
      
      MuiTableCell: {
        head: {
          backgroundColor: "#e3fbfd  !important",
        
          //fontWeight:"bold",
          //"font-weight": 'bold'
        },
        root :{
          display: "table-cell",
          borderBottom: "1px solid rgba(224, 224, 224, 1)",
          padding:"0px",
          textAlign:"left"
        }
      },
      MuiButton: {
        label: {
          //backgroundColor: 'blue',
          fontWeight:"600",
          width: "150px" ,
          justifyContent:"left !important"
          
        }
      },
      MUIDataTableBodyCell: {
        root: {
         // backgroundColor: "red",
          width: "150px"
        }
      },
      MUIDataTableToolbar: {
        root: {
          backgroundColor: "#e9e9e9  !important",
          // color: "white !important"  5392aa
        },
        
      },
      CustomToolbar: {
        root: {
          backgroundColor: "red !important"
        }
      }
    }

  })

  const options = {
    fixedSelectColumn: false,
    // jumpToPage: true,
    // count:props.result[1].data[0].TOTAL,
    //  page:0,
    //  count:100,
    // count:,
    filter: true,
    filterType: "dropdown",
    print: false,
    responsive,
    tableBodyHeight,
    tableBodyMaxHeight,
    draggableColumns:{
      enabled: true
    },  
    customFooter: (
      count,
      page,
      rowsPerPage,
      changeRowsPerPage,
      changePage,
      start,
      end
    ) => {
      return (
        <CustomFooter
          count={count}
          page={page}
          rowsPerPage={rowsPerPage}
          onChangeRowsPerPage={event => changeRowsPerPage(event.target.value)}
          onChangePage={(_, page) => changePage(page) }
          start={props.start}
          end={props.end}
          onChangeRender={render =>  props.onRender(render)}

          // props.onRender(render)
    
          // onChangeStart={start => setStart(start) || props.onStart(start) }
          // onChangeEnd={end => setEnd(end) || props.onEnd(end)}

        />
      );
    }

  };




  return (
    <React.Fragment>

      {/* {render != undefined ?  render.innerHTML : ""} */}


      <MuiThemeProvider theme={getMuiTheme()}>
        <MUIDataTable
        ref={test_ref}
          title={"PracticeEHR Payer List"}
          data={rows}
          columns={columns}
          options={options}
        />
      </MuiThemeProvider>
    </React.Fragment>
  );
}



export default PayerListDatatable;




