import react from 'react'

const ProviderEnrollmentDetailDatatable = () =>{
    return(
        <>
        </>
    )
}


export default ProviderEnrollmentDetailDatatable