import React, { useEffect, useState } from 'react';

import {
    CButton,
    CCard,
    CCardBody,
    CTabPane,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CNavLink,
    CTabContent,
    CNavItem,
    CNav,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CTabs,
    CSwitch
} from '@coreui/react'
import { config } from 'src/containers/API_Call_Constant';
import API_Fetcher from 'src/containers/API_Fetcher';
import ClaimStatusDetailDatatable from '../datatable/ClaimStatusDetailDatatable';
import progressbar from '../progressbar/progressbar';


const customized_col_names = ["CPT", "Charge Amt", "Paid Amt", "Billed Units", "Paid Units", "Category", "Status"];
const customized_col_index = [0, 1, 2, 3, 4, 5, 6];
const cells = [""]

const ClaimStatusDetail = (props) => {

    const [isLoading, setLoading] = useState(false);
    const [data, setData] = useState();

    const [Category, setCategory] = useState();
    const [Status, setStatus] = useState();

    useEffect(() => {

        async function LoadData() {


            const url = config.url.API_URL;
            const GetReportURL = url + "/ediportal/api/v1/RequestHandler";

            const obj = {
                tag_name: 'ClaimStatusDetail_request',
                parameters: `${props.rowData[11]}@splitter@LiveDB`
            }

            const param = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(obj)
            }

            try {
                let { status, data } = await API_Fetcher(GetReportURL, param)



                setData(data[0]);
                CategoryRecord(data[1]);
                StatusRecord(data[2]);
                setLoading(true);


            } catch (error) {
            }
        }
        LoadData();
    }, [])


    function CategoryRecord(obj) {


        let category = [];

        if ("Empty" in obj.data) {
        }
        else {
            for (var i = 0; i < obj.data.length; i++) {
                category.push(<CLabel style={{ fontWeight: "bold" }} className="" htmlFor="select">{Object.values(obj.data[i])[0]}&nbsp; &nbsp;</CLabel>);
                category.push(<CLabel className="" htmlFor="select">{Object.values(obj.data[i])[1]}&nbsp; &nbsp;</CLabel>)
            }
        }

        setCategory(category);

    }

    function StatusRecord(obj) {


        let status = [];

        if ("Empty" in obj.data) {
        }
        else {
            for (var i = 0; i < obj.data.length; i++) {
                status.push(<CLabel style={{ fontWeight: "bold" }} className="" htmlFor="select">{Object.values(obj.data[i])[0]}&nbsp; &nbsp;</CLabel>);
                status.push(<CLabel className="" htmlFor="select">{Object.values(obj.data[i])[1]}&nbsp; &nbsp;</CLabel>)
            }
        }

        setStatus(status);

    }


    function HanldleSubmit() {
        props.onChange(false);

    }
    return (
        <>

            <CRow>
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardHeader className="providerenrollmentheader">
                            <CRow>
                                <CCol className="col-9">
                                    <small>
                                        <strong>Claim Status</strong>
                                    </small>
                                </CCol>
                                <CCol className="d-flex justify-content-end col-3">
                                    <CButton onClick={() => HanldleSubmit()} type="submit" color="primary" className="custom_button">BACK</CButton>
                                </CCol>
                            </CRow>
                        </CCardHeader>
                        <CCardBody >
                            <CRow>
                                <CCol xs="12" sm="12" lg="4">
                                    <CCard className="customizeCard">

                                        <CCardBody>
                                            <CRow>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Claim #</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[2]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Payer Name</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[3]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Payer ID</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[18]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Patient</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[32]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Policy #</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[22]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">DOS</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[5]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                            </CRow>



                                        </CCardBody>
                                    </CCard>
                                </CCol>



                                <CCol xs="12" sm="12" lg="4">
                                    <CCard className="customizeCard">
                                        <CCardBody>

                                            <CRow>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Billing Provider</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[19]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">NPI</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[20]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Rendering Provider</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[4]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Claim Amount</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{"$" + props.rowData[23]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Paid Amount</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{"$" + props.rowData[24]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">

                                                        </CCol>
                                                        <CCol xs="12" md="6" className="form colSize">

                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                            </CRow>
                                        </CCardBody>
                                    </CCard>
                                </CCol>


                                <CCol xs="12" sm="12" lg="4">

                                    <CCard style={{ border: "none" }} className="customizeCard">
                                        <CCardBody>
                                            <CCol md="12" className="text-center" style={{ background: "#C9E3F4" }}>
                                                <CLabel className="headerBold">Claim Processing Status</CLabel>
                                            </CCol>
                                            {/* <CCard className="customizeCard">
                        <CCardBody> */}
                                            <CRow>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Received By PracticeEHR</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[29]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Forwarded to Payer</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[33]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Payer Accepted</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[34]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Payer Rejected</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[35]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Status</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" style={{ color: props.rowData[37] == "F" || props.rowData[37] == "J" ? "#FF0000" : "#2A587C" }} htmlFor="select">{props.rowData[36]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                            </CRow>


                                        </CCardBody>
                                    </CCard>
                                </CCol>
                            </CRow>

                            <CRow>
                                <CCol xs="12" sm="12" lg="4">
                                    <CCard className="customizeCard">
                                        <CCardBody>

                                            <CRow>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Payer Claim #</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[28]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Status Date</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[8]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                            </CRow>
                                        </CCardBody>
                                    </CCard>
                                </CCol>


                                <CCol xs="12" sm="12" lg="4">
                                    <CCard className="customizeCard">
                                        <CCardBody>

                                            <CRow>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Category</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" style={{ color: "#9c0000" }} htmlFor="select">{props.rowData[6]}</CLabel>
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[14]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>


                                            </CRow>
                                        </CCardBody>
                                    </CCard>
                                </CCol>


                                <CCol xs="12" sm="12" lg="4">
                                    <CCard className="customizeCard">
                                        <CCardBody>

                                            <CRow>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="6">
                                                            <CLabel className="labelbold" htmlFor="select">Status</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="6" >
                                                            <CLabel className="valuelabel" style={{ color: "#9c0000" }} htmlFor="select">{props.rowData[15]}</CLabel>
                                                            <CLabel className="valuelabel" htmlFor="select">{props.rowData[16]}</CLabel>
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>


                                            </CRow>
                                        </CCardBody>
                                    </CCard>
                                </CCol>

                            </CRow>

                            {isLoading ? <ClaimStatusDetailDatatable result={data} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : progressbar(2)}




                            <CRow>
                                <CCol xs="12" sm="12" lg="12">
                                    <CCard className="customizeCard">
                                        <CCardBody>

                                            <CRow>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="2">
                                                            <CLabel className="labelbold" htmlFor="select">Category Codes</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="10" >
                                                            {Category}
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                            </CRow>
                                        </CCardBody>
                                    </CCard>
                                </CCol>

                                <CCol xs="12" sm="12" lg="12">
                                    <CCard className="customizeCard">
                                        <CCardBody>

                                            <CRow>

                                                <CCol xs="12" sm="12" md="4" lg="12">
                                                    <CFormGroup row className="customizeRow">
                                                        <CCol xs="12" sm="12" md="6" lg="2">
                                                            <CLabel className="labelbold" htmlFor="select">Status Codes</CLabel>
                                                        </CCol>
                                                        <CCol xs="12" sm="12" md="6" lg="10" >
                                                            {Status}
                                                        </CCol>
                                                    </CFormGroup>
                                                </CCol>
                                            </CRow>
                                        </CCardBody>
                                    </CCard>
                                </CCol>
                            </CRow>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    )
}

export default ClaimStatusDetail;