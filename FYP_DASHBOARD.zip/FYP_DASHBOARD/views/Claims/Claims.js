import React, { useState, useEffect } from 'react'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CCollapse,
    CDropdownItem,
    CDropdownMenu,
    CDropdownToggle,
    CFade,
    CForm,
    CFormGroup,
    CFormText,
    CValidFeedback,
    CInvalidFeedback,
    CTextarea,
    CInput,
    CInputFile,
    CInputCheckbox,
    CInputRadio,
    CInputGroup,
    CInputGroupAppend,
    CInputGroupPrepend,
    CDropdown,
    CInputGroupText,
    CLabel,
    CSelect,
    CRow,
    CSwitch
} from '@coreui/react'

import { config } from 'src/containers/API_Call_Constant'
import API_Fetcher from 'src/containers/API_Fetcher'
import progressbar from 'src/views/progressbar/progressbar'
import UserProfile from 'src/containers/UserProfile';
import moment from 'moment';
import Backdrop from '@material-ui/core/Backdrop';
import { makeStyles } from '@material-ui/core/styles';
import ClaimsDatatable from 'src/views/datatable/ClaimsDatatable'

// const singlequote = '\'';
// const user_query = "SELECT ALLOW_SEND_TO_PM FROM CLIENT_PORTAL_USERS  WHERE CLIENT_SEQ_NUM = "+ UserProfile.getSeqnum() + "  and USER_NAME = " + singlequote + UserProfile.getName() + singlequote ;
// const workqueue_query = "SELECT initcap(PATIENT) PATIENT, INSURED_ID,TO_CHAR(AMOUNT, '$99,999,999,999,999,999.99') AMOUNT, PAYER_ID,PROV_CLAIM_NUM,RECEIVED_DATE ENTRY_DATE,STATUS, EDI360_CLAIM_NUM, FILE_NAME ,  REJECTION_REASON , '' TEMP, X12_SBR_CLAIM_SEQ_NUM, INTERNAL_STATUS,initcap(PAYER_NAME) PAYER_NAME, DOS,' '  Space  FROM EDI360.VP_WORK_QUEUE_CLAIMS WHERE CLIENT_SEQ_NUM = " + UserProfile.getSeqnum() + " ORDER BY ENTRY_DATE desc";
const customized_col_names = ["Provider Claim #", "Received Date", "Provider", "Patient", "Insured ID", "DOS", "Amount", "Payer Name", "Status", "Rejection Reason", "IHCFA Tracking #", "IHCFA Comments", "Claim Type", "Case #", "Form Type"];
const customized_col_index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
const cells = ["ProvClaimNum"]

function Claims(props) {
    const [data, setData] = useState([]);
    const [isLoading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);

    const [DosFrom, setDosFrom] = useState();
    const [DosTo, setDosTo] = useState();
    const [Status, setStatus] = useState("ALL");
    const [EntryFrom, setEntryFrom] = useState();
    const [EntryTo, setEntryTo] = useState();
    const [ProviderClaim, setProviderClaim] = useState();
    const [Duration, setDuration] = useState("ALL");
    const [RejectionReason, setRejectionReason] = useState();
    const [Provider, setProvider] = useState();
    const [Case, setCase] = useState();
    const [Form, setForm] = useState("ALL");
    const [ClaimType, setClaimType] = useState("ALL");

    const handleClose = () => {
        setOpen(false);
    };
    const handleToggle = () => {
        setOpen(!open);
    };

    const useStyles = makeStyles((theme) => ({
        backdrop: {
            zIndex: theme.zIndex.drawer + 1,
            color: '#fff',
        },
    }));

    const classes = useStyles();

    async function hanldleSubmit() {

        handleToggle();
        const url = config.url.API_URL;
        const GetReportURL = url +"/ediportal/api/v1/RequestHandler";

        const obj = {
            tag_name: 'Claims_request',
            parameters: `${props.seqnum}@splitter@${DosFrom}@splitter@${DosTo}@splitter@${Status}@splitter@${EntryFrom}@splitter@${EntryTo}@splitter@${ProviderClaim}@splitter@${Duration}@splitter@${RejectionReason}@splitter@${Provider}@splitter@${Case}@splitter@${Form}@splitter@${ClaimType}@splitter@${UserProfile.getSeqnum()}@splitter@LiveDB`
        }

        const param = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(obj)
        }

        try {
            let { status, data } = await API_Fetcher(GetReportURL, param)


            setData(data[0]);
            setLoading(true);
            setOpen(false);

        } catch (error) {
        }

    }

    useEffect(() => {

         async function LoadData() {


            handleToggle();
            const url = config.url.API_URL;
            const GetReportURL = url +"/ediportal/api/v1/RequestHandler";
    
            const obj = {
                tag_name: 'Claims_request',
                parameters: `${props.seqnum}@splitter@${DosFrom}@splitter@${DosTo}@splitter@${Status}@splitter@${EntryFrom}@splitter@${EntryTo}@splitter@${ProviderClaim}@splitter@${Duration}@splitter@${RejectionReason}@splitter@${Provider}@splitter@${Case}@splitter@${Form}@splitter@${ClaimType}@splitter@${UserProfile.getSeqnum()}@splitter@LiveDB`
            }
    
            const param = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(obj)
            }
    
            try {
                let { status, data } = await API_Fetcher(GetReportURL, param)
    
    
                setData(data[0]);
                setLoading(true);
                setOpen(false);
    
            } catch (error) {
            }
        }
        if(props.seqnum == undefined){}else{ LoadData();}
    }, [])


    function hanldleBack() {
        props.onChange(false);

    }

    return (
        <div>
            <CRow id="ClaimsFilter" className="ClaimsFilter"> 
                <CCol xs="12" sm="12" lg="12">
                    <CCard>
                        <CCardBody>
                            <CRow >
                            <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                       
                                        </CCol>
                                        <CCol xs="12" md="9">
                                       
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                       
                                        </CCol>
                                        <CCol xs="12" md="9">
                                       
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            {/* <CLabel className="custom_label" htmlFor="date-input">Archived DB</CLabel> */}
                                        </CCol>
                                        <span style={{marginLeft:"auto",display:"flex"}}>
                                            Archived DB &nbsp;&nbsp;
                                        {/* <CLabel className="custom_label" htmlFor="date-input">Archived DB</CLabel> */}
                                            <CSwitch

                                                labelOn="ON"
                                                labelOff="OFF"
                                                className="mr-1"
                                                color="info"
                                                shape="pill"
                                                variant="outline"
                                            />
                                        </span>
                                    </CFormGroup>
                                </CCol>

                            </CRow>
                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>

                                    <CCol md="3">
                                            <label className="custom_label" htmlFor="date-input">DOS From</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()}  value={DosFrom==undefined? "": moment(DosFrom).format('YYYY-MM-DD')}  onChange={(e)=>setDosFrom(moment(e.target.value).format('MM-DD-YYYY'))} type="date"   name="date-input" placeholder="DOS From" />
                                            <div class="divider"></div>
                                            {DosFrom == undefined ?"" : <button onClick={()=> {setDosFrom(undefined)}} className="custom_clear">X</button> }
                                        </CCol>

                                        
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>

                                    <CCol md="3">
                                            <label className="custom_label" htmlFor="date-input">DOS To</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()}  value={DosTo==undefined? "": moment(DosTo).format('YYYY-MM-DD')}  onChange={(e)=>setDosTo(moment(e.target.value).format('MM-DD-YYYY'))} type="date"   name="date-input" placeholder="DOS To" />
                                            <div class="divider"></div>
                                            {DosTo == undefined ?"" : <button onClick={()=> {setDosTo(undefined)}} className="custom_clear">X</button> }
                                        </CCol>

                                      
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="select">Status</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CSelect onChange={(e) => setStatus(e.target.value)} custom name="select" id="select">
                                                <option value="ALL">ALL</option>
                                                <option value="WAITING FOR PAYER RESPONSE">WAITING FOR PAYER RESPONSE</option>
                                                <option value="FORWARDED TO PAYER">FORWARDED TO PAYER</option>
                                                <option value="RECEIVED BY PAYER">RECEIVED BY PAYER</option>
                                                <option value="ACCEPTED BY PAYER">ACCEPTED BY PAYER</option>
                                                <option value="PAYER REJECTED">PAYER REJECTED\SENT TO PM</option>
                                                <option value="PRACTICEEHR REJECTED"> REJECTED BY PRACTICEEHR</option>


                                            </CSelect>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                            </CRow>

                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>

                                    <CCol md="3">
                                            <label className="custom_label" htmlFor="date-input">Entry From</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()}  value={EntryFrom==undefined? "": moment(EntryFrom).format('YYYY-MM-DD')}  onChange={(e)=>setEntryFrom(moment(e.target.value).format('MM-DD-YYYY'))} type="date"   name="date-input" placeholder="Entry From" />
                                            <div class="divider"></div>
                                            {EntryFrom == undefined ?"" : <button onClick={()=> {setEntryFrom(undefined)}} className="custom_clear">X</button> }
                                        </CCol>


                                    
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>

                                    <CCol md="3">
                                            <label className="custom_label" htmlFor="date-input">Entry To</label>
                                        </CCol>
                                        <CCol xs="12" md="9" className="form">
                                            <CInput onKeyDown={(e) => e.preventDefault()}  value={EntryTo==undefined? "": moment(EntryTo).format('YYYY-MM-DD')}  onChange={(e)=>setEntryTo(moment(e.target.value).format('MM-DD-YYYY'))} type="date"   name="date-input" placeholder="Entry To" />
                                            <div class="divider"></div>
                                            {EntryTo == undefined ?"" : <button onClick={()=> {setEntryTo(undefined)}} className="custom_clear">X</button> }
                                        </CCol>


                                      
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Provider Claim #</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CInput onChange={(e) => setProviderClaim(e.target.value)} id="name" placeholder="Provider Claim #" required />
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                            </CRow>



                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="select">Select Range</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CSelect onChange={(e) => setStatus(e.target.value)} custom name="select" id="select">
                                                <option value="ALL">ALL</option>
                                                <option value="TODAY">TODAY</option>
                                                <option value="THIS WEEK">THIS WEEK</option>
                                                <option value="THIS MONTH TO DATE">THIS MONTH TO DATE</option>
                                                <option value="LAST 30 DAYS">LAST 30 DAYS</option>
                                                <option value="LAST SIX MONTH">LAST SIX MONTH</option>



                                            </CSelect>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Rejection Reason</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CInput onChange={(e) => setRejectionReason(e.target.value)} id="name" placeholder="Rejection Reason" required />
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Provider</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CInput onChange={(e) => setProvider(e.target.value)} id="name" placeholder="Provider" required />
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                            </CRow>


                            <CRow>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="date-input">Case #</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CInput onChange={(e) => setCase(e.target.value)} id="name" placeholder="Case #" required />
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="select">Form</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CSelect onChange={(e) => setForm(e.target.value)} custom name="select" id="select">
                                                <option value="ALL">ALL</option>
                                                <option value="EC4NARR">EC4NARR</option>
                                                <option value="EC4AMR">EC4AMR</option>
                                                <option value="OTPT4">OTPT4</option>


                                            </CSelect>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                                <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                            <CLabel className="custom_label" htmlFor="select">Cliam Type</CLabel>
                                        </CCol>
                                        <CCol xs="12" md="9">
                                            <CSelect onChange={(e) => setClaimType(e.target.value)} custom name="select" id="select">
                                                <option value="ALL">ALL</option>
                                                <option value="DENTAL">DENTAL</option>
                                                <option value="MEDICAL">MEDICAL</option>
                                                <option value="WC">WC</option>
                                                <option value="NF">NF</option>

                                            </CSelect>
                                        </CCol>
                                    </CFormGroup>
                                </CCol>
                            </CRow>


                            <CRow>

                            <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                      
                                        </CCol>
                                        <CCol xs="12" md="9">
                                      
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                
                            <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                      
                                        </CCol>
                                        <CCol xs="12" md="9">
                                      
                                        </CCol>
                                    </CFormGroup>
                                </CCol>

                                
                            <CCol xs="12" sm="12" md="4" lg="4">
                                    <CFormGroup row>
                                        <CCol md="3">
                                      
                                        </CCol>
                                        <CCol xs="12" md="9">
                                        <CButton onClick={() => hanldleSubmit()} type="submit" color="primary" className="custom_button col-md-12">Search</CButton>
                                    {open && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>}
                                        </CCol>
                                    </CFormGroup>
                                </CCol>




                                {/* <CCol xs="12" className="text-center">
                                    <CButton onClick={() => hanldleSubmit()} type="submit" color="primary" className="custom_button">Search</CButton>
                                    {open && <Backdrop className={classes.backdrop} open={open} onClick={handleClose}> {progressbar(1)} </Backdrop>}
                                </CCol> */}
                            </CRow>
                            <CRow>
                            </CRow>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>


          {props.seqnum == undefined  ? "" :    <CRow id="ClaimsBack" className="ClaimsBack">
                <CCol className="d-flex justify-content-end col-12">
                    <CButton onClick={() => hanldleBack()} type="submit" color="primary" className="custom_button">BACK</CButton>
                </CCol>
            </CRow>}
            {isLoading ? <ClaimsDatatable result={data} column_name={customized_col_names} column_index={customized_col_index} cells={cells} /> : ""}

        </div>
    )
}

export default Claims
